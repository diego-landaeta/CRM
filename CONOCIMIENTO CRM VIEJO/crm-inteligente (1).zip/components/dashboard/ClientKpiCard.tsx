
import React from 'react';
import Card from '../ui/Card.tsx';

const ClientKpiCard: React.FC = () => {
  return (
    <Card className="flex flex-col items-center">
      <h3 className="text-lg font-semibold text-[var(--text-primary)] mb-3 self-start">KPIs Clave de Clientes</h3>
      <img
        alt="Medidor de KPIs de clientes"
        className="w-40 h-auto mb-3"
        src="https://picsum.photos/seed/kpi/200/150"
      />
      <div className="grid grid-cols-2 gap-x-4 gap-y-2 w-full text-sm mt-2">
        <p className="text-[var(--text-secondary)]">Satisfacción:</p>
        <p className="font-medium text-[var(--text-primary)] text-right">92%</p>
        <p className="text-[var(--text-secondary)]">Retención:</p>
        <p className="font-medium text-[var(--text-primary)] text-right">85%</p>
        <p className="text-[var(--text-secondary)]">Valor Prom.:</p>
        <p className="font-medium text-[var(--text-primary)] text-right">$1,250</p>
      </div>
      <button className="mt-4 w-full bg-emerald-50 text-[var(--text-accent)] font-medium py-2 px-4 rounded-lg hover:bg-emerald-100 transition-colors text-sm">
        Optimizar KPIs
      </button>
    </Card>
  );
};

export default ClientKpiCard;