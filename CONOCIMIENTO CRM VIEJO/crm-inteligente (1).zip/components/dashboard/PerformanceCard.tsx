
import React from 'react';
import Card from '../ui/Card.tsx';
import Icon from '../ui/Icon.tsx';

const PerformanceCard: React.FC = () => {
  const stats = [
    { value: '1,280', label: 'Nuevos Leads (Mes)' },
    { value: '72%', label: 'Tasa de Conversión' },
    { value: '$45,670', label: 'Ingresos Generados' },
    { value: '15', label: 'Alertas Activas', color: 'text-orange-500' },
  ];

  return (
    <Card className="flex flex-col h-full">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-xl font-semibold text-[var(--text-primary)]">Visión General del Rendimiento</h3>
        <button className="bg-[var(--button-primary-bg)] text-white font-semibold py-2.5 px-4 sm:px-5 rounded-lg flex items-center space-x-2 hover:bg-[var(--button-primary-hover-bg)] transition-all duration-200 ease-in-out text-sm shadow-md hover:shadow-lg">
          <Icon name="add_circle_outline" className="text-xl" />
          <span className="hidden sm:inline">Generar Reporte</span>
        </button>
      </div>
      <div className="flex-grow bg-gradient-to-br from-emerald-600 to-emerald-800 rounded-lg p-4 flex justify-center items-center min-h-[300px]">
        <img
          alt="Gráfico de reporte"
          className="max-w-full max-h-full object-contain shadow-2xl rounded-md"
          src="https://storage.googleapis.com/proudcity/mebanenc/uploads/2021/03/placeholder-image-300x225.png"
        />
      </div>
      <div className="mt-4 grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
        {stats.map((stat, index) => (
          <div key={index}>
            <p className={`text-2xl font-bold ${stat.color || 'text-[var(--text-accent)]'}`}>{stat.value}</p>
            <p className="text-xs text-[var(--text-secondary)]">{stat.label}</p>
          </div>
        ))}
      </div>
    </Card>
  );
};

export default PerformanceCard;