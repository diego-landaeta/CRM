
import React from 'react';
import Icon from '../ui/Icon.tsx';

const CermiPromoCard: React.FC = () => {
  return (
    <div className="bg-gradient-to-br from-emerald-500 to-teal-600 text-white p-6 rounded-xl shadow-[0_4px_12px_var(--card-shadow)] flex flex-col items-center justify-center text-center">
      <Icon name="auto_awesome" className="text-5xl mb-3 opacity-80" />
      <h3 className="text-xl font-semibold mb-2">¡Cermi está aquí para ayudar!</h3>
      <p className="text-sm opacity-90 mb-4">¿Necesitas generar un reporte rápido o encontrar un contacto? Pídeselo a Cermi.</p>
      <button className="bg-white/20 hover:bg-white/30 text-white font-semibold py-2.5 px-6 rounded-lg transition-colors text-sm shadow-md">
        Hablar con Cermi
      </button>
    </div>
  );
};

export default CermiPromoCard;