
import React from 'react';
import Card from '../ui/Card.tsx';
import Icon from '../ui/Icon.tsx';
import { PendingTask } from '../../types.ts';

interface PendingTasksCardProps {
  tasks: PendingTask[];
}

const PendingTasksCard: React.FC<PendingTasksCardProps> = ({ tasks }) => {
  return (
    <Card>
      <h3 className="text-lg font-semibold text-[var(--text-primary)] mb-3">Tareas Pendientes</h3>
      <ul className="space-y-3">
        {tasks.map((task, index) => (
          <li
            key={task.id}
            className={`flex items-center justify-between pb-2 ${index < tasks.length - 1 ? 'border-b border-gray-100' : ''}`}
          >
            <div>
              <p className="text-sm font-medium text-[var(--text-primary)]">{task.title}</p>
              <p className={`text-xs ${task.dueColor}`}>{task.dueDate}</p>
            </div>
            <button className="text-gray-400 hover:text-green-500 transition-colors">
              <Icon name="check_box_outline_blank" />
            </button>
          </li>
        ))}
      </ul>
      <button className="mt-4 w-full text-sm text-[var(--text-accent)] font-medium py-2 px-4 rounded-lg border-2 border-emerald-500 hover:bg-emerald-50 transition-colors">
        Ver todas las tareas
      </button>
    </Card>
  );
};

export default PendingTasksCard;