
import React from 'react';
import Card from '../ui/Card.tsx';

const LeadConversionCard: React.FC = () => {
  const percentage = 34;
  const strokeDasharray = `${percentage}, 100`;

  return (
    <Card>
      <h3 className="text-lg font-semibold text-[var(--text-primary)] mb-1">Leads Convertidos en Clientes</h3>
      <p className="text-sm text-[var(--text-secondary)] mb-3">Últimos 30 días</p>
      <div className="flex items-center justify-between">
        <div>
          <p className="text-5xl font-bold text-[var(--text-accent)]">86</p>
          <p className="text-sm text-[var(--text-secondary)]">Entraron 250 Leads</p>
        </div>
        <div className="w-24 h-24 relative">
          <svg className="w-full h-full" viewBox="0 0 36 36">
            <path
              className="text-gray-200"
              d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
              fill="none"
              stroke="currentColor"
              strokeWidth="3.5"
            ></path>
            <path
              className="text-[var(--text-accent)]"
              d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831"
              fill="none"
              stroke="currentColor"
              strokeDasharray={strokeDasharray}
              strokeLinecap="round"
              strokeWidth="3.5"
              transform="rotate(-90 18 18)"
            ></path>
          </svg>
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="text-lg font-semibold text-[var(--text-accent)]">{percentage}%</span>
          </div>
        </div>
      </div>
      <button className="mt-4 w-full bg-emerald-50 text-[var(--text-accent)] font-medium py-2 px-4 rounded-lg hover:bg-emerald-100 transition-colors text-sm">
        Ver detalle de conversión
      </button>
    </Card>
  );
};

export default LeadConversionCard;