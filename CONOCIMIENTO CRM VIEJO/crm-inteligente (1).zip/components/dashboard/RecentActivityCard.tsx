
import React from 'react';
import Card from '../ui/Card.tsx';
import Icon from '../ui/Icon.tsx';
import { RecentActivity } from '../../types.ts';

interface RecentActivityCardProps {
  activities: RecentActivity[];
}

const RecentActivityCard: React.FC<RecentActivityCardProps> = ({ activities }) => {
  return (
    <Card>
      <h3 className="text-lg font-semibold text-[var(--text-primary)] mb-3">Actividad Reciente</h3>
      <ul className="space-y-3">
        {activities.map((activity, index) => (
          <li
            key={activity.id}
            className={`flex items-start space-x-3 pb-3 ${index < activities.length - 1 ? 'border-b border-gray-100' : ''}`}
          >
            <Icon name={activity.icon} className={`${activity.iconColor} mt-0.5`} />
            <div>
              <p className="text-sm font-medium text-[var(--text-primary)]" dangerouslySetInnerHTML={{ __html: activity.title.replace(/:(.*)/, ':<span class="font-normal">$1</span>') }}></p>
              <p className="text-xs text-[var(--text-secondary)]">{activity.timestamp}</p>
            </div>
          </li>
        ))}
      </ul>
    </Card>
  );
};

export default RecentActivityCard;