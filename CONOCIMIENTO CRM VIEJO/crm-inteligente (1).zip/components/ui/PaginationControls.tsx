import React from 'react';
import Icon from './Icon.tsx';

interface PaginationControlsProps {
  currentPage: number;
  totalPages: number;
  onPageChange: (page: number) => void;
  itemsPerPage: number;
  onItemsPerPageChange: (size: number) => void;
  totalItems: number;
  itemCountOnPage: number;
}

const PaginationControls: React.FC<PaginationControlsProps> = ({
  currentPage,
  totalPages,
  onPageChange,
  itemsPerPage,
  onItemsPerPageChange,
  totalItems,
  itemCountOnPage,
}) => {
    const startItem = totalItems > 0 ? (currentPage - 1) * itemsPerPage + 1 : 0;
    const endItem = startItem + itemCountOnPage - 1;

    return (
        <div className="flex justify-between items-center mt-6 pt-4 border-t border-gray-200 flex-wrap gap-4">
            <div className="flex items-center gap-2 text-sm text-gray-600">
                <span>Mostrar</span>
                <select
                    value={itemsPerPage}
                    onChange={(e) => onItemsPerPageChange(Number(e.target.value))}
                    className="px-2 py-1 border border-gray-300 rounded-md focus:ring-teal-500 focus:border-teal-500 bg-white"
                    aria-label="Resultados por página"
                >
                    <option value={10}>10</option>
                    <option value={25}>25</option>
                    <option value={50}>50</option>
                    <option value={100}>100</option>
                </select>
                <span>resultados</span>
            </div>
            
            <p className="text-sm text-gray-600">
                Mostrando {startItem} - {endItem} de {totalItems} resultados
            </p>

            <div className="flex items-center gap-2">
                <button
                    onClick={() => onPageChange(currentPage - 1)}
                    disabled={currentPage === 1}
                    className="p-2 border rounded-md disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-100 transition-colors"
                    aria-label="Página anterior"
                >
                    <Icon name="chevron_left" />
                </button>
                <span className="text-sm font-medium text-gray-700">
                    Página {currentPage} de {totalPages > 0 ? totalPages : 1}
                </span>
                <button
                    onClick={() => onPageChange(currentPage + 1)}
                    disabled={currentPage === totalPages || totalPages === 0}
                    className="p-2 border rounded-md disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-100 transition-colors"
                    aria-label="Página siguiente"
                >
                    <Icon name="chevron_right" />
                </button>
            </div>
        </div>
    );
};

export default PaginationControls;
