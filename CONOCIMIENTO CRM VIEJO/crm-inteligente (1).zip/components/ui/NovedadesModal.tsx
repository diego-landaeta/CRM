
import React from 'react';
import Icon from './Icon.tsx';

interface NovedadesModalProps {
    isOpen: boolean;
    onClose: () => void;
}

const Feature: React.FC<{ icon: string, title: string, children: React.ReactNode }> = ({ icon, title, children }) => (
    <div className="flex items-start gap-4">
        <div className="flex-shrink-0 w-10 h-10 rounded-lg flex items-center justify-center bg-teal-100">
            <Icon name={icon} className="text-xl text-teal-600" />
        </div>
        <div>
            <h4 className="font-semibold text-gray-800">{title}</h4>
            <p className="text-sm text-gray-600">{children}</p>
        </div>
    </div>
);

const NovedadesModal: React.FC<NovedadesModalProps> = ({ isOpen, onClose }) => {
    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 flex justify-center items-center z-50 p-4 transition-opacity duration-300">
            <div className="bg-white rounded-xl shadow-2xl p-6 sm:p-8 max-w-2xl w-full transform transition-all animate-scale-in max-h-[90vh] flex flex-col">
                <header className="flex justify-between items-center mb-4 pb-4 border-b">
                    <div className="flex items-center gap-3">
                         <Icon name="celebration" className="text-3xl text-purple-500" />
                        <div>
                           <h3 className="text-2xl font-bold text-gray-900">¡Novedades en la Plataforma!</h3>
                           <p className="text-sm text-gray-500">Hemos lanzado nuevas funciones para potenciar tu gestión.</p>
                        </div>
                    </div>
                    <button onClick={onClose} className="text-gray-400 hover:text-gray-700 p-1 rounded-full"><Icon name="close" /></button>
                </header>

                <main className="overflow-y-auto pr-4 -mr-4 space-y-6">
                    <Feature icon="integration_instructions" title="Gestión de Flujos de n8n Simplificada">
                        Conecta múltiples automatizaciones de n8n directamente desde la interfaz de Email. Añade, edita y elimina flujos de trabajo con facilidad, sin necesidad de tocar el código.
                    </Feature>
                    <Feature icon="upload_file" title="Importación desde Excel Mejorada">
                        Ahora puedes personalizar la plantilla de importación seleccionando los campos que necesitas. El sistema también crea automáticamente nuevas categorías (etapas, coordinadoras, etc.) que no existan.
                    </Feature>
                    <Feature icon="archive" title="Archivado de Clientes y Prospectos">
                        Mantén tus listas principales limpias moviendo contactos inactivos al archivo. Podrás verlos y restaurarlos desde la nueva pestaña "Archivados".
                    </Feature>
                    <Feature icon="payments" title="Gestión de Pagos por Cuotas">
                        El nuevo módulo de Facturación te permite gestionar clientes con pago a cuotas. Marca las cuotas como pagadas y el sistema calculará automáticamente el saldo pendiente.
                    </Feature>
                     <Feature icon="filter_alt" title="Filtros Avanzados para Contactos">
                        Utiliza el nuevo panel de filtros para segmentar tus clientes y prospectos por país, origen, oferta académica jerárquica y más.
                    </Feature>
                     <Feature icon="visibility" title="Vista Detallada de Contacto">
                        Haz clic en el nombre de un cliente o prospecto para abrir una vista rápida con todos sus detalles y acciones rápidas, sin salir de la página.
                    </Feature>
                    <Feature icon="notifications" title="Centro de Notificaciones Funcional">
                       ¡Justo lo que estás viendo! La campana de notificaciones ahora es completamente funcional, con un historial completo en la nueva página "Ver todas".
                    </Feature>
                </main>

                <footer className="mt-6 pt-4 border-t">
                    <button
                        onClick={onClose}
                        className="w-full bg-teal-600 text-white font-semibold py-2.5 px-6 rounded-lg hover:bg-teal-700 transition-colors"
                    >
                        ¡Genial! Entendido
                    </button>
                </footer>
            </div>
            <style>{`
            @keyframes scale-in {
                from { transform: scale(0.95); opacity: 0; }
                to { transform: scale(1); opacity: 1; }
            }
            .animate-scale-in {
                animation: scale-in 0.2s ease-out forwards;
            }
            `}</style>
        </div>
    );
};

export default NovedadesModal;
