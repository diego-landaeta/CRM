import React, { useState, useEffect } from 'react';
import Icon from './Icon.tsx';
import { Client, Installment, Json } from '../../types.ts';
import { useCurrency } from '../../contexts/CurrencyContext.tsx';

interface InstallmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (client: Client) => void;
  client: Client;
}

const InstallmentModal: React.FC<InstallmentModalProps> = ({ isOpen, onClose, onSave, client }) => {
  const [installments, setInstallments] = useState<Installment[]>([]);
  const { formatCurrency } = useCurrency();

  useEffect(() => {
    setInstallments(((client.installment_details as unknown) as Installment[]) || []);
  }, [client]);

  if (!isOpen) return null;

  const handleStatusChange = (index: number) => {
    const newInstallments = [...installments];
    newInstallments[index].status = newInstallments[index].status === 'Pagado' ? 'Pendiente' : 'Pagado';
    setInstallments(newInstallments);
  };
  
  const handlePaymentMethodChange = (index: number, value: string) => {
      const newInstallments = [...installments];
      newInstallments[index].paymentMethod = value;
      setInstallments(newInstallments);
  };

  const handleSaveChanges = () => {
    const paidAmount = installments
      .filter(inst => inst.status === 'Pagado')
      .reduce((sum, inst) => sum + inst.amount, 0);

    const paidCount = installments.filter(inst => inst.status === 'Pagado').length;

    const updatedClient: Client = {
      ...client,
      installment_details: installments as unknown as Json,
      total_paid: paidAmount,
      installments_paid: paidCount,
    };
    onSave(updatedClient);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex justify-center items-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-2xl p-6 sm:p-8 max-w-3xl w-full transform transition-all animate-scale-in">
        <header className="flex justify-between items-center mb-4 border-b pb-3">
          <div>
            <h3 className="text-xl font-bold text-gray-900">Gestionar Cuotas de {client.name}</h3>
            <p className="text-sm text-gray-500">Marca las cuotas que han sido pagadas.</p>
          </div>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-800"><Icon name="close" /></button>
        </header>
        
        <div className="space-y-3 max-h-[60vh] overflow-y-auto pr-2">
            {installments.map((inst, index) => (
                <div key={index} className="grid grid-cols-1 md:grid-cols-5 gap-4 items-center p-3 rounded-lg bg-gray-50">
                    <div className="font-medium">Cuota {index + 1}</div>
                    <div className="font-semibold">{formatCurrency(inst.amount)}</div>
                    <div>Vence: {new Date(inst.dueDate).toLocaleDateString()}</div>
                    <input 
                        type="text"
                        placeholder="Método de Pago"
                        value={inst.paymentMethod || ''}
                        onChange={(e) => handlePaymentMethodChange(index, e.target.value)}
                        className="w-full px-3 py-1.5 border border-gray-300 rounded-md focus:ring-teal-500 focus:border-teal-500 text-sm"
                    />
                    <label className="flex items-center gap-2 cursor-pointer text-sm font-medium">
                        <input
                            type="checkbox"
                            checked={inst.status === 'Pagado'}
                            onChange={() => handleStatusChange(index)}
                            className="h-5 w-5 rounded border-gray-300 text-teal-600 focus:ring-teal-500"
                        />
                        {inst.status}
                    </label>
                </div>
            ))}
        </div>
        
        <div className="mt-6 flex justify-end gap-3">
          <button type="button" onClick={onClose} className="px-4 py-2 rounded-lg text-gray-700 border border-gray-300 hover:bg-gray-50">Cancelar</button>
          <button type="button" onClick={handleSaveChanges} className="px-4 py-2 rounded-lg text-white bg-teal-600 hover:bg-teal-700">Guardar Cambios</button>
        </div>
      </div>
      <style>{`
        @keyframes scale-in {
          from { transform: scale(0.95); opacity: 0; }
          to { transform: scale(1); opacity: 1; }
        }
        .animate-scale-in {
          animation: scale-in 0.2s ease-out forwards;
        }
      `}</style>
    </div>
  );
};

export default InstallmentModal;