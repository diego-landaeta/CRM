import React from 'react';

interface FormInputProps {
    label: string;
    id: string;
    name: string;
    type?: string;
    placeholder?: string;
    required?: boolean;
    value: string | number;
    onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
    readOnly?: boolean;
}

const FormInput: React.FC<FormInputProps> = 
({ label, id, name, type = 'text', placeholder, required = false, value, onChange, readOnly = false }) => (
    <div>
        <label className="block text-sm font-medium text-gray-700 mb-1" htmlFor={id}>{label}{required && <span className="text-red-500">*</span>}</label>
        <input 
            className={`w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-teal-500 focus:border-teal-500 transition ${readOnly ? 'bg-gray-100 cursor-not-allowed' : ''}`}
            id={id} 
            name={name} 
            placeholder={placeholder} 
            type={type} 
            required={required} 
            value={value} 
            onChange={onChange}
            readOnly={readOnly}
        />
    </div>
);

export default FormInput;
