
import React from 'react';
import Icon from './Icon.tsx';

const abrahamCard = `<div style="max-width: 400px; margin: auto; padding: 20px; border: 2px solid #e0e0e0; border-radius: 10px; background: #ffffff; font-family: sans-serif; text-align: center; box-shadow: 0 5px 15px rgba(0,0,0,0.1);">
  <!-- GitHub Icon -->
  <div style="margin-bottom: 15px;">
    <svg width="50" height="50" viewBox="0 0 16 16" fill="#24292e" xmlns="http://www.w3.org/2000/svg">
      <path d="M8 .198a8 8 0 0 0-2.534 15.598c.4.074.546-.172.546-.383 0-.19-.007-.693-.011-1.361-2.225.483-2.695-1.073-2.695-1.073-.364-.923-.89-1.168-.89-1.168-.727-.497.055-.487.055-.487.803.057 1.225.825 1.225.825.715 1.224 1.873.87 2.329.665.072-.517.28-.87.509-1.07-1.777-.2-3.644-.888-3.644-3.957 0-.874.312-1.59.824-2.15-.083-.202-.357-1.016.078-2.117 0 0 .672-.215 2.202.82A7.656 7.656 0 0 1 8 4.62c.682.003 1.37.092 2.011.27 1.53-1.035 2.2-.82 2.2-.82.437 1.101.163 1.915.08 2.117.513.56.823 1.276.823 2.15 0 3.075-1.87 3.754-3.652 3.95.287.246.543.735.543 1.48 0 1.068-.01 1.93-.01 2.192 0 .213.144.46.55.382A8.001 8.001 0 0 0 8 .198z"/>
    </svg>
  </div>
  <h2 style="margin: 0; font-size: 24px; color: #222;">Desarrollador Frontend</h2>
  <p style="margin: 10px 0 5px; font-size: 20px; color: #333; font-weight: bold;">Abraham</p>
  <p style="margin: 10px 0 20px; font-size: 16px; color: #666;">Especializado en la creación de interfaces de usuario interactivas y responsivas con React y TypeScript.</p>
  <a href="https://github.com/abraham111-ry" target="_blank" style="display: inline-block; padding: 10px 20px; background-color: #24292e; color: #ffffff; border-radius: 5px; text-decoration: none; font-weight: bold;">
    Ver GitHub
  </a>
</div>`;

const diegoCard = `<div style="max-width: 400px; margin: auto; padding: 20px; border: 2px solid #e0e0e0; border-radius: 10px; background: #ffffff; font-family: sans-serif; text-align: center; box-shadow: 0 5px 15px rgba(0,0,0,0.1);">
  <!-- GitHub Icon -->
  <div style="margin-bottom: 15px;">
    <svg width="50" height="50" viewBox="0 0 16 16" fill="#e63946" xmlns="http://www.w3.org/2000/svg">
      <path d="M8 .198a8 8 0 0 0-2.534 15.598c.4.074.546-.172.546-.383 0-.19-.007-.693-.011-1.361-2.225.483-2.695-1.073-2.695-1.073-.364-.923-.89-1.168-.89-1.168-.727-.497.055-.487.055-.487.803.057 1.225.825 1.225.825.715 1.224 1.873.87 2.329.665.072-.517.28-.87.509-1.07-1.777-.2-3.644-.888-3.644-3.957 0-.874.312-1.59.824-2.15-.083-.202-.357-1.016.078-2.117 0 0 .672-.215 2.202.82A7.656 7.656 0 0 1 8 4.62c.682.003 1.37.092 2.011.27 1.53-1.035 2.2-.82 2.2-.82.437 1.101.163 1.915.08 2.117.513.56.823 1.276.823 2.15 0 3.075-1.87 3.754-3.652 3.95.287.246.543.735.543 1.48 0 1.068-.01 1.93-.01 2.192 0 .213.144.46.55.382A8.001 8.001 0 0 0 8 .198z"/>
    </svg>
  </div>
  <h2 style="margin: 0; font-size: 24px; color: #222;">Desarrollador Backend</h2>
   <p style="margin: 10px 0 5px; font-size: 20px; color: #333; font-weight: bold;">Diego</p>
  <p style="margin: 10px 0 20px; font-size: 16px; color: #666;">Responsable de la arquitectura de la base de datos, la lógica del servidor y la integración de APIs.</p>
  <a href="https://github.com/diegoprogrammer-dev" target="_blank" style="display: inline-block; padding: 10px 20px; background-color: #e63946; color: #ffffff; border-radius: 5px; text-decoration: none; font-weight: bold;">
    Ver GitHub
  </a>
</div>`;

const ronaldCard = `<div style="max-width: 400px; margin: auto; padding: 20px; border: 2px solid #e0e0e0; border-radius: 10px; background: #ffffff; font-family: sans-serif; text-align: center; box-shadow: 0 5px 15px rgba(0,0,0,0.1);">
  <!-- GitHub Icon -->
  <div style="margin-bottom: 15px;">
    <svg width="50" height="50" viewBox="0 0 16 16" fill="#007acc" xmlns="http://www.w3.org/2000/svg">
      <path d="M8 .198a8 8 0 0 0-2.534 15.598c.4.074.546-.172.546-.383 0-.19-.007-.693-.011-1.361-2.225.483-2.695-1.073-2.695-1.073-.364-.923-.89-1.168-.89-1.168-.727-.497.055-.487.055-.487.803.057 1.225.825 1.225.825.715 1.224 1.873.87 2.329.665.072-.517.28-.87.509-1.07-1.777-.2-3.644-.888-3.644-3.957 0-.874.312-1.59.824-2.15-.083-.202-.357-1.016.078-2.117 0 0 .672-.215 2.202.82A7.656 7.656 0 0 1 8 4.62c.682.003 1.37.092 2.011.27 1.53-1.035 2.2-.82 2.2-.82.437 1.101.163 1.915.08 2.117.513.56.823 1.276.823 2.15 0 3.075-1.87 3.754-3.652 3.95.287.246.543.735.543 1.48 0 1.068-.01 1.93-.01 2.192 0 .213.144.46.55.382A8.001 8.001 0 0 0 8 .198z"/>
    </svg>
  </div>
  <h2 style="margin: 0; font-size: 24px; color: #222;">Desarrollador Frontend</h2>
   <p style="margin: 10px 0 5px; font-size: 20px; color: #333; font-weight: bold;">Ronald</p>
  <p style="margin: 10px 0 20px; font-size: 16px; color: #666;">Enfocado en la experiencia de usuario (UX) y el diseño de componentes visuales atractivos y funcionales.</p>
  <a href="https://github.com/ronaldd-png" target="_blank" style="display: inline-block; padding: 10px 20px; background-color: #007acc; color: #ffffff; border-radius: 5px; text-decoration: none; font-weight: bold;">
    Ver GitHub
  </a>
</div>`;


interface CreatorsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const CreatorsModal: React.FC<CreatorsModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex justify-center items-center z-50 p-4 transition-opacity duration-300">
      <div className="bg-white rounded-xl shadow-2xl p-6 sm:p-8 max-w-7xl w-full transform transition-all animate-scale-in max-h-[90vh] overflow-y-auto">
        <header className="flex justify-between items-center mb-6 pb-4 border-b">
          <h3 className="text-2xl font-bold text-gray-900">Créditos de los Desarrolladores</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-700 p-1 rounded-full">
            <Icon name="close" />
          </button>
        </header>

        <div className="flex flex-wrap justify-center gap-8">
            <div dangerouslySetInnerHTML={{ __html: abrahamCard }} />
            <div dangerouslySetInnerHTML={{ __html: diegoCard }} />
            <div dangerouslySetInnerHTML={{ __html: ronaldCard }} />
        </div>

      </div>
      <style>{`
        @keyframes scale-in {
          from { transform: scale(0.95); opacity: 0; }
          to { transform: scale(1); opacity: 1; }
        }
        .animate-scale-in {
          animation: scale-in 0.2s ease-out forwards;
        }
      `}</style>
    </div>
  );
};

export default CreatorsModal;