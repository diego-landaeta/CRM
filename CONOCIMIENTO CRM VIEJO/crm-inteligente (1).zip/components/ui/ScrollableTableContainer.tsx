import React, { useRef, useState, useEffect, useCallback } from 'react';

interface ScrollableTableContainerProps {
  children: React.ReactNode;
  className?: string;
}

const ScrollableTableContainer: React.FC<ScrollableTableContainerProps> = ({ children, className = '' }) => {
    const containerRef = useRef<HTMLDivElement>(null);
    const [showLeftShadow, setShowLeftShadow] = useState(false);
    const [showRightShadow, setShowRightShadow] = useState(false);

    const checkScroll = useCallback(() => {
        const el = containerRef.current;
        if (el) {
            const isScrollable = el.scrollWidth > el.clientWidth;
            // Use a small buffer to prevent floating point inaccuracies
            const atStart = el.scrollLeft < 5;
            const atEnd = el.scrollLeft >= el.scrollWidth - el.clientWidth - 5;

            setShowLeftShadow(isScrollable && !atStart);
            setShowRightShadow(isScrollable && !atEnd);
        }
    }, []);

    useEffect(() => {
        const el = containerRef.current;
        if (!el) return;

        checkScroll();

        const resizeObserver = new ResizeObserver(checkScroll);
        resizeObserver.observe(el);
        el.addEventListener('scroll', checkScroll, { passive: true });

        // A slight delay for the initial check can help if content loads slowly
        const timeoutId = setTimeout(checkScroll, 100);

        return () => {
            clearTimeout(timeoutId);
            if (el) {
               resizeObserver.unobserve(el);
               el.removeEventListener('scroll', checkScroll);
            }
        };
    }, [checkScroll]);

    return (
        <div className={`relative ${className}`}>
            <div 
                className={`absolute top-0 bottom-0 left-0 w-6 bg-gradient-to-r from-white to-transparent pointer-events-none transition-opacity duration-300 z-10 ${showLeftShadow ? 'opacity-100' : 'opacity-0'}`}
                aria-hidden="true"
            />
            <div 
                ref={containerRef} 
                className="overflow-x-auto"
            >
                {children}
            </div>
            <div 
                className={`absolute top-0 bottom-0 right-0 w-6 bg-gradient-to-l from-white to-transparent pointer-events-none transition-opacity duration-300 z-10 ${showRightShadow ? 'opacity-100' : 'opacity-0'}`}
                aria-hidden="true"
            />
        </div>
    );
};

export default ScrollableTableContainer;
