
import React, { useState, useEffect, useMemo } from 'react';
import Icon from './Icon.tsx';
import { AcademicOffer, ProgramType, ProgramTypeLabels } from '../../types.ts';
import FormCombobox from './FormCombobox.tsx';

export interface Filters {
    searchTerm: string;
    stage: string;
    coordinator: string;
    paymentType?: string; // Optional for prospects
    faculty: string;
    programType: string;
    program: string;
    country: string;
    origin: string;
}

interface FilterPanelProps {
    isOpen: boolean;
    onClose: () => void;
    onApplyFilters: (filters: Filters) => void;
    initialFilters: Filters;
    entityType: 'client' | 'prospect';
    
    // Data for dropdowns
    coordinators: string[];
    statuses: string[];
    academicOffer: AcademicOffer;
    isAcademicOfferEnabled: boolean;
    countries: string[];
    origins: string[];
    teamMemberRoleSingular: string;
    teamMemberRolePlural: string;
}

const FilterPanel: React.FC<FilterPanelProps> = ({
    isOpen,
    onClose,
    onApplyFilters,
    initialFilters,
    entityType,
    coordinators,
    statuses,
    academicOffer,
    isAcademicOfferEnabled,
    countries,
    origins,
    teamMemberRoleSingular,
    teamMemberRolePlural,
}) => {
    const [filters, setFilters] = useState<Filters>(initialFilters);

    useEffect(() => {
        setFilters(initialFilters);
    }, [isOpen, initialFilters]);

    const handleFilterChange = (name: string, value: string) => {
        setFilters(prev => ({ ...prev, [name]: value }));
    };
    
    const handleComboboxChange = (name: keyof Filters, value: string) => {
        const newFilters = { ...filters, [name]: value };

        // Reset dependent fields in the academic offer hierarchy
        if (name === 'faculty') {
            newFilters.programType = '';
            newFilters.program = '';
        } else if (name === 'programType') {
            newFilters.program = '';
        }
        setFilters(newFilters);
    };
    
    const getProgramTypeKey = (label: string): ProgramType | '' => {
        return (Object.entries(ProgramTypeLabels) as [ProgramType, string][]).find(
            ([_key, l]) => l === label
        )?.[0] || '';
    }

    const handleClear = () => {
        const clearedFilters: Filters = {
            searchTerm: '',
            stage: '',
            coordinator: '',
            faculty: '',
            programType: '',
            program: '',
            country: '',
            origin: '',
        };
        if (entityType === 'client') {
            clearedFilters.paymentType = '';
        }
        setFilters(clearedFilters);
        onApplyFilters(clearedFilters);
        onClose();
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onApplyFilters(filters);
        onClose();
    };
    
    const facultyNames = useMemo(() => academicOffer.map(f => f.name), [academicOffer]);
    const availableProgramTypes = useMemo(() => {
        if (!filters.faculty) return [];
        const faculty = academicOffer.find(f => f.name === filters.faculty);
        if (!faculty) return [];
        return (Object.keys(ProgramTypeLabels) as ProgramType[]).filter(
            type => faculty[type] && faculty[type].length > 0
        ).map(type => ProgramTypeLabels[type]);
    }, [filters.faculty, academicOffer]);

    const availablePrograms = useMemo(() => {
        if (!filters.faculty || !filters.programType) return [];
        const faculty = academicOffer.find(f => f.name === filters.faculty);
        if (!faculty) return [];
        const typeKey = getProgramTypeKey(filters.programType);
        if (!typeKey) return [];
        return faculty[typeKey]?.map(p => p.name) || [];
    }, [filters.faculty, filters.programType, academicOffer]);

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-end z-40 animate-fade-in-fast">
            <div className="bg-white h-full w-full max-w-md shadow-2xl flex flex-col animate-slide-in-right">
                <header className="flex items-center justify-between p-4 border-b">
                    <h3 className="text-xl font-semibold text-gray-800">Filtros Avanzados</h3>
                    <button onClick={onClose} className="text-gray-500 hover:text-gray-800 p-1 rounded-full">
                        <Icon name="close" />
                    </button>
                </header>

                <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-6">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Buscar por Nombre o Email</label>
                        <input
                            type="text"
                            name="searchTerm"
                            placeholder="Buscar..."
                            value={filters.searchTerm}
                            onChange={(e) => handleFilterChange(e.target.name, e.target.value)}
                            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-teal-500 focus:border-teal-500"
                        />
                    </div>

                    <FormCombobox label="Etapa" name="stage" options={statuses} value={filters.stage} onChange={handleComboboxChange} placeholder="Todas las etapas" />
                    <FormCombobox label={teamMemberRoleSingular} name="coordinator" options={coordinators} value={filters.coordinator} onChange={handleComboboxChange} placeholder={`Todas las ${teamMemberRolePlural.toLowerCase()}`} />
                    <FormCombobox label="País" name="country" options={countries} value={filters.country} onChange={handleComboboxChange} placeholder="Todos los países"/>
                    <FormCombobox label="Origen" name="origin" options={origins} value={filters.origin} onChange={handleComboboxChange} placeholder="Todos los orígenes"/>

                    {entityType === 'client' && (
                         <FormCombobox
                            label="Tipo de Pago"
                            name="paymentType"
                            options={['Pago Único', 'Cuotas']}
                            value={filters.paymentType || ''}
                            onChange={handleComboboxChange}
                            placeholder="Todos los tipos de pago"
                        />
                    )}

                    {isAcademicOfferEnabled && (
                        <div className="p-4 border rounded-lg bg-gray-50 space-y-4">
                            <h4 className="text-md font-semibold text-gray-700">Filtrar por Programa</h4>
                            <FormCombobox label="Facultad" name="faculty" options={facultyNames} value={filters.faculty} onChange={handleComboboxChange} placeholder="Todas las facultades" />
                            {filters.faculty && (
                                <FormCombobox label="Tipo de Programa" name="programType" options={availableProgramTypes} value={filters.programType} onChange={handleComboboxChange} placeholder="Todos los tipos" />
                            )}
                            {filters.faculty && filters.programType && (
                                <FormCombobox label="Programa Específico" name="program" options={availablePrograms} value={filters.program} onChange={handleComboboxChange} placeholder="Todos los programas" />
                            )}
                        </div>
                    )}
                </form>

                <footer className="p-4 border-t bg-gray-50 flex justify-end gap-3">
                    <button type="button" onClick={handleClear} className="px-4 py-2 rounded-lg text-gray-700 border border-gray-300 hover:bg-gray-100">Limpiar Filtros</button>
                    <button type="submit" onClick={handleSubmit} className="px-6 py-2 rounded-lg text-white bg-teal-600 hover:bg-teal-700">Aplicar</button>
                </footer>
                
                <style>{`
                  @keyframes fade-in-fast { from { opacity: 0; } to { opacity: 1; } }
                  @keyframes slide-in-right { from { transform: translateX(100%); } to { transform: translateX(0); } }
                  .animate-fade-in-fast { animation: fade-in-fast 0.2s ease-out forwards; }
                  .animate-slide-in-right { animation: slide-in-right 0.3s ease-out forwards; }
                `}</style>
            </div>
        </div>
    );
};

export default FilterPanel;
