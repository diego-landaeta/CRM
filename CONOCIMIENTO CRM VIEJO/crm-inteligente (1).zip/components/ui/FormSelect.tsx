import React from 'react';
import Icon from './Icon.tsx';

interface FormSelectProps {
    label: string;
    id: string;
    name: string;
    options: (string|number)[];
    required?: boolean;
    value: string | number;
    onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void;
}

const FormSelect: React.FC<FormSelectProps> = 
({ label, id, name, options, required = false, value, onChange }) => (
    <div>
        <label className="block text-sm font-medium text-gray-700 mb-1" htmlFor={id}>{label}{required && <span className="text-red-500">*</span>}</label>
        <div className="relative">
            <select className="w-full px-4 py-2 border border-gray-300 rounded-lg appearance-none focus:ring-teal-500 focus:border-teal-500 transition" id={id} name={name} required={required} value={value} onChange={onChange}>
                <option value="">Selecciona...</option>
                {options.map(option => <option key={option} value={option}>{option}</option>)}
            </select>
            <Icon name="arrow_drop_down" className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 pointer-events-none" />
        </div>
    </div>
);

export default FormSelect;
