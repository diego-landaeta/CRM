
import React from 'react';
import Icon from './Icon.tsx';
import { Client, Prospect, Page } from '../../types.ts';
import { useCurrency } from '../../contexts/CurrencyContext.tsx';

interface ContactDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  contact: Client | Prospect | null;
  entityType: 'client' | 'prospect';
  onNavigate: (page: Page, id?: string) => void;
}

const DetailItem: React.FC<{ icon: string; label: string; value: string | number | null | undefined; }> = ({ icon, label, value }) => {
    if (!value && value !== 0) return null;
    
    return (
        <div className="flex items-start">
            <Icon name={icon} className="text-teal-600 mt-1 mr-3" />
            <div>
                <p className="text-sm text-gray-500">{label}</p>
                <p className="font-medium text-gray-800">{String(value)}</p>
            </div>
        </div>
    );
};

const ContactDetailModal: React.FC<ContactDetailModalProps> = ({ isOpen, onClose, contact, entityType, onNavigate }) => {
  const { formatCurrency } = useCurrency();
  
  if (!isOpen || !contact) return null;

  const handleNavigation = (page: Page) => {
      onNavigate(page, contact.id);
      onClose();
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex justify-center items-center z-50 p-4 transition-opacity duration-300">
      <div className="bg-white rounded-xl shadow-2xl p-6 sm:p-8 max-w-2xl w-full transform transition-all animate-scale-in">
        <header className="flex justify-between items-center mb-6 pb-4 border-b">
          <div className="flex items-center gap-4">
            <span className="bg-teal-100 p-3 rounded-full">
                <Icon name={entityType === 'client' ? 'person' : 'person_search'} className="text-2xl text-teal-700" />
            </span>
            <div>
                 <h3 className="text-2xl font-bold text-gray-900">{contact.name}</h3>
                 <p className="text-sm text-gray-500">{entityType === 'client' ? 'Cliente' : 'Prospecto'}</p>
            </div>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-700 p-1 rounded-full"><Icon name="close" /></button>
        </header>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6 mb-6">
            <DetailItem icon="email" label="Email" value={contact.email} />
            <DetailItem icon="phone" label="Teléfono" value={contact.phone} />
            <DetailItem icon="school" label="Programa" value={contact.program} />
            <DetailItem icon="flag" label="País" value={contact.country} />
            <DetailItem icon="badge" label="Coordinadora" value={contact.coordinator} />
            <DetailItem icon="stairs" label="Etapa" value={contact.stage} />
            <DetailItem icon="monetization_on" label="Valor Estimado" value={formatCurrency(contact.estimated_value)} />
        </div>

        {contact.notes && (
            <div className="mb-6">
                <h4 className="text-sm font-semibold text-gray-600 mb-2">Notas</h4>
                <p className="text-sm text-gray-700 bg-gray-50 p-3 rounded-md border">{contact.notes}</p>
            </div>
        )}
        
        <footer className="mt-8 flex justify-end gap-3 flex-wrap">
          <button type="button" onClick={onClose} className="px-5 py-2 rounded-lg text-gray-700 border border-gray-300 hover:bg-gray-50 font-medium transition-colors">Cerrar</button>
          {entityType === 'prospect' && (
            <button
                type="button"
                onClick={() => handleNavigation('ConvertProspect')}
                className="px-5 py-2 rounded-lg text-white bg-green-600 hover:bg-green-700 font-medium transition-colors flex items-center gap-2"
            >
                <Icon name="sync_alt" className="text-base" /> Convertir a Cliente
            </button>
          )}
          <button
            type="button"
            onClick={() => handleNavigation(entityType === 'client' ? 'EditClient' : 'EditProspect')}
            className="px-5 py-2 rounded-lg text-white bg-teal-600 hover:bg-teal-700 font-medium transition-colors flex items-center gap-2"
          >
             <Icon name="edit" className="text-base" /> Editar
          </button>
        </footer>
      </div>
      <style>{`
        @keyframes scale-in {
          from { transform: scale(0.95); opacity: 0; }
          to { transform: scale(1); opacity: 1; }
        }
        .animate-scale-in {
          animation: scale-in 0.2s ease-out forwards;
        }
      `}</style>
    </div>
  );
};

export default ContactDetailModal;