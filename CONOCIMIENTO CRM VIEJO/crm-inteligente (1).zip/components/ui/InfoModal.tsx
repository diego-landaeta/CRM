
import React from 'react';
import Icon from './Icon.tsx';

interface InfoModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  message: string;
  type?: 'success' | 'error';
}

const InfoModal: React.FC<InfoModalProps> = ({
  isOpen,
  onClose,
  title,
  message,
  type = 'success',
}) => {
  if (!isOpen) return null;

  const iconName = type === 'success' ? 'check_circle' : 'error';
  const iconClasses = type === 'success' ? 'bg-teal-100 text-teal-600' : 'bg-red-100 text-red-600';
  const buttonClasses = type === 'success' ? 'bg-teal-600 hover:bg-teal-700 focus:ring-teal-500' : 'bg-red-600 hover:bg-red-700 focus:ring-red-500';

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex justify-center items-center z-50 transition-opacity duration-300">
      <div className="bg-white rounded-xl shadow-2xl p-6 sm:p-8 max-w-md w-full m-4 transform transition-all duration-300 scale-95 animate-scale-in">
        <div className="flex items-start">
          <div className={`mx-auto flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full ${iconClasses} sm:mx-0 sm:h-10 sm:w-10`}>
            <Icon name={iconName} />
          </div>
          <div className="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left">
            <h3 className="text-lg leading-6 font-bold text-gray-900" id="modal-title">
              {title}
            </h3>
            <div className="mt-2">
              <p className="text-sm text-gray-600">
                {message}
              </p>
            </div>
          </div>
        </div>
        <div className="mt-5 sm:mt-6">
          <button
            type="button"
            className={`w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 text-base font-medium text-white focus:outline-none focus:ring-2 focus:ring-offset-2 sm:text-sm ${buttonClasses}`}
            onClick={onClose}
          >
            Entendido
          </button>
        </div>
         <style>{`
          @keyframes scale-in {
            from { transform: scale(0.95); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
          }
          .animate-scale-in {
            animation: scale-in 0.2s ease-out forwards;
          }
        `}</style>
      </div>
    </div>
  );
};

export default InfoModal;
