
import React, { useState, useEffect, useRef } from 'react';
import Icon from './Icon.tsx';

interface FormComboboxProps {
    label: string;
    name: string;
    options: string[];
    value: string;
    onChange: (name: string, value: string) => void;
    placeholder?: string;
    required?: boolean;
}

const FormCombobox: React.FC<FormComboboxProps> = ({ label, name, options, value, onChange, placeholder = "Selecciona...", required = false }) => {
    const [isOpen, setIsOpen] = useState(false);
    const [query, setQuery] = useState('');
    const wrapperRef = useRef<HTMLDivElement>(null);
    const inputRef = useRef<HTMLInputElement>(null);

    // When the component's value prop changes from the outside, update the query.
    useEffect(() => {
        setQuery(value || '');
    }, [value]);
    
    // Handle clicks outside the component to close the dropdown.
    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
                setIsOpen(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    const filteredOptions = query === '' || query === value
        ? options
        : options.filter(option =>
            option.toLowerCase().replace(/\s+/g, '').includes(query.toLowerCase().replace(/\s+/g, ''))
        );

    const handleSelectOption = (option: string) => {
        setQuery(option); // Update input text to reflect selection
        onChange(name, option);
        setIsOpen(false);
    };

    const handleBlur = () => {
        // If the query text is not a valid option and is not empty,
        // treat it as a new value.
        if (query && !options.some(opt => opt.toLowerCase() === query.toLowerCase())) {
            onChange(name, query);
        }
        setIsOpen(false);
    }

    return (
        <div ref={wrapperRef}>
            <label className="block text-sm font-medium text-gray-700 mb-1" htmlFor={name}>{label}{required && <span className="text-red-500">*</span>}</label>
            <div className="relative">
                <div className="relative">
                    <input
                        id={name}
                        ref={inputRef}
                        type="text"
                        className="w-full px-4 py-2 pr-10 border border-gray-300 rounded-lg focus:ring-teal-500 focus:border-teal-500 transition"
                        value={query}
                        onChange={(e) => {
                            setQuery(e.target.value);
                            if(!isOpen) setIsOpen(true);
                        }}
                        onFocus={() => setIsOpen(true)}
                        onBlur={handleBlur}
                        placeholder={placeholder}
                        autoComplete="off"
                    />
                    <button
                        type="button"
                        className="absolute inset-y-0 right-0 flex items-center pr-2"
                        onClick={() => setIsOpen(!isOpen)}
                    >
                        <Icon name="unfold_more" className="text-gray-400" aria-hidden="true" />
                    </button>
                </div>

                {isOpen && (
                    <ul className="absolute z-20 w-full mt-1 bg-white border border-gray-300 rounded-lg shadow-lg max-h-60 overflow-y-auto animate-fade-in-sm">
                        {filteredOptions.length > 0 ? (
                             filteredOptions.map(option => (
                                <li
                                    key={option}
                                    className={`px-4 py-2 cursor-pointer hover:bg-teal-50 text-gray-900 ${value === option ? 'bg-teal-100 font-semibold' : ''}`}
                                    onMouseDown={(e) => { // use onMouseDown to fire before onBlur on input
                                        e.preventDefault();
                                        handleSelectOption(option);
                                    }}
                                >
                                    {option}
                                </li>
                            ))
                        ) : (
                            <li className="px-4 py-2 text-gray-500">No se encontraron resultados. Puedes crear uno nuevo.</li>
                        )}
                    </ul>
                )}
            </div>
            <style>{`
                @keyframes fade-in-sm {
                    from { opacity: 0; transform: scale(0.98) translateY(-5px); }
                    to { opacity: 1; transform: scale(1) translateY(0); }
                }
                .animate-fade-in-sm {
                    animation: fade-in-sm 0.1s ease-out forwards;
                }
            `}</style>
        </div>
    );
};

export default FormCombobox;