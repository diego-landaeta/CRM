import React, { useState } from 'react';
import Icon from './Icon.tsx';
import { authService } from '../../services/authService.ts';

interface PasswordResetModalProps {
  isOpen: boolean;
  onClose: () => void;
  onResetSuccess: () => void;
}

const PasswordResetModal: React.FC<PasswordResetModalProps> = ({ isOpen, onClose, onResetSuccess }) => {
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    const handleSave = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        setSuccess('');

        if (password.length < 6) {
            setError('La contraseña debe tener al menos 6 caracteres.');
            return;
        }
        if (password !== confirmPassword) {
            setError('Las contraseñas no coinciden.');
            return;
        }
        
        setIsLoading(true);
        try {
            await authService.updatePassword(password);
            setSuccess('¡Tu contraseña ha sido actualizada con éxito! Ahora puedes iniciar sesión con tu nueva contraseña.');
            setPassword('');
            setConfirmPassword('');
        } catch (err: any) {
            setError(err.message || 'Ocurrió un error al actualizar la contraseña.');
        } finally {
            setIsLoading(false);
        }
    };
    
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex justify-center items-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-2xl p-6 sm:p-8 max-w-md w-full m-4 transform transition-all duration-300 scale-95 animate-scale-in">
        <header className="flex justify-between items-center mb-4">
            <h3 className="text-xl font-bold text-gray-900">Establecer Nueva Contraseña</h3>
             <button onClick={onClose} className="text-gray-500 hover:text-gray-800"><Icon name="close" /></button>
        </header>
       
        {success ? (
             <div className="text-center">
                <Icon name="check_circle" className="text-5xl text-teal-500 mx-auto mb-4" />
                <p className="text-gray-700">{success}</p>
                 <button
                    onClick={onResetSuccess}
                    className="mt-6 w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-teal-600 text-base font-medium text-white hover:bg-teal-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500 sm:text-sm"
                >
                    Ir a Iniciar Sesión
                </button>
            </div>
        ) : (
            <form onSubmit={handleSave} className="space-y-4">
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1" htmlFor="new-password">Nueva Contraseña</label>
                    <input
                        id="new-password"
                        type="password"
                        value={password}
                        onChange={e => setPassword(e.target.value)}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-teal-500 focus:border-teal-500 transition"
                        placeholder="Introduce tu nueva contraseña"
                    />
                </div>
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1" htmlFor="confirm-new-password">Confirmar Contraseña</label>
                    <input
                        id="confirm-new-password"
                        type="password"
                        value={confirmPassword}
                        onChange={e => setConfirmPassword(e.target.value)}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-teal-500 focus:border-teal-500 transition"
                        placeholder="Confirma tu nueva contraseña"
                    />
                </div>

                {error && <p className="text-sm text-red-600 text-center">{error}</p>}

                <div className="pt-2">
                     <button
                        type="submit"
                        disabled={isLoading}
                        className="w-full flex justify-center py-3 px-4 border border-transparent text-sm font-medium rounded-lg text-white bg-teal-600 hover:bg-teal-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500 disabled:bg-gray-400"
                    >
                        {isLoading ? 'Guardando...' : 'Guardar Nueva Contraseña'}
                    </button>
                </div>
            </form>
        )}
         <style>{`
          @keyframes scale-in {
            from { transform: scale(0.95); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
          }
          .animate-scale-in {
            animation: scale-in 0.2s ease-out forwards;
          }
        `}</style>
      </div>
    </div>
  );
};

export default PasswordResetModal;