import React from 'react';
import Icon from './Icon.tsx';
import { Client, Prospect, ClientDataForCreate, ProspectDataForCreate } from '../../types.ts';

interface DuplicateContactModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOverwrite: () => void;
  existingContact: Client | Prospect | null;
  newContactData: Partial<ClientDataForCreate | ProspectDataForCreate> | null;
  entityType: 'client' | 'prospect' | null;
  allowOverwrite: boolean;
  actionType: 'overwrite' | 'convert';
}

const DataField: React.FC<{ label: string, value: any }> = ({ label, value }) => (
    (value || (typeof value === 'number' && value === 0)) ? <p className="text-sm break-words"><strong className="font-semibold text-gray-600">{label}:</strong> {String(value)}</p> : null
);

const DuplicateContactModal: React.FC<DuplicateContactModalProps> = ({
  isOpen,
  onClose,
  onOverwrite,
  existingContact,
  newContactData,
  entityType,
  allowOverwrite,
  actionType
}) => {
  if (!isOpen || !existingContact || !newContactData || !entityType) return null;

  const entityTypeDisplay = entityType === 'client' ? 'cliente' : 'prospecto';
  let title = `Conflicto: Contacto Duplicado`;
  let message = `Ya existe un ${entityTypeDisplay} con el correo electrónico "${existingContact.email}".`;
  let overwriteButtonText = 'Sobrescribir';

  if (!allowOverwrite) {
      title = 'Acción no permitida';
      message = `Ya existe un cliente con el correo electrónico "${existingContact.email}". No puedes crear un prospecto duplicado. Por favor, utiliza un correo electrónico diferente.`;
  } else if (actionType === 'convert') {
      title = 'Conflicto: Prospecto Existente';
      message = `Ya existe un prospecto con el correo electrónico "${existingContact.email}". ¿Deseas convertirlo a cliente utilizando la nueva información?`;
      overwriteButtonText = 'Convertir a Cliente';
  } else {
       message += ` Puedes sobrescribir los datos existentes con la nueva información o cancelar para editarla.`
       overwriteButtonText = `Sobrescribir ${entityTypeDisplay}`;
  }


  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex justify-center items-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-2xl p-6 sm:p-8 max-w-3xl w-full transform transition-all animate-scale-in">
        <header className="flex justify-between items-start mb-4">
            <div>
                 <h3 className="text-lg leading-6 font-bold text-gray-900" id="modal-title">{title}</h3>
                 <p className="mt-1 text-sm text-gray-600">{message}</p>
            </div>
             <button onClick={onClose} className="text-gray-400 hover:text-gray-600"><Icon name="close"/></button>
        </header>
        
        {allowOverwrite &&
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4 border-t border-b py-6">
                <div className="pr-6 md:border-r">
                    <h4 className="font-bold text-gray-800 mb-3">Datos Existentes ({entityTypeDisplay})</h4>
                    <div className="space-y-2">
                        <DataField label="Nombre" value={existingContact.name} />
                        <DataField label="Teléfono" value={existingContact.phone} />
                        <DataField label="Programa" value={existingContact.program} />
                        <DataField label="Etapa" value={existingContact.stage} />
                        <DataField label="País" value={existingContact.country} />
                        <DataField label="Coordinadora" value={existingContact.coordinator} />
                        <DataField label="Notas" value={existingContact.notes} />
                    </div>
                </div>
                 <div>
                    <h4 className="font-bold text-teal-700 mb-3">Nuevos Datos a Guardar</h4>
                     <div className="space-y-2">
                        <DataField label="Nombre" value={newContactData.name} />
                        <DataField label="Teléfono" value={newContactData.phone} />
                        <DataField label="Programa" value={newContactData.program} />
                        <DataField label="Etapa" value={newContactData.stage} />
                        <DataField label="País" value={newContactData.country} />
                        <DataField label="Coordinadora" value={newContactData.coordinator} />
                        <DataField label="Notas" value={newContactData.notes} />
                    </div>
                </div>
            </div>
        }

        <div className="mt-6 sm:flex sm:flex-row-reverse sm:gap-3">
          {allowOverwrite &&
            <button
                type="button"
                className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 text-base font-medium text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 sm:w-auto sm:text-sm"
                onClick={onOverwrite}
            >
                {overwriteButtonText}
            </button>
          }
          <button
            type="button"
            className="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 sm:mt-0 sm:w-auto sm:text-sm"
            onClick={onClose}
          >
            {allowOverwrite ? 'Cancelar y Editar' : 'Cerrar'}
          </button>
        </div>
        <style>{`
          @keyframes scale-in {
            from { transform: scale(0.95); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
          }
          .animate-scale-in {
            animation: scale-in 0.2s ease-out forwards;
          }
        `}</style>
      </div>
    </div>
  );
};

export default DuplicateContactModal;