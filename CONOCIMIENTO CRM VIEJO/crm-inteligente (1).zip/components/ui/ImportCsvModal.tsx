import React, { useState, useEffect, useCallback } from 'react';
import Icon from './Icon.tsx';
import { configService } from '../../services/configService.ts';
import { dataService } from '../../services/dataService.ts';
import { EntityType, FieldConfig, ClientInsert, ProspectInsert, ProgramType, ProgramTypeLabels, Json, AppConfigUpdate } from '../../types.ts';
import { parseExcel, downloadExcelTemplate } from '../../utils/csv.ts';
import * as XLSX from 'xlsx';

interface ImportCsvModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: () => void;
    entityType: EntityType;
}

const MAX_INSTALLMENTS_TEMPLATE = 15;

const ImportCsvModal: React.FC<ImportCsvModalProps> = ({ isOpen, onClose, onSave, entityType }) => {
    const [allCrmFields, setAllCrmFields] = useState<FieldConfig[]>([]);
    const [selectedFields, setSelectedFields] = useState<Record<string, boolean>>({});
    const [file, setFile] = useState<File | null>(null);
    const [isProcessing, setIsProcessing] = useState(false);
    const [result, setResult] = useState<{ success: boolean; message: string; } | null>(null);
    const [isAcademicOfferEnabled, setIsAcademicOfferEnabled] = useState(true);

    const entityName = entityType === 'client' ? 'Clientes' : 'Prospectos';

    const resetState = useCallback(() => {
        setAllCrmFields([]);
        setSelectedFields({});
        setFile(null);
        setIsProcessing(false);
        setResult(null);
    }, []);

    useEffect(() => {
        if (isOpen) {
            Promise.all([
                configService.getFieldConfig(entityType),
                configService.getAcademicOfferConfig()
            ]).then(([fields, academicConfig]) => {
                setIsAcademicOfferEnabled(academicConfig.is_enabled);
                
                const EXCLUDED_FIELDS_BASE = ['id', 'creation_date', 'last_contact', 'owner_id', 'owner'];
                const EXCLUDED_FIELDS_CLIENT = [...EXCLUDED_FIELDS_BASE, 'installments_paid', 'total_paid', 'installment_details', 'single_payment_method'];

                const importableFields = fields.filter(f => {
                    const exclusions = entityType === 'client' ? EXCLUDED_FIELDS_CLIENT : EXCLUDED_FIELDS_BASE;
                    return !exclusions.includes(f.key);
                });

                setAllCrmFields(importableFields);
                const initialSelection = importableFields.reduce((acc, field) => {
                    const commonFields = ['name', 'email', 'phone', 'program', 'stage', 'coordinator', 'country', 'origin', 'notes', 'next_contact', 'estimated_value', 'payment_type', 'installments_total'];
                    acc[field.key] = commonFields.includes(field.key);
                    return acc;
                }, {} as Record<string, boolean>);
                setSelectedFields(initialSelection);
            });
        } else {
            resetState();
        }
    }, [isOpen, entityType, resetState]);


    const handleToggleField = (fieldKey: string) => {
        setSelectedFields(prev => ({ ...prev, [fieldKey]: !prev[fieldKey] }));
    };

    const handleDownloadTemplate = () => {
        const activeFields = allCrmFields.filter(field => selectedFields[field.key]);
        if (activeFields.length === 0) {
            setResult({ success: false, message: "Por favor, selecciona al menos un campo para descargar la plantilla." });
            return;
        }

        if (entityType === 'client') {
            const headers: string[] = [];
            const fieldOrder = ['name', 'email', 'phone', 'program', 'stage', 'coordinator', 'country', 'origin', 'next_contact', 'notes', 'estimated_value', 'payment_type', 'installments_total'];
            
            const orderedActiveFields = activeFields.sort((a, b) => {
                const indexA = fieldOrder.indexOf(a.key);
                const indexB = fieldOrder.indexOf(b.key);
                if (indexA === -1) return 1;
                if (indexB === -1) return -1;
                return indexA - indexB;
            });

            orderedActiveFields.forEach(field => {
                if (field.key === 'program' && isAcademicOfferEnabled) {
                    headers.push('Facultad', 'Categoría de Programa', 'Nombre del Programa');
                } else {
                    headers.push(field.label);
                }
            });

            if (headers.includes('Tipo de Pago')) {
                headers.splice(headers.indexOf('Tipo de Pago') + 1, 0, 'Método de Pago (Pago Único)');
            }

            for (let i = 1; i <= MAX_INSTALLMENTS_TEMPLATE; i++) {
                headers.push(`Monto Cuota ${i}`, `Fecha Cuota ${i}`, `Método de Pago Cuota ${i}`);
            }

            const example1 = {
                'Nombre': 'Cliente Unico', 'Email': 'unico@ejemplo.com', 'Teléfono': '+123456789',
                'Facultad': 'Marketing', 'Categoría de Programa': 'Cursos', 'Nombre del Programa': 'SEO Avanzado',
                'Etapa': 'Activo', 'Coordinadora': 'Isabel', 'País': 'México', 'Origen': 'Web',
                'Próximo Contacto': '2025-10-15', 'Notas': 'Pago realizado por transferencia.', 'Valor Total Venta': 2500,
                'Tipo de Pago': 'Pago Único', 'Método de Pago (Pago Único)': 'Tarjeta de Crédito', 'Total Cuotas': null
            };
            const example2 = {
                'Nombre': 'Cliente Cuotas', 'Email': 'cuotas@ejemplo.com', 'Teléfono': '+987654321',
                'Facultad': 'Tecnología', 'Categoría de Programa': 'Diplomados', 'Nombre del Programa': 'Ciencia de Datos',
                'Etapa': 'Activo', 'Coordinadora': 'Sofía', 'País': 'Colombia', 'Origen': 'Referido',
                'Próximo Contacto': '2025-11-20', 'Notas': 'Paga mensualmente.', 'Valor Total Venta': 3600,
                'Tipo de Pago': 'Cuotas', 'Total Cuotas': 3,
                'Monto Cuota 1': 1200, 'Fecha Cuota 1': '2025-08-15', 'Método de Pago Cuota 1': 'Transferencia Bancaria',
                'Monto Cuota 2': 1200, 'Fecha Cuota 2': '2025-09-15', 'Método de Pago Cuota 2': 'Transferencia Bancaria',
                'Monto Cuota 3': 1200, 'Fecha Cuota 3': '2025-10-15', 'Método de Pago Cuota 3': 'Transferencia Bancaria',
            };

            const wsData: (string | number | null)[][] = [headers];
            const row1 = headers.map(h => (example1 as any)[h] ?? null);
            const row2 = headers.map(h => (example2 as any)[h] ?? null);

            wsData.push(row1, row2);
            
            const worksheet = XLSX.utils.aoa_to_sheet(wsData);
            const workbook = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(workbook, worksheet, "Plantilla Clientes");
            XLSX.writeFile(workbook, `plantilla_importacion_clientes.xlsx`);
            setResult(null);
        } else {
            // Original logic for prospects
            const headers: string[] = [];
            const exampleRow: (string | number | null)[] = [];
            
            const fieldOrder = ['name', 'email', 'phone', 'program', 'stage', 'coordinator', 'notes', 'origin', 'country', 'next_contact', 'estimated_value'];
            
            const orderedActiveFields = activeFields.sort((a, b) => {
                const indexA = fieldOrder.indexOf(a.key);
                const indexB = fieldOrder.indexOf(b.key);
                if (indexA === -1) return 1;
                if (indexB === -1) return -1;
                return indexA - indexB;
            });

            orderedActiveFields.forEach(field => {
                if (field.key === 'program' && isAcademicOfferEnabled) {
                    headers.push('Facultad', 'Categoría de Programa', 'Nombre del Programa');
                    exampleRow.push('Ingeniería', 'Cursos', 'Sistemas Computacionales');
                } else if (field.key === 'coordinator') {
                    headers.push('Técnico');
                    exampleRow.push('Isabel');
                } else {
                    headers.push(field.label);
                    switch(field.key) {
                        case 'name': exampleRow.push('Juan Ejemplo'); break;
                        case 'email': exampleRow.push('juan.ejemplo@email.com'); break;
                        case 'phone': exampleRow.push('+52 5512345678'); break;
                        case 'stage': exampleRow.push('Nuevo'); break;
                        case 'notes': exampleRow.push('Interesado en el curso'); break;
                        case 'origin': exampleRow.push('Referido'); break;
                        case 'country': exampleRow.push('México'); break;
                        case 'next_contact': exampleRow.push('2025-01-15'); break;
                        case 'estimated_value': exampleRow.push(1500); break;
                        case 'program': exampleRow.push('Programa General'); break;
                        default: exampleRow.push(''); break;
                    }
                }
            });
            downloadExcelTemplate(`plantilla_importacion_${entityType}.xlsx`, headers, exampleRow);
            setResult(null);
        }
    };


    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files.length > 0) {
            setFile(e.target.files[0]);
            setResult(null);
        }
    };
    
    const handleImport = async () => {
        if (!file) {
            setResult({ success: false, message: "Por favor, selecciona un archivo para importar." });
            return;
        }
        
        setIsProcessing(true);
        setResult(null);

        try {
            const parsedData = await parseExcel(file);
            if (parsedData.length === 0) throw new Error("El archivo Excel está vacío o no tiene datos.");
            
            const fields = await configService.getFieldConfig(entityType);
            const labelToKeyMap = fields.reduce((acc, field) => {
                acc[field.label.toLowerCase()] = field.key;
                return acc;
            }, {} as Record<string, string>);
            
            labelToKeyMap['técnico'] = 'coordinator';
            labelToKeyMap['tecnico'] = 'coordinator';
            labelToKeyMap['facultad'] = 'faculty_temp';
            labelToKeyMap['categoría de programa'] = 'category_temp';
            labelToKeyMap['categoria de programa'] = 'category_temp';
            labelToKeyMap['categoría de pr'] = 'category_temp';
            labelToKeyMap['categoria de pr'] = 'category_temp';
            labelToKeyMap['nombre del programa'] = 'program';
            labelToKeyMap['nombre del pro'] = 'program';
            labelToKeyMap['teléfono'] = 'phone';
            labelToKeyMap['telefono'] = 'phone';
            labelToKeyMap['país'] = 'country';
            labelToKeyMap['pais'] = 'country';
            labelToKeyMap['próximo contacto'] = 'next_contact';
            labelToKeyMap['proximo contacto'] = 'next_contact';
            if (entityType === 'client') {
                labelToKeyMap['método de pago (pago único)'] = 'single_payment_method';
                for (let i = 1; i <= 15; i++) { // Process up to 15 installments
                    labelToKeyMap[`monto cuota ${i}`] = `installment_${i}_amount`;
                    labelToKeyMap[`fecha cuota ${i}`] = `installment_${i}_date`;
                    labelToKeyMap[`método de pago cuota ${i}`] = `installment_${i}_method`;
                }
            }

            
            const dataWithKeys = parsedData.map(row => {
                const newRow: any = {};
                for (const label in row) {
                    const key = labelToKeyMap[label.trim().toLowerCase()];
                    if (key) {
                        let value = row[label];
                         if (value instanceof Date) {
                             newRow[key] = value.toISOString().split('T')[0];
                        } else {
                            newRow[key] = value;
                        }
                    }
                }
                return newRow;
            });
            
            const [
                currentCoordinators, currentCountries, currentStages, currentAcademicOffer, academicConfig
            ] = await Promise.all([
                configService.getCoordinators(),
                configService.getCountries(),
                entityType === 'client' ? configService.getClientStatuses() : configService.getProspectStatuses(),
                configService.getAcademicOffer(),
                configService.getAcademicOfferConfig()
            ]);

            const existingCoordinators = new Set(currentCoordinators.map(c => c.toLowerCase()));
            const existingCountries = new Set(currentCountries.map(c => c.toLowerCase()));
            const existingStages = new Set(currentStages.map(s => s.toLowerCase()));
            
            const newOffer = JSON.parse(JSON.stringify(currentAcademicOffer));
            const newCoordinators = new Set<string>();
            const newCountries = new Set<string>();
            const newStages = new Set<string>();
            let offerWasModified = false;

            for (const item of dataWithKeys) {
                if (item.coordinator) {
                    const coordinator = item.coordinator.toString().trim();
                    if (coordinator && !existingCoordinators.has(coordinator.toLowerCase())) newCoordinators.add(coordinator);
                }
                if (item.country) {
                    const country = item.country.toString().trim();
                    if (country && !existingCountries.has(country.toLowerCase())) newCountries.add(country);
                }
                if (item.stage) {
                    const stage = item.stage.toString().trim();
                    if (stage && !existingStages.has(stage.toLowerCase())) newStages.add(stage);
                }

                if (academicConfig.is_enabled) {
                    const { faculty_temp, category_temp, program } = item;
                    if (faculty_temp && category_temp && program) {
                        const facultyName = faculty_temp.toString().trim();
                        const programTypeLabel = category_temp.toString().trim();
                        const programName = program.toString().trim();
                        
                        let faculty = newOffer.find(f => f.name.toLowerCase() === facultyName.toLowerCase());
                        if (!faculty) {
                            faculty = { id: crypto.randomUUID(), name: facultyName, courses: [], diplomas: [], masters: [], specializations: [] };
                            newOffer.push(faculty);
                            offerWasModified = true;
                        }
                        
                        const programTypeKey = (Object.entries(ProgramTypeLabels) as [ProgramType, string][]).find(([_key, label]) => label.toLowerCase() === programTypeLabel.toLowerCase())?.[0];

                        if (programTypeKey && !faculty[programTypeKey].some(p => p.name.toLowerCase() === programName.toLowerCase())) {
                            faculty[programTypeKey].push({ id: crypto.randomUUID(), name: programName });
                            offerWasModified = true;
                        }
                    }
                }
            }
            
            const updatePayload: AppConfigUpdate = {};
            if (newCoordinators.size > 0) updatePayload.coordinators = [...currentCoordinators, ...Array.from(newCoordinators)];
            if (newCountries.size > 0) updatePayload.countries = [...currentCountries, ...Array.from(newCountries)];
            if (newStages.size > 0) {
                if (entityType === 'client') updatePayload.client_statuses = [...currentStages, ...Array.from(newStages)];
                else updatePayload.prospect_statuses = [...currentStages, ...Array.from(newStages)];
            }
            if (offerWasModified) updatePayload.academic_offer = newOffer as unknown as Json;
            
            if (Object.keys(updatePayload).length > 0) {
                await configService.updateConfig(updatePayload);
            }

            const coordinatorMap = await configService.getCoordinatorMap();
            const dataToInsert = dataWithKeys.map(item => {
                if (item.country && !item.coordinator && coordinatorMap[item.country]) {
                    item.coordinator = coordinatorMap[item.country];
                }
                delete item.faculty_temp;
                delete item.category_temp;
                return item;
            });

            const response = entityType === 'client'
                ? await dataService.bulkAddClients(dataToInsert as Partial<ClientInsert>[])
                : await dataService.bulkAddProspects(dataToInsert as Partial<ProspectInsert>[]);

            let successMessage = `${response.successCount} de ${parsedData.length} ${entityName} importados exitosamente.`;
            if (response.duplicateCount > 0) {
                successMessage += ` Se omitieron ${response.duplicateCount} registros por ser duplicados.`;
            }

            setResult({ success: true, message: successMessage });
            setTimeout(() => {
                onSave();
                onClose();
            }, 2000);
        
        } catch (error: any) {
            setResult({ success: false, message: `Error en la importación: ${error.message}` });
        } finally {
            setIsProcessing(false);
        }
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 flex justify-center items-center z-50 p-4">
            <div className="bg-white rounded-xl shadow-2xl p-6 sm:p-8 max-w-4xl w-full transform transition-all animate-scale-in">
                <header className="flex justify-between items-start mb-6">
                    <div>
                        <h3 className="text-xl font-bold text-gray-900">Importar {entityName} desde Excel</h3>
                        <p className="text-sm text-gray-500 mt-1">Sigue los pasos para añadir múltiples registros a la vez.</p>
                    </div>
                    <button onClick={onClose} className="text-gray-500 hover:text-gray-800 p-1 rounded-full"><Icon name="close" /></button>
                </header>

                <div className="space-y-6">
                    {/* Step 1: Download */}
                    <div className="p-6 border rounded-lg bg-gray-50/50">
                        <h4 className="text-lg font-semibold text-gray-800 mb-1">Paso 1: Descargar Plantilla Personalizada</h4>
                        <p className="text-sm text-gray-600 mb-4">Selecciona los campos que quieres incluir. Descarga la plantilla, llénala con tus datos y guárdala.</p>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-x-4 gap-y-3 mb-5 max-h-40 overflow-y-auto pr-2">
                            {allCrmFields.map(field => (
                                <label key={field.key} className="flex items-center space-x-2 cursor-pointer text-sm">
                                    <input
                                        type="checkbox"
                                        className="h-4 w-4 rounded border-gray-300 text-teal-600 focus:ring-teal-500"
                                        checked={selectedFields[field.key] || false}
                                        onChange={() => handleToggleField(field.key)}
                                    />
                                    <span className="text-gray-700">{field.label}</span>
                                </label>
                            ))}
                        </div>
                        <button onClick={handleDownloadTemplate} className="bg-teal-600 hover:bg-teal-700 text-white font-medium py-2 px-4 rounded-lg flex items-center transition-colors shadow-sm hover:shadow-md">
                            <Icon name="download" className="mr-2" />
                            Descargar Plantilla
                        </button>
                    </div>

                    {/* Step 2: Upload */}
                    <div className="p-6 border rounded-lg bg-gray-50/50">
                        <h4 className="text-lg font-semibold text-gray-800 mb-1">Paso 2: Subir y Procesar Archivo</h4>
                        <p className="text-sm text-gray-600 mb-4">Sube el archivo Excel que llenaste. El sistema creará nuevas coordinadoras, países o programas si es necesario.</p>
                        <div className="flex items-center gap-4">
                            <label className="flex-grow h-12 flex items-center justify-center px-4 py-2 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:border-teal-500 hover:bg-white transition-colors">
                                <Icon name="attachment" className="text-gray-500 mr-2" />
                                <span className="text-gray-700 truncate">{file ? file.name : 'Seleccionar archivo...'}</span>
                                <input type="file" accept=".xlsx, .xls" className="hidden" onChange={handleFileChange} />
                            </label>
                            <button onClick={handleImport} disabled={!file || isProcessing} className="px-6 py-2 h-12 rounded-lg text-white bg-gray-700 hover:bg-gray-800 disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center whitespace-nowrap">
                                {isProcessing ? <Icon name="hourglass_top" className="animate-spin mr-2" /> : <Icon name="upload" className="mr-2" />}
                                {isProcessing ? 'Importando...' : 'Importar'}
                            </button>
                        </div>
                    </div>
                </div>
                
                {result && (
                    <div className={`mt-4 p-3 rounded-lg text-sm text-center ${result.success ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                        {result.message}
                    </div>
                )}
            </div>
            <style>{`
              @keyframes scale-in { from { transform: scale(0.95); opacity: 0; } to { transform: scale(1); opacity: 1; } }
              .animate-scale-in { animation: scale-in 0.2s ease-out forwards; }
            `}</style>
        </div>
    );
};

export default ImportCsvModal;