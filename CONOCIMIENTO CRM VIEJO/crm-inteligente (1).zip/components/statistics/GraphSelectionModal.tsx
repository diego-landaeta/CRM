
import React, { useState, useEffect } from 'react';
import Icon from '../ui/Icon.tsx';

interface GraphSelectionModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (selection: Record<string, boolean>) => void;
    currentSelection: Record<string, boolean>;
    teamMemberRole: string;
}

const GraphSelectionModal: React.FC<GraphSelectionModalProps> = ({
    isOpen,
    onClose,
    onSave,
    currentSelection,
    teamMemberRole,
}) => {
    const [selection, setSelection] = useState(currentSelection);
    
    const ALL_GRAPHS = [
        { key: 'ingresosPorMes', label: 'Ingresos por Mes' },
        { key: 'nuevosContactosPorMes', label: 'Nuevos Contactos por Mes' },
        { key: 'distribucionOrigen', label: 'Distribución por Origen' },
        { key: 'rendimientoCoordinadoras', label: `Rendimiento de ${teamMemberRole}` },
        { key: 'embudoDeVentas', label: 'Embudo de Ventas' },
        { key: 'ventasPorPais', label: 'Ventas por País' },
        { key: 'programasPopulares', label: 'Programas Populares' },
    ];


    useEffect(() => {
        setSelection(currentSelection);
    }, [isOpen, currentSelection]);

    if (!isOpen) return null;

    const handleToggle = (key: string) => {
        setSelection(prev => ({ ...prev, [key]: !prev[key] }));
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 flex justify-center items-center z-50 p-4">
            <div className="bg-white rounded-xl shadow-2xl p-6 sm:p-8 max-w-2xl w-full transform transition-all animate-scale-in">
                <header className="flex justify-between items-center mb-4 pb-4 border-b">
                    <h3 className="text-xl font-bold text-gray-900">Gestionar Gráficos del Dashboard</h3>
                    <button onClick={onClose} className="text-gray-500 hover:text-gray-800"><Icon name="close" /></button>
                </header>
                
                <p className="text-gray-600 mb-6">Selecciona los gráficos que quieres que sean visibles en tu panel de estadísticas.</p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-h-[50vh] overflow-y-auto pr-2">
                    {ALL_GRAPHS.map(graph => (
                        <label key={graph.key} className="flex items-center space-x-3 p-3 rounded-lg hover:bg-gray-100 transition-colors cursor-pointer">
                            <input
                                type="checkbox"
                                className="h-5 w-5 rounded border-gray-300 text-teal-600 focus:ring-teal-500"
                                checked={!!selection[graph.key]}
                                onChange={() => handleToggle(graph.key)}
                            />
                            <span className="text-gray-700 font-medium">{graph.label}</span>
                        </label>
                    ))}
                </div>
                
                <div className="mt-6 flex justify-end gap-3">
                    <button type="button" onClick={onClose} className="px-4 py-2 rounded-lg text-gray-700 border border-gray-300 hover:bg-gray-50">Cancelar</button>
                    <button type="button" onClick={() => onSave(selection)} className="px-4 py-2 rounded-lg text-white bg-teal-600 hover:bg-teal-700">Guardar Visibilidad</button>
                </div>
                 <style>{`
                  @keyframes scale-in { from { transform: scale(0.95); opacity: 0; } to { transform: scale(1); opacity: 1; } }
                  .animate-scale-in { animation: scale-in 0.2s ease-out forwards; }
                `}</style>
            </div>
        </div>
    );
};

export default GraphSelectionModal;
