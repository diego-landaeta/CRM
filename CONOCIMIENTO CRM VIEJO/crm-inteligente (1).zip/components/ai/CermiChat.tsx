
import React, { useState, useRef, useEffect } from 'react';
import Icon from '../ui/Icon.tsx';
import { useCermi } from '../../hooks/useCermi.ts';
import { ChatMessage } from '../../types.ts';

interface CermiChatProps {
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
}

const CermiChat: React.FC<CermiChatProps> = ({ isOpen, setIsOpen }) => {
  const { messages, isLoading, sendMessage } = useCermi();
  const [input, setInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(scrollToBottom, [messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim() && !isLoading) {
      sendMessage(input.trim());
      setInput('');
    }
  };

  const MessageBubble: React.FC<{ message: ChatMessage }> = ({ message }) => {
    const isUser = message.role === 'user';
    const bubbleClasses = isUser
      ? 'bg-[var(--sidebar-bg)] text-white self-end'
      : 'bg-gray-200 text-[var(--text-primary)] self-start';
    const errorClasses = message.isError ? 'bg-red-100 text-red-700' : '';
    
    return (
      <div className={`p-3 rounded-lg max-w-sm md:max-w-md break-words ${bubbleClasses} ${errorClasses}`}>
        {message.text}
        {message.role === 'model' && isLoading && messages[messages.length-1].id === message.id && (
             <span className="inline-block w-2 h-4 bg-gray-600 animate-pulse ml-1" />
        )}
      </div>
    );
  };

  return (
    <>
      <div className={`fixed bottom-0 right-0 sm:bottom-6 sm:right-6 z-50 transition-all duration-300 ease-in-out ${isOpen ? 'w-full h-full sm:w-[440px] sm:h-[80vh] sm:max-h-[700px]' : 'w-auto h-auto'}`}>
        {!isOpen && (
          <button
            onClick={() => setIsOpen(true)}
            className="bg-[var(--button-primary-bg)] text-white p-4 rounded-full shadow-xl hover:bg-[var(--button-primary-hover-bg)] transition-all duration-200 ease-in-out flex items-center focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[var(--button-primary-bg)] group"
          >
            <Icon name="chat" className="mr-0 group-hover:mr-2 transition-all duration-200" />
            <span className="hidden group-hover:inline max-w-0 group-hover:max-w-xs transition-all duration-300 ease-in-out overflow-hidden whitespace-nowrap">Soy Cermi, tu asistente IA</span>
          </button>
        )}
        
        {isOpen && (
          <div className="flex flex-col h-full w-full bg-white sm:rounded-2xl shadow-2xl border border-gray-200/50">
            <header className="flex items-center justify-between p-4 border-b bg-[var(--sidebar-bg)] text-white sm:rounded-t-2xl">
              <div className="flex items-center space-x-3">
                <Icon name="auto_awesome" />
                <h3 className="text-lg font-semibold">Cermi, Asistente IA</h3>
              </div>
              <button onClick={() => setIsOpen(false)} className="text-white/70 hover:text-white">
                <Icon name="close" />
              </button>
            </header>
            
            <div className="flex-1 p-4 overflow-y-auto bg-gray-50 flex flex-col space-y-4">
              {messages.map((msg) => (
                <MessageBubble key={msg.id} message={msg} />
              ))}
              <div ref={messagesEndRef} />
            </div>
            
            <footer className="p-4 border-t">
              <form onSubmit={handleSubmit} className="flex items-center space-x-2">
                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Pregúntale algo a Cermi..."
                  disabled={isLoading}
                  className="flex-1 border-gray-300 rounded-full py-2 px-4 focus:ring-2 focus:ring-[var(--input-focus-ring)] focus:border-transparent transition"
                />
                <button
                  type="submit"
                  disabled={isLoading || !input.trim()}
                  className="bg-[var(--button-primary-bg)] text-white rounded-full p-3 disabled:bg-gray-300 disabled:cursor-not-allowed hover:bg-[var(--button-primary-hover-bg)] transition-colors"
                >
                  <Icon name={isLoading ? 'hourglass_top' : 'send'} className={isLoading ? 'animate-spin' : ''} />
                </button>
              </form>
            </footer>
          </div>
        )}
      </div>
    </>
  );
};

export default CermiChat;