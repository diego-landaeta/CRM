
import React, { useState, useEffect, useCallback } from 'react';
import { configService } from '../../services/configService.ts';
import { AcademicOffer, Faculty, ProgramType, AcademicProgram, ProgramTypeLabels } from '../../types.ts';
import Icon from '../ui/Icon.tsx';

const SettingsToggle: React.FC<{ label: string; enabled: boolean; onChange: () => void }> = ({ label, enabled, onChange }) => (
     <div className="flex items-center justify-between">
        <span className="text-sm font-medium text-gray-700">{label}</span>
        <button
            type="button"
            onClick={onChange}
            className={`${enabled ? 'bg-teal-600' : 'bg-gray-200'} relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500`}
        >
            <span className={`${enabled ? 'translate-x-6' : 'translate-x-1'} inline-block w-4 h-4 transform bg-white rounded-full transition-transform`} />
        </button>
    </div>
);


const singularProgramLabels: Record<ProgramType, string> = {
    courses: 'Curso',
    diplomas: 'Diplomado',
    masters: 'Master',
    specializations: 'Especialización'
};

const ProgramInput: React.FC<{
    programType: ProgramType,
    facultyId: string,
    onAddProgram: (facultyId: string, programType: ProgramType, programName: string) => void
}> = ({ programType, facultyId, onAddProgram }) => {
    const [name, setName] = useState('');
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (name.trim()) {
            onAddProgram(facultyId, programType, name.trim());
            setName('');
        }
    };
    return (
        <form onSubmit={handleSubmit} className="flex items-center gap-2 mt-2">
            <input
                type="text"
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder={`Añadir ${singularProgramLabels[programType]}`}
                className="flex-grow w-full text-sm px-2 py-1 border border-gray-300 rounded-md focus:ring-teal-500 focus:border-teal-500"
            />
            <button type="submit" className="p-1.5 bg-teal-500 text-white rounded-md hover:bg-teal-600">
                <Icon name="add" className="text-sm" />
            </button>
        </form>
    );
}

const AcademicOfferManager: React.FC<{
    onSaveSuccess: (message: string) => void;
    showConfirmation: (title: string, message: string, onConfirm: () => Promise<void>) => void;
    showSaveConfirmation: (onConfirm: () => Promise<void>) => void;
}> = ({ onSaveSuccess, showConfirmation, showSaveConfirmation }) => {
    const [offer, setOffer] = useState<AcademicOffer>([]);
    const [isOfferEnabled, setIsOfferEnabled] = useState(true);
    const [isLoading, setIsLoading] = useState(true);
    const [newFacultyName, setNewFacultyName] = useState('');
    const [activeTabs, setActiveTabs] = useState<Record<string, ProgramType>>({});

    const fetchOffer = useCallback(async () => {
        setIsLoading(true);
        const [data, config] = await Promise.all([
            configService.getAcademicOffer(),
            configService.getAcademicOfferConfig()
        ]);
        setOffer(data || []);
        setIsOfferEnabled(config ? config.is_enabled : true);
        setIsLoading(false);
    }, []);

    useEffect(() => {
        fetchOffer();
    }, [fetchOffer]);

    const handleSave = async () => {
        showSaveConfirmation(async () => {
            await Promise.all([
                configService.updateAcademicOffer(offer),
                configService.updateAcademicOfferConfig({ is_enabled: isOfferEnabled })
            ]);
            onSaveSuccess('Configuración de oferta académica actualizada exitosamente.');
        });
    };
    
    const handleAddFaculty = (e: React.FormEvent) => {
        e.preventDefault();
        if (newFacultyName.trim() && !offer.some(f => f.name === newFacultyName.trim())) {
            const newFaculty: Faculty = {
                id: crypto.randomUUID(),
                name: newFacultyName.trim(),
                courses: [],
                diplomas: [],
                masters: [],
                specializations: [],
            };
            setOffer(prev => [...prev, newFaculty]);
            setNewFacultyName('');
        }
    };

    const handleDeleteFaculty = (facultyId: string) => {
        const faculty = offer.find(f => f.id === facultyId);
        if(!faculty) return;

        showConfirmation(
            'Confirmar Eliminación de Facultad',
            `¿Estás seguro de que quieres eliminar la facultad "${faculty.name}" y todos sus programas? Esta acción no se puede deshacer.`,
            async () => {
                setOffer(prev => prev.filter(f => f.id !== facultyId));
                onSaveSuccess(`Facultad "${faculty.name}" eliminada. No olvides guardar los cambios.`);
            }
        );
    };

    const handleAddProgram = (facultyId: string, programType: ProgramType, programName: string) => {
        const newProgram: AcademicProgram = { id: crypto.randomUUID(), name: programName };
        setOffer(prev => prev.map(faculty => {
            if (faculty.id === facultyId) {
                const updatedFaculty = { ...faculty };
                updatedFaculty[programType] = [...faculty[programType], newProgram];
                return updatedFaculty;
            }
            return faculty;
        }));
    };

    const handleDeleteProgram = (facultyId: string, programType: ProgramType, programId: string) => {
        setOffer(prev => prev.map(faculty => {
            if (faculty.id === facultyId) {
                const updatedFaculty = { ...faculty };
                updatedFaculty[programType] = faculty[programType].filter(p => p.id !== programId);
                return updatedFaculty;
            }
            return faculty;
        }));
    };

    if (isLoading) {
        return <div className="bg-white rounded-lg shadow p-6">Cargando oferta académica...</div>;
    }

    return (
        <div className="bg-white rounded-lg shadow p-6">
            <div className="flex justify-between items-center border-b pb-3 mb-4">
                <h3 className="text-lg font-semibold">Gestión de Oferta Académica</h3>
                 <SettingsToggle 
                    label="Activar módulo" 
                    enabled={isOfferEnabled} 
                    onChange={() => setIsOfferEnabled(!isOfferEnabled)}
                />
            </div>
            
            {isOfferEnabled && (
                <>
                    <div className="space-y-4 mb-6">
                        {offer.map((faculty) => {
                            const activeProgramType = activeTabs[faculty.id] || 'courses';
                            return (
                            <div key={faculty.id} className="p-4 border rounded-lg bg-gray-50/50">
                                <div className="flex justify-between items-center mb-2">
                                    <h4 className="text-md font-semibold text-gray-800">{faculty.name}</h4>
                                    <button onClick={() => handleDeleteFaculty(faculty.id)} className="text-gray-500 hover:text-red-600 p-1">
                                        <Icon name="delete" className="text-base" />
                                    </button>
                                </div>

                                <div className="border-b border-gray-200">
                                    <nav className="-mb-px flex space-x-4 overflow-x-auto" aria-label="Tabs">
                                        {(Object.keys(ProgramTypeLabels) as ProgramType[]).map(type => (
                                            <button
                                                key={type}
                                                onClick={() => setActiveTabs(prev => ({ ...prev, [faculty.id]: type }))}
                                                className={`${
                                                    activeProgramType === type
                                                        ? 'border-teal-500 text-teal-600'
                                                        : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                                                } whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm transition-colors focus:outline-none`}
                                            >
                                                {ProgramTypeLabels[type]}
                                            </button>
                                        ))}
                                    </nav>
                                </div>

                                <div className="mt-4">
                                    <div className="space-y-2">
                                        {faculty[activeProgramType].map(program => (
                                            <div key={program.id} className="flex justify-between items-center bg-white p-2 rounded border text-sm">
                                                <span>{program.name}</span>
                                                <button onClick={() => handleDeleteProgram(faculty.id, activeProgramType, program.id)} className="text-gray-400 hover:text-red-500 p-1">
                                                    <Icon name="close" className="text-xs" />
                                                </button>
                                            </div>
                                        ))}
                                    </div>
                                    <ProgramInput programType={activeProgramType} facultyId={faculty.id} onAddProgram={handleAddProgram} />
                                </div>
                            </div>
                        )})}
                    </div>

                    <form onSubmit={handleAddFaculty} className="flex gap-4 mb-6 p-4 border-t">
                        <input
                            type="text"
                            value={newFacultyName}
                            onChange={e => setNewFacultyName(e.target.value)}
                            placeholder="Nueva facultad"
                            className="flex-grow w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-teal-500 focus:border-teal-500"
                        />
                        <button type="submit" className="bg-blue-600 text-white font-medium py-2 px-4 rounded-lg hover:bg-blue-700">Añadir Facultad</button>
                    </form>
                </>
            )}

            <div className="flex justify-end mt-6">
                <button onClick={handleSave} className="bg-teal-600 text-white font-medium py-2 px-4 rounded-lg hover:bg-teal-700 transition-colors">
                    Guardar Cambios
                </button>
            </div>
        </div>
    );
};

export default AcademicOfferManager;
