
import React, { useState, useEffect, useCallback } from 'react';
import { configService } from '../../services/configService.ts';
import { FieldConfig, EntityType, Contact } from '../../types.ts';
import Icon from '../ui/Icon.tsx';

const SettingsToggle: React.FC<{ label: string; enabled: boolean; onChange: () => void }> = ({ label, enabled, onChange }) => (
     <div className="flex items-center justify-between p-2 rounded-md hover:bg-gray-50">
        <span className="text-sm font-medium text-gray-700">{label}</span>
        <button
            type="button"
            onClick={onChange}
            className={`${enabled ? 'bg-teal-600' : 'bg-gray-200'} relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500`}
        >
            <span className={`${enabled ? 'translate-x-6' : 'translate-x-1'} inline-block w-4 h-4 transform bg-white rounded-full transition-transform`} />
        </button>
    </div>
);

const EntityQuickCreateConfig: React.FC<{ entity: EntityType; config: {is_visible: boolean; required_fields: string[]}; allFields: FieldConfig[]; onConfigChange: (newConfig: any) => void; }> = 
({ entity, config, allFields, onConfigChange }) => {

    const handleVisibilityToggle = () => {
        onConfigChange({ ...config, is_visible: !config.is_visible });
    };

    const handleFieldToggle = (fieldKey: string) => {
        const newFields = config.required_fields.includes(fieldKey)
            ? config.required_fields.filter(f => f !== fieldKey)
            : [...config.required_fields, fieldKey];
        onConfigChange({ ...config, required_fields: newFields });
    };

    return (
        <div>
            <h4 className="text-md font-semibold text-gray-800 capitalize mb-3">
                {entity === 'client' ? 'Clientes' : 'Prospectos'}
            </h4>
            <div className="border rounded-md p-4 space-y-4">
                <SettingsToggle 
                    label="Habilitar Creación Rápida"
                    enabled={config.is_visible}
                    onChange={handleVisibilityToggle}
                />
                <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-700 block">Campos Requeridos:</label>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                        {allFields.map(field => (
                             <label key={field.key} className="flex items-center space-x-2 p-2 rounded-md hover:bg-gray-50 text-sm">
                                <input
                                    type="checkbox"
                                    className="h-4 w-4 rounded border-gray-300 text-teal-600 focus:ring-teal-500"
                                    checked={config.required_fields.includes(field.key)}
                                    onChange={() => handleFieldToggle(field.key)}
                                />
                                <span className="text-gray-700">{field.label}</span>
                            </label>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    )
}

const QuickCreateManager: React.FC<{ 
    onSaveSuccess: (message: string) => void;
    showSaveConfirmation: (onConfirm: () => Promise<void>) => void;
}> = ({ onSaveSuccess, showSaveConfirmation }) => {
    const [config, setConfig] = useState<any>(null);
    const [allClientFields, setAllClientFields] = useState<FieldConfig[]>([]);
    const [allProspectFields, setAllProspectFields] = useState<FieldConfig[]>([]);

    const fetchConfig = useCallback(async () => {
        const qcConfig = await configService.getQuickCreateConfig();
        setConfig(qcConfig);
        const clientFields = await configService.getFieldConfig('client');
        const prospectFields = await configService.getFieldConfig('prospect');
        // Filter out fields that are not suitable for a creation form
        const filterFields = (f: FieldConfig) => !['id', 'creation_date', 'last_contact', 'owner', 'owner_id'].includes(f.key);
        setAllClientFields(clientFields.filter(filterFields));
        setAllProspectFields(prospectFields.filter(filterFields));
    }, []);

    useEffect(() => {
        fetchConfig();
    }, [fetchConfig]);

    const handleConfigChange = (entity: EntityType, newEntityConfig: any) => {
        setConfig((prev: any) => ({
            ...prev,
            [entity]: newEntityConfig,
        }));
    };
    
    const handleSave = async () => {
        if (config) {
            showSaveConfirmation(async () => {
                await configService.updateQuickCreateConfig(config);
                onSaveSuccess('Configuración de creación rápida guardada.');
            });
        }
    };

    if (!config) {
        return <div className="bg-white rounded-lg shadow p-6">Cargando...</div>;
    }

    return (
        <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-xl font-semibold mb-4 border-b pb-3">Gestión de Creación Rápida</h2>
            <p className="text-sm text-gray-600 mb-6">Habilita un formulario simplificado en las vistas de Clientes y Prospectos para añadir nuevos contactos rápidamente. Selecciona los campos que deseas que aparezcan en este formulario.</p>
            <div className="space-y-6">
                <EntityQuickCreateConfig 
                    entity="client"
                    config={config.client}
                    allFields={allClientFields}
                    onConfigChange={(newConf) => handleConfigChange('client', newConf)}
                />
                 <EntityQuickCreateConfig 
                    entity="prospect"
                    config={config.prospect}
                    allFields={allProspectFields}
                    onConfigChange={(newConf) => handleConfigChange('prospect', newConf)}
                />
            </div>
            <div className="flex justify-end mt-6">
                <button onClick={handleSave} className="bg-teal-600 text-white font-medium py-2 px-4 rounded-lg hover:bg-teal-700 transition-colors">
                    Guardar Cambios
                </button>
            </div>
        </div>
    );
};

export default QuickCreateManager;