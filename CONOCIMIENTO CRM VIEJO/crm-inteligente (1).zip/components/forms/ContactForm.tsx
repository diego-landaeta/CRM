import React, { useState, useEffect, useMemo, useCallback } from 'react';
import Icon from '../ui/Icon.tsx';
import FormInput from '../ui/FormInput.tsx';
import FormSelect from '../ui/FormSelect.tsx';
import FormCombobox from '../ui/FormCombobox.tsx';
import DuplicateContactModal from '../ui/DuplicateContactModal.tsx';
import { ORIGINS } from '../../constants.ts';
import { dataService } from '../../services/dataService.ts';
import { configService } from '../../services/configService.ts';
import { 
    Client, Prospect, 
    ClientDataForCreate, ProspectDataForCreate, 
    Installment, AcademicOffer, ProgramType, 
    ProgramTypeLabels, Json, ClientUpdate, ProspectUpdate, EntityType 
} from '../../types.ts';
import { useCurrency } from '../../contexts/CurrencyContext.tsx';

interface ContactFormProps {
    entityType: EntityType;
    initialData?: Client | Prospect | null;
    onCancel: () => void;
    onSave: () => void;
}

const ContactForm: React.FC<ContactFormProps> = ({ entityType, initialData = null, onCancel, onSave }) => {
    const isEditMode = !!initialData;
    const [formData, setFormData] = useState<any>({});
    
    // Config states
    const [coordinators, setCoordinators] = useState<string[]>([]);
    const [statuses, setStatuses] = useState<string[]>([]);
    const [countries, setCountries] = useState<string[]>([]);
    const [fieldLabels, setFieldLabels] = useState<Record<string, string>>({});
    const [isAcademicOfferEnabled, setIsAcademicOfferEnabled] = useState(true);
    const [academicOffer, setAcademicOffer] = useState<AcademicOffer>([]);
    
    // Hierarchical program selection states
    const [selectedFaculty, setSelectedFaculty] = useState('');
    const [selectedProgramType, setSelectedProgramType] = useState<ProgramType | ''>('');
    
    // UI states
    const [error, setError] = useState('');
    const [duplicateInfo, setDuplicateInfo] = useState<{ existingContact: Client | Prospect; type: 'client' | 'prospect' } | null>(null);
    const { currency, formatCurrency } = useCurrency();
    const currencySymbol = useMemo(() => (currency === 'USD' ? '$' : '€'), [currency]);
    
    const pageTitle = `${isEditMode ? 'Editar' : 'Añadir'} ${entityType === 'client' ? 'Cliente' : 'Prospecto'}`;
    const pageSubtitle = isEditMode 
        ? `Actualiza los datos de ${initialData?.name}.`
        : `Completa los datos para agregar un nuevo ${entityType === 'client' ? 'cliente' : 'prospecto'}.`;

    const fetchConfig = useCallback(async () => {
        const [
            coords,
            entityStatuses,
            countryList,
            fieldConfig,
            academicConfig,
            offerData
        ] = await Promise.all([
            configService.getCoordinators(),
            entityType === 'client' ? configService.getClientStatuses() : configService.getProspectStatuses(),
            configService.getCountries(),
            configService.getFieldConfig(entityType),
            configService.getAcademicOfferConfig(),
            configService.getAcademicOffer()
        ]);

        setCoordinators(coords);
        setStatuses(entityStatuses);
        setCountries(countryList);
        setIsAcademicOfferEnabled(academicConfig.is_enabled);
        setAcademicOffer(offerData);
        
        const labels = fieldConfig.reduce((acc, field) => {
            acc[field.key] = field.label;
            return acc;
        }, {} as Record<string, string>);
        setFieldLabels(labels);
    }, [entityType]);

    useEffect(() => {
        fetchConfig();
        window.addEventListener('config_updated', fetchConfig);
        return () => window.removeEventListener('config_updated', fetchConfig);
    }, [fetchConfig]);

    useEffect(() => {
        const defaultData = {
            name: '', email: '', phone: '', program: '', stage: '', estimated_value: 0,
            next_contact: '', owner: 'Auto Asignado', notes: '', country: '', origin: '', coordinator: '',
            payment_type: 'Pago Único', installments_total: 1, installment_details: [], single_payment_method: ''
        };
        const data = isEditMode ? { ...initialData } : defaultData;
        if (isEditMode && entityType === 'client') {
             (data as any).installment_details = ((initialData as Client)?.installment_details as unknown as Installment[] | null) || [];
             (data as any).payment_type = (initialData as Client)?.payment_type || 'Pago Único';
             (data as any).installments_total = (initialData as Client)?.installments_total || 1;
             (data as any).single_payment_method = (initialData as Client)?.single_payment_method || '';
        }
        setFormData(data);
    }, [initialData, isEditMode, entityType]);

    useEffect(() => {
        if (formData?.program && academicOffer.length > 0) {
            for (const faculty of academicOffer) {
                for (const type of Object.keys(ProgramTypeLabels) as ProgramType[]) {
                    if (faculty[type]?.some(p => p.name === formData.program)) {
                        setSelectedFaculty(faculty.name);
                        setSelectedProgramType(type);
                        return; // Exit once found
                    }
                }
            }
        }
    }, [formData?.program, academicOffer]);

    useEffect(() => {
        if (!formData?.country) return;
        const fetchCoordinator = async () => {
            const coordinator = await configService.getCoordinatorForCountry(formData.country);
            if (coordinator) {
                setFormData(prev => ({...prev, coordinator: coordinator }));
            }
        };
        fetchCoordinator();
    }, [formData?.country]);
    
    useEffect(() => {
        if (entityType !== 'client' || formData?.payment_type !== 'Cuotas') return;
        
        const numInstallments = parseInt(formData.installments_total, 10) || 1;
        const currentInstallments = formData.installment_details || [];
        if (currentInstallments.length !== numInstallments) {
            const newInstallments = Array.from({ length: numInstallments }, (_, i) => 
                currentInstallments[i] || { amount: 0, dueDate: '', status: 'Pendiente', paymentMethod: '' }
            );
            setFormData(prev => ({ ...prev, installment_details: newInstallments }));
        }
    }, [formData?.payment_type, formData?.installments_total, entityType]);


    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleComboboxChange = (name: string, value: string) => {
        if (name === 'faculty') {
            setSelectedFaculty(value);
            setSelectedProgramType('');
            setFormData(prev => ({ ...prev, program: '' }));
        } else if (name === 'programType') {
            const typeKey = (Object.entries(ProgramTypeLabels) as [ProgramType, string][]).find(
                ([_key, label]) => label === value
            )?.[0];
            setSelectedProgramType(typeKey || '');
            setFormData(prev => ({ ...prev, program: '' }));
        } else {
            setFormData(prev => ({ ...prev, [name]: value }));
        }
    };
    
    const handleInstallmentsChange = (index: number, field: keyof Installment, value: string | number) => {
        const updatedInstallments = [...(formData.installment_details || [])];
        (updatedInstallments[index] as any)[field] = value;
        setFormData(prev => ({...prev, installment_details: updatedInstallments}));
    };

    const proceedWithSave = async () => {
        try {
            // Ensure dynamic fields exist before saving
            if (formData.coordinator) await configService.ensureCoordinatorExists(formData.coordinator);
            if (formData.stage) {
                if (entityType === 'client') await configService.ensureClientStageExists(formData.stage);
                else await configService.ensureProspectStageExists(formData.stage);
            }
            if (isAcademicOfferEnabled && selectedFaculty && selectedProgramType && formData.program) {
                const programTypeLabel = ProgramTypeLabels[selectedProgramType];
                await configService.ensureAcademicProgramExists(selectedFaculty, programTypeLabel, formData.program);
            }
            
            // Prepare payload
            const value = parseFloat(formData.estimated_value) || 0;
            
            if (entityType === 'client') {
                const installmentsPaid = (formData.installment_details || []).filter((i: Installment) => i.status === 'Pagado').length;
                const clientPayload = {
                    ...formData,
                    estimated_value: value,
                    payment_type: formData.payment_type,
                    installments_total: formData.payment_type === 'Cuotas' ? parseInt(formData.installments_total) : null,
                    installments_paid: formData.payment_type === 'Cuotas' ? installmentsPaid : null,
                    installment_details: formData.payment_type === 'Cuotas' ? formData.installment_details as Json : null,
                    single_payment_method: formData.payment_type === 'Pago Único' ? formData.single_payment_method : null,
                };
                isEditMode ? await dataService.updateClient(clientPayload as ClientUpdate) : await dataService.addClient(clientPayload as ClientDataForCreate);
            } else {
                const prospectPayload = {
                    ...formData,
                    estimated_value: value
                };
                isEditMode ? await dataService.updateProspect(prospectPayload as ProspectUpdate) : await dataService.addProspect(prospectPayload as ProspectDataForCreate);
            }
            onSave();
        } catch (err: any) {
            setError(err.message);
        }
    };
    
    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');

        // Duplicate check is only needed on creation or if email has changed on edit
        if (!isEditMode || formData.email !== initialData?.email) {
            const duplicate = await dataService.findContactByEmail(formData.email);
            if (duplicate) {
                setDuplicateInfo({ existingContact: duplicate.contact, type: duplicate.type });
                return;
            }
        }
        await proceedWithSave();
    };
    
    const handleOverwrite = async () => {
        if (!duplicateInfo) return;
        setError('');
        try {
            if (entityType === 'client') {
                 await dataService.deleteProspect(duplicateInfo.existingContact.id);
            } else { // Prospect form with existing Prospect
                 await dataService.deleteProspect(duplicateInfo.existingContact.id);
            }
            await proceedWithSave();
            setDuplicateInfo(null);
        } catch (e: any) {
            setError(e.message);
            setDuplicateInfo(null);
        }
    };

    // Derived values for rendering
    const facultyNames = useMemo(() => academicOffer.map(f => f.name), [academicOffer]);
    const availableProgramTypes = useMemo(() => {
        if (!selectedFaculty) return [];
        const faculty = academicOffer.find(f => f.name === selectedFaculty);
        return faculty ? (Object.keys(ProgramTypeLabels) as ProgramType[]).filter(type => faculty[type] && faculty[type].length > 0) : [];
    }, [selectedFaculty, academicOffer]);
    const availablePrograms = useMemo(() => {
        if (!selectedFaculty || !selectedProgramType) return [];
        const faculty = academicOffer.find(f => f.name === selectedFaculty);
        return faculty ? faculty[selectedProgramType].map(p => p.name) : [];
    }, [selectedFaculty, selectedProgramType, academicOffer]);
    
    if (Object.keys(formData).length === 0) {
        return <div className="p-8 text-center">Cargando datos del formulario...</div>
    }

    return (
        <div className="p-4 sm:p-8 overflow-y-auto">
            <div className="bg-white p-8 rounded-lg shadow-md max-w-4xl mx-auto">
                <header className="mb-8">
                    <h1 className="text-3xl font-semibold text-gray-800">{pageTitle}</h1>
                    <p className="text-gray-600">{pageSubtitle}</p>
                </header>

                <form onSubmit={handleSubmit}>
                    <h3 className="text-lg font-semibold text-gray-700 border-b pb-2 mb-4">Información de Contacto</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                        <FormInput label={fieldLabels.name || "Nombre Completo"} id="name" name="name" placeholder="Ej: Juan Pérez" required value={formData.name || ''} onChange={handleChange} />
                        <FormInput label={fieldLabels.email || "Email"} id="email" name="email" type="email" placeholder="Ej: juan.perez@example.com" value={formData.email || ''} onChange={handleChange} />
                        <FormInput label={fieldLabels.phone || "Teléfono"} id="phone" name="phone" placeholder="Ej: +52 55 1234 5678" type="tel" value={formData.phone || ''} onChange={handleChange} />
                        <FormCombobox label={fieldLabels.country || "País"} name="country" options={countries} value={formData.country || ''} onChange={handleComboboxChange} placeholder="Selecciona país..."/>
                        <FormCombobox label={fieldLabels.coordinator || "Coordinadora"} name="coordinator" options={coordinators} value={formData.coordinator || ''} onChange={handleComboboxChange} placeholder="Selecciona o crea coordinadora..."/>
                        <FormCombobox label={fieldLabels.origin || "Origen"} name="origin" options={ORIGINS} value={formData.origin || ''} onChange={handleComboboxChange} placeholder="Selecciona origen..."/>
                    </div>

                    <h3 className="text-lg font-semibold text-gray-700 border-b pb-2 mb-4 mt-8">Detalles de Venta y Seguimiento</h3>
                     <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                        {isAcademicOfferEnabled && (
                            <div className="md:col-span-2">
                                <label className="block text-sm font-medium text-gray-700 mb-2">{fieldLabels.program || "Oferta Académica"}</label>
                                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 p-4 border rounded-lg bg-gray-50/50">
                                    <FormCombobox label="Facultad" name="faculty" options={facultyNames} value={selectedFaculty} onChange={handleComboboxChange} placeholder="Selecciona o crea..."/>
                                    {selectedFaculty && <FormCombobox label="Tipo de Programa" name="programType" options={availableProgramTypes.map(key => ProgramTypeLabels[key])} value={selectedProgramType ? ProgramTypeLabels[selectedProgramType] : ''} onChange={handleComboboxChange} placeholder="Selecciona tipo..."/>}
                                    {selectedFaculty && selectedProgramType && <FormCombobox label="Programa Específico" name="program" options={availablePrograms} value={formData.program} onChange={handleComboboxChange} placeholder="Busca o crea programa..."/>}
                                </div>
                            </div>
                        )}
                        <FormCombobox label={fieldLabels.stage || "Etapa"} name="stage" options={statuses} required value={formData.stage || ''} onChange={handleComboboxChange} placeholder="Selecciona o crea etapa..."/>
                        <FormInput label={fieldLabels.next_contact || "Fecha Próximo Contacto"} id="next_contact" name="next_contact" type="date" placeholder="" value={formData.next_contact?.split('T')[0] || ''} onChange={handleChange} />
                    </div>

                    {entityType === 'client' && (
                        <>
                            <h3 className="text-lg font-semibold text-gray-700 border-b pb-2 mb-4 mt-8">Información de Facturación</h3>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                                <FormInput label={`${fieldLabels.estimated_value || "Valor Total de Venta"} (${currencySymbol})`} id="estimated_value" name="estimated_value" type="number" placeholder="Ej: 1500" value={formData.estimated_value || 0} onChange={handleChange}/>
                                <FormSelect label={fieldLabels.payment_type || "Tipo de Pago"} id="payment_type" name="payment_type" options={['Pago Único', 'Cuotas']} value={formData.payment_type || 'Pago Único'} onChange={handleChange}/>
                                {formData.payment_type === 'Pago Único' && (
                                    <FormInput label="Método de Pago" id="single_payment_method" name="single_payment_method" type="text" placeholder="Ej: Tarjeta de Crédito" value={formData.single_payment_method || ''} onChange={handleChange}/>
                                )}
                            </div>
                            
                            {formData.payment_type === 'Cuotas' && (
                                <div className="p-4 bg-gray-50 rounded-lg border">
                                    <h4 className="text-md font-semibold text-gray-600 mb-4">Detalle de Cuotas</h4>
                                    <FormSelect label={fieldLabels.installments_total || "Número de Cuotas"} id="installments_total" name="installments_total" options={Array.from({length: 15}, (_, i) => i + 1)} value={formData.installments_total || 1} onChange={handleChange}/>
                                    <div className="space-y-4 mt-4">
                                        {(formData.installment_details || []).map((inst: Installment, index: number) => (
                                            <div key={index} className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end p-2 border-b">
                                                <div><p className="font-medium text-sm">Cuota {index + 1}</p></div>
                                                <FormInput label="Monto" id={`inst_amount_${index}`} name={`inst_amount_${index}`} type="number" placeholder="Monto" value={inst.amount || 0} onChange={(e) => handleInstallmentsChange(index, 'amount', parseFloat(e.target.value))}/>
                                                <FormInput label="Vencimiento" id={`inst_due_${index}`} name={`inst_due_${index}`} type="date" placeholder="" value={inst.dueDate?.split('T')[0] || ''} onChange={(e) => handleInstallmentsChange(index, 'dueDate', e.target.value)}/>
                                                <div className="md:col-span-3">
                                                    <FormInput label="Método de Pago" id={`inst_method_${index}`} name={`inst_method_${index}`} type="text" placeholder="Ej: Transferencia" value={inst.paymentMethod || ''} onChange={(e) => handleInstallmentsChange(index, 'paymentMethod', e.target.value)}/>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            )}
                        </>
                    )}
                    
                     {entityType === 'prospect' && (
                         <div className="mb-6">
                            <FormInput label={`${fieldLabels.estimated_value || "Valor Estimado"} (${currencySymbol})`} id="estimated_value" name="estimated_value" type="number" placeholder="Ej: 25000" value={formData.estimated_value || 0} onChange={handleChange} />
                         </div>
                     )}

                    <div className="my-6">
                        <label className="block text-sm font-medium text-gray-700 mb-1" htmlFor="notes">{fieldLabels.notes || "Notas / Intereses"}</label>
                        <textarea className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-teal-500 focus:border-teal-500 transition" id="notes" name="notes" placeholder="Añadir notas adicionales..." rows={4} value={formData.notes || ''} onChange={handleChange}></textarea>
                    </div>
                   
                    {error && (
                        <div className="my-4 p-3 bg-red-100 text-red-700 text-sm rounded-lg text-center">{error}</div>
                    )}

                    <div className="flex justify-end space-x-4">
                        <button onClick={onCancel} className="px-6 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500 transition" type="button">Cancelar</button>
                        <button className="px-6 py-2 bg-teal-600 text-white rounded-lg hover:bg-teal-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500 transition" type="submit">Guardar Cambios</button>
                    </div>
                </form>
            </div>
            <DuplicateContactModal
                isOpen={!!duplicateInfo}
                onClose={() => setDuplicateInfo(null)}
                onOverwrite={handleOverwrite}
                existingContact={duplicateInfo?.existingContact || null}
                newContactData={formData}
                entityType={duplicateInfo?.type || null}
                allowOverwrite={entityType === 'client' || (entityType === 'prospect' && duplicateInfo?.type === 'prospect')}
                actionType={duplicateInfo?.type === 'prospect' ? 'convert' : 'overwrite'}
            />
        </div>
    );
};

export default ContactForm;
