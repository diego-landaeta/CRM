
import React, { useState, useEffect, useCallback } from 'react';
import Icon from '../ui/Icon.tsx';
import { configService } from '../../services/configService.ts';
import { dataService } from '../../services/dataService.ts';
import { EntityType, FieldConfig, Contact, ClientDataForCreate, ProspectDataForCreate, Client, Prospect, ClientUpdate, ProspectUpdate } from '../../types.ts';
import FormCombobox from '../ui/FormCombobox.tsx';
import DuplicateContactModal from '../ui/DuplicateContactModal.tsx';

interface QuickCreateModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: () => void;
    entityType: EntityType;
}

const FormInput: React.FC<{ label: string; name: string; type?: string; required?: boolean; value: string; onChange: (e: React.ChangeEvent<HTMLInputElement>) => void; }> = 
({ label, name, type = 'text', required = true, value, onChange }) => (
    <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
        <input className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-teal-500 focus:border-teal-500 transition" name={name} type={type} required={required} value={value} onChange={onChange} />
    </div>
);

const QuickCreateModal: React.FC<QuickCreateModalProps> = ({ isOpen, onClose, onSave, entityType }) => {
    const [formData, setFormData] = useState<Partial<Contact>>({});
    const [requiredFields, setRequiredFields] = useState<FieldConfig[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');
    const [selectOptions, setSelectOptions] = useState<Record<string, string[]>>({});
    const [duplicateInfo, setDuplicateInfo] = useState<{ existingContact: Client | Prospect; type: 'client' | 'prospect' } | null>(null);

    const fetchConfig = useCallback(async () => {
        if (!isOpen) return;
        setIsLoading(true);
        const qcConfig = await configService.getQuickCreateConfig();
        const allFields = await configService.getFieldConfig(entityType);
        
        const rFields = allFields.filter(f => qcConfig[entityType].required_fields.includes(f.key));
        setRequiredFields(rFields);
        
        const options: Record<string, string[]> = {};
        if (rFields.some(f => f.key === 'stage')) {
            options.stage = entityType === 'client' ? await configService.getClientStatuses() : await configService.getProspectStatuses();
        }
        if (rFields.some(f => f.key === 'program')) {
            options.program = await configService.getAllProgramNames();
        }
        if (rFields.some(f => f.key === 'coordinator')) {
            options.coordinator = await configService.getCoordinators();
        }
        setSelectOptions(options);

        const initialFormData: Partial<Contact> = {};
        rFields.forEach(f => { (initialFormData as any)[f.key] = ''; });
        setFormData(initialFormData);
        setError('');
        setDuplicateInfo(null);
        setIsLoading(false);
    }, [isOpen, entityType]);

    useEffect(() => {
        fetchConfig();
        window.addEventListener('config_updated', fetchConfig);
        return () => window.removeEventListener('config_updated', fetchConfig);
    }, [fetchConfig]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
    };

    const handleComboboxChange = (name: string, value: string) => {
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');

        const email = (formData as any).email;
        const duplicate = await dataService.findContactByEmail(email);

        if (duplicate) {
            setDuplicateInfo({ existingContact: duplicate.contact, type: duplicate.type });
            return;
        }

        await proceedWithSave();
    };

    const handleOverwrite = async () => {
        if (!duplicateInfo) return;
        const { existingContact: contact, type } = duplicateInfo;

        try {
            if (entityType === 'client') {
                 const clientData = {
                    name: formData.name || '',
                    email: formData.email || '',
                    stage: formData.stage || '',
                    phone: formData.phone || null,
                    program: formData.program || '',
                    estimated_value: Number(formData.estimated_value) || 0,
                    next_contact: formData.next_contact || null,
                    country: formData.country || '',
                    coordinator: formData.coordinator || '',
                    payment_type: 'Pago Único',
                    installments_total: null,
                    installments_paid: null,
                    installment_details: null,
                    single_payment_method: null,
                };
                if (type === 'client') {
                    await dataService.updateClient({ ...clientData, id: contact.id });
                } else { // Found prospect, convert to client
                    await dataService.deleteProspect(contact.id);
                    await dataService.addClient({ ...clientData, origin: 'Creación Rápida', owner: 'Auto Asignado', notes: 'Creado via Creación Rápida.' });
                }
            } else { // entityType is 'prospect'
                if (type === 'prospect') {
                    const prospectPayload: ProspectUpdate = {
                        id: contact.id,
                        name: formData.name,
                        email: formData.email,
                        stage: formData.stage,
                        phone: formData.phone,
                        program: formData.program,
                        estimated_value: Number(formData.estimated_value),
                        next_contact: formData.next_contact,
                        country: formData.country,
                        coordinator: formData.coordinator,
                    };
                    await dataService.updateProspect(prospectPayload);
                } else { // Found client, should not happen due to modal logic
                    throw new Error("Cannot overwrite a client with a prospect.");
                }
            }
            onSave();
        } catch (err: any) {
            setError(err.message || 'Error al sobrescribir.');
        } finally {
            setDuplicateInfo(null);
        }
    };
    
    const proceedWithSave = async () => {
        try {
            if ((formData as any).coordinator) await configService.ensureCoordinatorExists((formData as any).coordinator);
            if ((formData as any).stage) {
                if (entityType === 'client') await configService.ensureClientStageExists((formData as any).stage);
                else await configService.ensureProspectStageExists((formData as any).stage);
            }
            
            if (entityType === 'client') {
                const dataToSave: ClientDataForCreate = {
                    name: formData.name || '',
                    email: formData.email || '',
                    stage: formData.stage || '',
                    phone: formData.phone || null,
                    program: formData.program || '',
                    estimated_value: Number(formData.estimated_value) || 0,
                    next_contact: formData.next_contact || null,
                    owner: 'Auto Asignado',
                    notes: 'Creado via Creación Rápida.',
                    country: formData.country || '',
                    origin: 'Creación Rápida',
                    coordinator: formData.coordinator || '',
                    payment_type: 'Pago Único',
                    installments_total: null,
                    installments_paid: null,
                    installment_details: null,
                    single_payment_method: null,
                };
                 await dataService.addClient(dataToSave);
            } else {
                 const dataToSave: ProspectDataForCreate = {
                    name: formData.name || '',
                    email: formData.email || '',
                    stage: formData.stage || '',
                    phone: formData.phone || null,
                    program: formData.program || '',
                    estimated_value: Number(formData.estimated_value) || 0,
                    next_contact: formData.next_contact || null,
                    owner: 'Auto Asignado',
                    notes: 'Creado via Creación Rápida.',
                    country: formData.country || '',
                    origin: 'Creación Rápida',
                    coordinator: formData.coordinator || '',
                };
                await dataService.addProspect(dataToSave);
            }
            onSave();
        } catch (err: any) {
            setError(err.message || 'Hubo un error al guardar.');
        }
    }


    if (!isOpen) return null;

    const renderField = (field: FieldConfig) => {
        const { key, label } = field;
        const value = (formData as any)[key] || '';

        switch (key) {
            case 'stage':
            case 'program':
            case 'coordinator':
                return (
                    <FormCombobox key={key} label={label} name={key} options={selectOptions[key] || []} value={String(value)}
                        onChange={handleComboboxChange} placeholder="Selecciona o crea..." />
                );
            case 'estimated_value':
                return <FormInput key={key} label={label} name={key} type="number" value={String(value)} onChange={handleChange} />;
            default:
                return <FormInput key={key} label={label} name={key} type={key === 'email' ? 'email' : 'text'} value={String(value)} onChange={handleChange} />;
        }
    };

    const allowOverwrite = entityType === 'client' || (entityType === 'prospect' && duplicateInfo?.type === 'prospect');
    const actionType = (entityType === 'client' && duplicateInfo?.type === 'prospect') ? 'convert' : 'overwrite';

    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 flex justify-center items-center z-50 p-4">
            <div className="bg-white rounded-xl shadow-2xl p-6 sm:p-8 max-w-lg w-full transform transition-all animate-scale-in">
                <header className="flex justify-between items-center mb-4">
                    <h3 className="text-xl font-bold text-gray-900">Creación Rápida de {entityType === 'client' ? 'Cliente' : 'Prospecto'}</h3>
                    <button onClick={onClose} className="text-gray-500 hover:text-gray-800"><Icon name="close" /></button>
                </header>
                {isLoading ? <p>Cargando configuración...</p> : (
                    <form onSubmit={handleSubmit}>
                        <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-2">
                           {requiredFields.map(field => renderField(field))}
                        </div>
                         {error && (
                            <div className="mt-4 p-3 bg-red-100 text-red-700 text-sm rounded-lg text-center">
                                {error}
                            </div>
                        )}
                        <div className="mt-6 flex justify-end gap-3">
                            <button type="button" onClick={onClose} className="px-4 py-2 rounded-lg text-gray-700 border border-gray-300 hover:bg-gray-50">Cancelar</button>
                            <button type="submit" className="px-4 py-2 rounded-lg text-white bg-teal-600 hover:bg-teal-700">Guardar</button>
                        </div>
                    </form>
                )}
            </div>
            {duplicateInfo &&
                <DuplicateContactModal
                    isOpen={!!duplicateInfo}
                    onClose={() => setDuplicateInfo(null)}
                    onOverwrite={handleOverwrite}
                    existingContact={duplicateInfo.existingContact}
                    newContactData={formData}
                    entityType={duplicateInfo.type}
                    allowOverwrite={allowOverwrite}
                    actionType={actionType}
                />
            }
             <style>{`
              @keyframes scale-in {
                from { transform: scale(0.95); opacity: 0; }
                to { transform: scale(1); opacity: 1; }
              }
              .animate-scale-in {
                animation: scale-in 0.2s ease-out forwards;
              }
            `}</style>
        </div>
    );
};

export default QuickCreateModal;