import React, { useState, useEffect } from 'react';
import Icon from '../ui/Icon.tsx';
import { Page, NavItem, User } from '../../types.ts';
import { NAV_ITEMS } from '../../constants.ts';

interface SidebarProps {
  currentUser: User;
  currentPage: Page;
  onPageChange: (page: Page) => void;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  onOpenCreatorsModal: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentUser, currentPage, onPageChange, isOpen, setIsOpen, onOpenCreatorsModal }) => {
  const [openMenus, setOpenMenus] = useState<Record<string, boolean>>({});

  const userRole = currentUser.profile?.role;
  const canSeeConfig = userRole === 'platform_admin' || userRole === 'crm_admin';

  const navItems = NAV_ITEMS.filter(item => {
    if (item.id === 'config-parent') {
        return canSeeConfig;
    }
    return true;
  });

  useEffect(() => {
    // Open the parent menu of the current page on initial load or page change
    const parent = navItems.find(item => item.subItems?.some(sub => sub.id === currentPage));
    if (parent && !openMenus[parent.id]) {
      setOpenMenus(prev => ({ ...prev, [parent.id]: true }));
    }
  }, [currentPage, navItems]);

  const handleParentClick = (id: string) => {
    setOpenMenus(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const NavLink: React.FC<{ item: NavItem, isSubItem?: boolean }> = ({ item, isSubItem = false }) => {
    const isActive = currentPage === item.id;
    
    if (isSubItem) {
        return (
             <a
                href="#"
                onClick={(e) => {
                  e.preventDefault();
                  onPageChange(item.id as Page);
                }}
                className={`flex items-center w-full px-3 py-2 rounded-lg text-sm transition-all duration-200 ease-in-out ${
                  isActive
                    ? 'bg-[var(--sidebar-active-bg)] text-[var(--sidebar-active-text)] font-semibold'
                    : 'text-emerald-200 hover:bg-[var(--sidebar-hover-bg)] hover:text-white'
                }`}
              >
                <Icon name={item.icon} className="mr-3 text-base" />
                {item.label}
            </a>
        )
    }

    return (
      <a
        href="#"
        onClick={(e) => {
          e.preventDefault();
          onPageChange(item.id as Page);
        }}
        className={`flex items-center px-4 py-3 rounded-lg transition-all duration-200 ease-in-out ${
          isActive 
            ? 'border-l-4 border-[var(--sidebar-active-border)] bg-[var(--sidebar-active-bg)] text-[var(--sidebar-active-text)] font-semibold' 
            : 'text-emerald-100 hover:bg-[var(--sidebar-hover-bg)] hover:text-white'
        }`}
      >
        <Icon name={item.icon} className={`mr-4 ${isActive ? 'text-[var(--sidebar-active-text)]' : 'text-emerald-300'}`} />
        {item.label}
      </a>
    );
  };
  
  const ParentNav: React.FC<{ item: NavItem }> = ({ item }) => {
      const isParentActive = item.subItems?.some(sub => sub.id === currentPage) ?? false;
      const isMenuOpen = openMenus[item.id] ?? false;

      return (
          <div className="text-sm">
              <button
                  onClick={() => handleParentClick(item.id)}
                  className={`flex items-center justify-between w-full px-4 py-3 rounded-lg transition-all duration-200 ease-in-out ${
                      isParentActive ? 'bg-[var(--sidebar-hover-bg)] text-white font-semibold' : 'text-emerald-100 hover:bg-[var(--sidebar-hover-bg)] hover:text-white'
                  }`}
              >
                  <div className="flex items-center">
                      <Icon name={item.icon} className={`mr-4 ${isParentActive ? 'text-white' : 'text-emerald-300'}`} />
                      <span>{item.label}</span>
                  </div>
                  <Icon name={isMenuOpen ? 'expand_less' : 'expand_more'} className="transition-transform" />
              </button>
              {isMenuOpen && (
                  <div className="pl-6 mt-1 space-y-1">
                      {item.subItems?.map(subItem => <NavLink key={subItem.id} item={subItem} isSubItem />)}
                  </div>
              )}
          </div>
      );
  };


  return (
    <>
        <div 
          className={`fixed inset-0 bg-black/50 z-30 lg:hidden transition-opacity duration-300 ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
          onClick={() => setIsOpen(false)}
        ></div>
        <aside className={`w-64 bg-[var(--sidebar-bg)] text-white flex-col shadow-lg fixed lg:relative lg:translate-x-0 h-full z-40 transition-transform duration-300 ease-in-out ${isOpen ? 'translate-x-0' : '-translate-x-full'} flex`}>
        <div className="p-6 border-b border-emerald-800 flex items-center space-x-3 shrink-0">
          <Icon name="insights" className="text-3xl text-emerald-300" />
          <h1 className="text-2xl font-bold">CRM Inteligente</h1>
        </div>
        <nav className="flex-1 space-y-2 p-4 overflow-y-auto">
          {navItems.map(item => item.subItems ? <ParentNav key={item.id} item={item} /> : <NavLink key={item.id} item={item} />)}
        </nav>
        <div className="p-4 border-t border-emerald-800">
            <button
                onClick={onOpenCreatorsModal}
                className="w-full flex items-center justify-center text-sm text-emerald-300 hover:text-white transition-colors py-2 rounded-lg hover:bg-[var(--sidebar-hover-bg)]"
                aria-label="Ver créditos de los desarrolladores"
            >
                <Icon name="code" className="mr-2" />
                <span>Desarrolladores</span>
            </button>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;