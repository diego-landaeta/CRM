
import React, { useState, useEffect, useRef } from 'react';
import Icon from '../ui/Icon.tsx';
import { User, Page, Notification } from '../../types.ts';

interface HeaderProps {
    currentUser: User;
    onMenuClick: () => void;
    onNavigate: (page: Page) => void;
    onLogout: () => void;
    notifications: Notification[];
    setNotifications: React.Dispatch<React.SetStateAction<Notification[]>>;
    onOpenNovedadesModal: () => void;
}

const Header: React.FC<HeaderProps> = ({ currentUser, onMenuClick, onNavigate, onLogout, notifications, setNotifications, onOpenNovedadesModal }) => {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const notificationsRef = useRef<HTMLDivElement>(null);

  // Close dropdowns on click outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setDropdownOpen(false);
      }
      if (notificationsRef.current && !notificationsRef.current.contains(event.target as Node)) {
        setNotificationsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleBellClick = () => {
    setNotificationsOpen(prev => !prev);
    if (!notificationsOpen) { // Only mark as read when opening
        const readNotifications = notifications.map(n => ({ ...n, read: true }));
        setNotifications(readNotifications);
    }
  };
  
  const hasUnread = notifications.some(n => !n.read);
  
  const userName = currentUser.profile?.full_name || currentUser.email;

  return (
    <header className="bg-[var(--header-bg)] shadow-[0_2px_4px_var(--header-shadow)] p-4 sm:p-6 flex justify-between items-center sticky top-0 z-20 shrink-0">
      <div className="flex items-center">
        <button onClick={onMenuClick} className="lg:hidden text-[var(--text-secondary)] mr-4">
            <Icon name="menu" />
        </button>
         <div className="relative hidden md:block">
          <input
            className="border border-[var(--input-border)] rounded-full py-2.5 px-4 pl-10 text-sm focus:outline-none focus:ring-2 focus:ring-[var(--input-focus-ring)] focus:border-transparent transition-all duration-200 ease-in-out w-48 sm:w-64"
            placeholder="Buscar prospectos, reportes..."
            type="text"
          />
          <Icon name="search" className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
        </div>
      </div>
      <div className="flex items-center space-x-4 sm:space-x-6">
        <div className="relative" ref={notificationsRef}>
            <button onClick={handleBellClick} className="text-[var(--text-secondary)] hover:text-[var(--text-accent)] relative transition-colors duration-200">
                <Icon name="notifications" className="text-2xl" />
                {hasUnread && (
                    <span className="absolute top-0 right-0 block h-2.5 w-2.5 rounded-full bg-red-500 border-2 border-white"></span>
                )}
            </button>
            {notificationsOpen && (
                <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white rounded-lg shadow-xl z-50 border border-gray-200/80 animate-fade-in-down">
                    <div className="p-4 font-semibold text-gray-800 border-b">Notificaciones</div>
                    <ul className="max-h-96 overflow-y-auto">
                        {notifications.length > 0 ? (
                            notifications.map(notification => (
                                <li key={notification.id} 
                                    className="border-b last:border-b-0 hover:bg-gray-50/50 cursor-pointer"
                                    onClick={() => {
                                        if (notification.id === 'update-1') {
                                            onOpenNovedadesModal();
                                            setNotificationsOpen(false);
                                        }
                                    }}
                                >
                                    <div className="p-4 flex items-start gap-3">
                                        <div className={`mt-1 flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${notification.iconColor.replace('text-', 'bg-').replace('500', '100')}`}>
                                            <Icon name={notification.icon} className={`${notification.iconColor} text-lg`} />
                                        </div>
                                        <div>
                                            <p className="text-sm font-semibold text-gray-800">{notification.title}</p>
                                            <p className="text-sm text-gray-600">{notification.message}</p>
                                            <p className="text-xs text-gray-400 mt-1">{notification.sender} &middot; {new Date(notification.timestamp).toLocaleString()}</p>
                                        </div>
                                    </div>
                                </li>
                            ))
                        ) : (
                            <li className="p-6 text-center text-sm text-gray-500">No tienes notificaciones.</li>
                        )}
                    </ul>
                    <div className="p-2 bg-gray-50/80 rounded-b-lg text-center">
                        <a href="#" onClick={(e) => { e.preventDefault(); onNavigate('Notifications'); setNotificationsOpen(false); }} className="text-sm font-medium text-teal-600 hover:text-teal-800">Ver todas</a>
                    </div>
                </div>
            )}
        </div>


        <div className="relative" ref={dropdownRef}>
            <button 
                onClick={() => setDropdownOpen(!dropdownOpen)}
                className="flex items-center space-x-2 text-[var(--text-secondary)] hover:text-[var(--text-accent)] cursor-pointer transition-colors duration-200"
            >
                <Icon name="account_circle" className="text-3xl" />
                <span className="hidden sm:inline text-sm font-medium">{userName}</span>
                <Icon name={dropdownOpen ? "arrow_drop_up" : "arrow_drop_down"} />
            </button>
            {dropdownOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-50 border border-gray-200 animate-fade-in-down">
                    <a href="#" onClick={(e) => { e.preventDefault(); onNavigate('Configuration'); setDropdownOpen(false); }} className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Configuración</a>
                    <a href="#" onClick={(e) => { e.preventDefault(); onLogout(); setDropdownOpen(false); }} className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Cerrar Sesión</a>
                </div>
            )}
        </div>
      </div>
    </header>
  );
};

export default Header;