import React, { useState, useCallback, useEffect } from 'react';
import Sidebar from './components/layout/Sidebar.tsx';
import Header from './components/layout/Header.tsx';
import Dashboard from './pages/Dashboard.tsx';
import Clients from './pages/Clients.tsx';
import Prospects from './pages/Prospects.tsx';
import Email from './pages/Email.tsx';
import Configuration from './pages/Configuration.tsx';
import Support from './pages/Support.tsx';
import Manual from './pages/Manual.tsx';
import CermiChat from './components/ai/CermiChat.tsx';
import Login from './pages/Login.tsx';
import SignUp from './pages/SignUp.tsx';
import AddClient from './pages/AddClient.tsx';
import AddProspect from './pages/AddProspect.tsx';
import ConvertProspect from './pages/ConvertProspect.tsx';
import EditClient from './pages/EditClient.tsx';
import EditProspect from './pages/EditProspect.tsx';
import Billing from './pages/Billing.tsx';
import Calendar from './pages/Calendar.tsx';
import Statistics from './pages/Statistics.tsx';
import { Page, User, Notification } from './types.ts';
import { authService } from './services/authService.ts';
import InfoModal from './components/ui/InfoModal.tsx';
import PasswordResetModal from './components/ui/PasswordResetModal.tsx';
import CreatorsModal from './components/ui/CreatorsModal.tsx';
import type { AuthChangeEvent, Session } from '@supabase/gotrue-js';
import NotificationsPage from './pages/NotificationsPage.tsx';
import NovedadesModal from './components/ui/NovedadesModal.tsx';
import Roles from './pages/Roles.tsx';


const App: React.FC = () => {
    const [currentUser, setCurrentUser] = useState<User | null>(null);
    const [loadingAuth, setLoadingAuth] = useState(true);
    const [view, setView] = useState<{ page: Page, id: string | null }>({ page: 'Dashboard', id: null });
    const [isCermiChatOpen, setIsCermiChatOpen] = useState(false);
    const [isSidebarOpen, setIsSidebarOpen] = useState(false);
    const [authView, setAuthView] = useState<'login' | 'signup'>('login');
    const [infoModalState, setInfoModalState] = useState({ isOpen: false, title: '', message: '' });
    const [showPasswordResetModal, setShowPasswordResetModal] = useState(false);
    const [isCreatorsModalOpen, setIsCreatorsModalOpen] = useState(false);
    const [isNovedadesModalOpen, setIsNovedadesModalOpen] = useState(false);
    const [notifications, setNotifications] = useState<Notification[]>([
        {
            id: 'update-1',
            title: '¡Nuevas funciones disponibles!',
            message: 'Gestiona flujos de n8n, archiva contactos y administra pagos por cuotas. ¡Explora los cambios!',
            sender: 'Equipo de Desarrollo',
            timestamp: new Date(Date.now() - 1000 * 60 * 5).toISOString(), // 5 mins ago
            read: false,
            icon: 'campaign',
            iconColor: 'text-purple-500'
        },
        {
            id: 'followup-1',
            title: 'Seguimiento pendiente',
            message: 'Contactar a "Ana Gómez" para discutir la propuesta.',
            sender: 'Sistema',
            timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(), // 1 day ago
            read: true,
            icon: 'task_alt',
            iconColor: 'text-blue-500'
        }
    ]);

    const fetchUser = async () => {
      const user = await authService.getUser();
      setCurrentUser(user);
      setLoadingAuth(false);
    };

    useEffect(() => {
        fetchUser(); // Check for an existing session on initial load

        const { data: authListener } = authService.onAuthStateChange(async (event: AuthChangeEvent, session: Session | null) => {
            if (event === 'PASSWORD_RECOVERY') {
                setShowPasswordResetModal(true);
            }
            // On any auth event, re-fetch the user with their profile
            await fetchUser();
        });
    
        return () => {
            authListener?.subscription.unsubscribe();
        };
    }, []);
    
    const handleSignUpSuccess = () => {
        setInfoModalState({
            isOpen: true,
            title: 'Registro Exitoso',
            message: 'Te hemos enviado un correo electrónico para que verifiques tu cuenta. Por favor, revisa tu bandeja de entrada.'
        });
        setAuthView('login');
    };

    const handleLoginSuccess = useCallback(async () => {
        await fetchUser(); // Fetch user with profile on successful login
        setView({ page: 'Dashboard', id: null });
    }, []);

    const handleLogout = useCallback(async () => {
        await authService.logout();
        setCurrentUser(null);
        setAuthView('login');
        setView({ page: 'Dashboard', id: null });
    }, []);
    
    useEffect(() => {
        if (!currentUser) {
            setView({ page: 'Dashboard', id: null });
        }
    }, [currentUser]);

    const handleNavigate = useCallback((page: Page, id: string | null = null) => {
        setView({ page, id });
        if (window.innerWidth < 1024) {
            setIsSidebarOpen(false);
        }
    }, []);
    
    const renderPage = () => {
        switch (view.page) {
            case 'Dashboard':
                return <Dashboard onNavigate={handleNavigate} />;
            case 'Calendar':
                return <Calendar />;
            case 'Clients':
                return <Clients onNavigate={handleNavigate} />;
            case 'Billing':
                return <Billing onNavigate={handleNavigate} />;
            case 'Statistics':
                return <Statistics />;
            case 'Prospects':
                return <Prospects onNavigate={handleNavigate} />;
            case 'Email':
                return <Email />;
            case 'Configuration':
                return <Configuration onNavigate={handleNavigate} currentUser={currentUser!} />;
            case 'Roles':
                return <Roles currentUser={currentUser!} />;
            case 'Manual':
                return <Manual />;
            case 'Support':
                return <Support />;
            case 'AddClient':
                return <AddClient onCancel={() => handleNavigate('Clients')} onSave={() => handleNavigate('Clients')} />;
            case 'EditClient':
                return <EditClient id={view.id!} onCancel={() => handleNavigate('Clients')} onSave={() => handleNavigate('Clients')} />;
            case 'AddProspect':
                return <AddProspect onCancel={() => handleNavigate('Prospects')} onSave={() => handleNavigate('Prospects')} />;
            case 'EditProspect':
                 return <EditProspect id={view.id!} onCancel={() => handleNavigate('Prospects')} onSave={() => handleNavigate('Prospects')} />;
            case 'ConvertProspect':
                 return <ConvertProspect id={view.id!} onCancel={() => handleNavigate('Prospects')} onConvert={() => handleNavigate('Clients')} />;
             case 'Notifications':
                return <NotificationsPage notifications={notifications} setNotifications={setNotifications} />;
            default:
                return <Dashboard onNavigate={handleNavigate} />;
        }
    };

    if (loadingAuth) {
        return (
            <div className="flex h-screen items-center justify-center bg-gray-100">
                <div className="text-xl font-medium text-gray-600">Cargando...</div>
            </div>
        );
    }

    if (!currentUser) {
       return (
         <>
            {authView === 'login' ? (
                <Login onLoginSuccess={handleLoginSuccess} onSwitchToSignUp={() => setAuthView('signup')} />
            ) : (
                <SignUp 
                    onSwitchToLogin={() => setAuthView('login')}
                    onSignUpSuccess={handleSignUpSuccess}
                />
            )}
             <InfoModal 
                isOpen={infoModalState.isOpen}
                onClose={() => setInfoModalState({ isOpen: false, title: '', message: '' })}
                title={infoModalState.title}
                message={infoModalState.message}
            />
        </>
       );
    }

    return (
        <div className="flex h-screen bg-gray-100 overflow-hidden">
            <Sidebar 
                currentUser={currentUser}
                currentPage={view.page} 
                onPageChange={handleNavigate} 
                isOpen={isSidebarOpen} 
                setIsOpen={setIsSidebarOpen} 
                onOpenCreatorsModal={() => setIsCreatorsModalOpen(true)}
            />
            <div className="flex-1 flex flex-col overflow-hidden">
                <Header 
                    currentUser={currentUser} 
                    onMenuClick={() => setIsSidebarOpen(!isSidebarOpen)} 
                    onNavigate={handleNavigate}
                    onLogout={handleLogout}
                    notifications={notifications}
                    setNotifications={setNotifications}
                    onOpenNovedadesModal={() => setIsNovedadesModalOpen(true)}
                />
                <main className="flex-1 overflow-x-hidden overflow-y-auto">
                    {renderPage()}
                </main>
            </div>
            <CermiChat isOpen={isCermiChatOpen} setIsOpen={setIsCermiChatOpen} />
            <PasswordResetModal 
                isOpen={showPasswordResetModal}
                onClose={() => setShowPasswordResetModal(false)}
                onResetSuccess={handleLogout}
            />
            <CreatorsModal 
                isOpen={isCreatorsModalOpen}
                onClose={() => setIsCreatorsModalOpen(false)}
            />
            <NovedadesModal
                isOpen={isNovedadesModalOpen}
                onClose={() => setIsNovedadesModalOpen(false)}
            />
        </div>
    );
};

export default App;