import React, { useState, useEffect, useCallback } from 'react';
import Card from '../components/ui/Card.tsx';
import Icon from '../components/ui/Icon.tsx';
import { dataService } from '../services/dataService.ts';
import { Profile, User, RoleType } from '../types.ts';
import ConfirmationModal from '../components/ui/ConfirmationModal.tsx';
import InfoModal from '../components/ui/InfoModal.tsx';

const ROLE_HIERARCHY: Record<RoleType, number> = {
    platform_admin: 3,
    crm_admin: 2,
    crm_collaborator: 1
};

const ROLE_LABELS: Record<RoleType, string> = {
    platform_admin: "Admin de Plataforma",
    crm_admin: "Admin de CRM",
    crm_collaborator: "Colaborador de CRM",
};


interface RolesProps {
    currentUser: User;
}

const Roles: React.FC<RolesProps> = ({ currentUser }) => {
    const [users, setUsers] = useState<Profile[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [isInviteModalOpen, setIsInviteModalOpen] = useState(false);
    const [inviteUserData, setInviteUserData] = useState<{ email: string; role: RoleType }>({ email: '', role: 'crm_collaborator' });
    const [modalError, setModalError] = useState('');
    const [deleteModalState, setDeleteModalState] = useState<{ isOpen: boolean; user: Profile | null }>({ isOpen: false, user: null });
    const [infoModal, setInfoModal] = useState({ isOpen: false, title: '', message: '', type: 'success' as 'success' | 'error' });
    
    const currentUserRole = currentUser.profile?.role || 'crm_collaborator';
    const currentUserLevel = ROLE_HIERARCHY[currentUserRole];

    const fetchData = useCallback(async () => {
        setIsLoading(true);
        try {
            const usersData = await dataService.getUsers();
            setUsers(usersData);
        } catch (error) {
            console.error("Failed to fetch users:", error);
            showModal('Error de Carga', 'No se pudieron cargar los datos de usuarios.', 'error');
        } finally {
            setIsLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchData();
    }, [fetchData]);

    const showModal = (title: string, message: string, type: 'success' | 'error' = 'success') => {
        setInfoModal({ isOpen: true, title, message, type });
    };
    
    const handleApiError = (error: any, action: string) => {
        const message = error.message.includes('security policy') ? `No tienes permiso para ${action}.` : (error.message || `Ocurrió un error al ${action}.`);
        setModalError(message);
        showModal('Error', message, 'error');
    };

    const handleInviteUser = async (e: React.FormEvent) => {
        e.preventDefault();
        setModalError('');
        if (!inviteUserData.email.trim() || !inviteUserData.role) {
            setModalError('Todos los campos son obligatorios.'); return;
        }
        try {
            await dataService.createInvitation(inviteUserData.email, inviteUserData.role);
            setIsInviteModalOpen(false);
            setInviteUserData({ email: '', role: 'crm_collaborator' });
            showModal('Invitación Registrada', `Se ha enviado una invitación a ${inviteUserData.email}. El usuario deberá registrarse con ese correo para acceder al CRM.`);
        } catch (error: any) {
            handleApiError(error, 'invitar al usuario');
        }
    };
    
    const handleRoleChange = async (userId: string, newRole: RoleType) => {
        try {
            await dataService.updateUserRole(userId, newRole);
            showModal('Rol Actualizado', 'El rol del usuario ha sido actualizado.');
            fetchData();
        } catch (error: any)
        {
            handleApiError(error, 'actualizar el rol');
        }
    };
    
    const handleDeleteUser = async () => {
        if (!deleteModalState.user) return;
        try {
            await dataService.deleteUser(deleteModalState.user.id);
            showModal('Usuario Eliminado', `El usuario "${deleteModalState.user.full_name}" ha sido eliminado del CRM.`);
            fetchData();
        } catch (error: any) {
            handleApiError(error, 'eliminar al usuario');
        } finally {
            setDeleteModalState({ isOpen: false, user: null });
        }
    };
    
    if (isLoading) return <div className="p-6 text-center text-gray-500">Cargando...</div>;

    return (
        <div className="p-4 sm:p-6">
            <Card>
                <div className="flex justify-between items-center flex-wrap gap-4 mb-6">
                    <div>
                        <h2 className="text-2xl font-bold text-gray-800">Gestión de Usuarios y Roles</h2>
                        <p className="text-sm text-gray-500">Invita, elimina y asigna roles a los miembros de tu equipo.</p>
                    </div>
                     <button 
                        onClick={() => setIsInviteModalOpen(true)} 
                        className="bg-teal-600 hover:bg-teal-700 text-white font-medium py-2 px-4 rounded-lg flex items-center shadow-md transition-colors"
                    >
                        <Icon name="person_add" className="mr-2" /> Invitar Usuario
                    </button>
                </div>
                
                 <div className="overflow-x-auto">
                    <table className="w-full text-left">
                        <thead className="text-xs text-gray-500 uppercase bg-gray-50">
                            <tr>
                                <th className="py-3 px-4">Nombre Completo</th>
                                <th className="py-3 px-4">Email</th>
                                <th className="py-3 px-4">Rol Asignado</th>
                                <th className="py-3 px-4 text-center">Acciones</th>
                            </tr>
                        </thead>
                        <tbody className="text-sm text-gray-700">
                            {users.map(user => {
                                const targetUserLevel = ROLE_HIERARCHY[user.role];
                                const canEditUser = currentUserLevel > targetUserLevel || (currentUserLevel === targetUserLevel && currentUser.id !== user.id);
                                const isSelf = currentUser.id === user.id;

                                return (
                                <tr key={user.id} className="border-b hover:bg-gray-50 transition-colors">
                                    <td className="py-3 px-4 font-medium">{user.full_name || '-'}</td>
                                    <td className="py-3 px-4">{user.email}</td>
                                    <td className="py-3 px-4">
                                        <select 
                                            value={user.role} 
                                            onChange={(e) => handleRoleChange(user.id, e.target.value as RoleType)}
                                            disabled={!canEditUser || isSelf}
                                            className="w-full sm:w-auto bg-transparent border border-gray-300 rounded-md py-1 px-2 focus:ring-teal-500 focus:border-teal-500 disabled:border-transparent disabled:appearance-none disabled:bg-transparent disabled:pl-0"
                                        >
                                            {Object.entries(ROLE_LABELS)
                                                .filter(([key]) => ROLE_HIERARCHY[key as RoleType] < currentUserLevel)
                                                .map(([key, label]) => (
                                                    <option key={key} value={key}>{label}</option>
                                                ))
                                            }
                                             {/* Always show the user's current role even if it's higher than the viewer's */}
                                             {!Object.keys(ROLE_LABELS).some(key => ROLE_HIERARCHY[key as RoleType] < currentUserLevel && key === user.role) && (
                                                <option value={user.role}>{ROLE_LABELS[user.role]}</option>
                                            )}
                                        </select>
                                    </td>
                                    <td className="py-3 px-4 text-center">
                                        <button 
                                            onClick={() => setDeleteModalState({ isOpen: true, user })}
                                            disabled={!canEditUser || isSelf}
                                            className="p-2 text-gray-500 hover:text-red-600 disabled:opacity-50 disabled:cursor-not-allowed" 
                                            title={isSelf ? "No puedes eliminarte a ti mismo" : (!canEditUser ? "No puedes eliminar a un usuario con un rol igual o superior" : "Eliminar usuario")}
                                        >
                                            <Icon name="delete" className="text-base" />
                                        </button>
                                    </td>
                                </tr>
                            )})}
                        </tbody>
                    </table>
                 </div>
            </Card>

            {isInviteModalOpen && (
                 <div className="fixed inset-0 bg-black bg-opacity-60 flex justify-center items-center z-50 p-4">
                    <div className="bg-white rounded-xl shadow-2xl p-6 sm:p-8 max-w-md w-full animate-scale-in">
                        <h3 className="text-xl font-bold mb-4">Invitar Nuevo Usuario</h3>
                        <form onSubmit={handleInviteUser} className="space-y-4">
                             <input type="email" placeholder="Correo electrónico del usuario" value={inviteUserData.email} onChange={(e) => setInviteUserData({...inviteUserData, email: e.target.value})} required className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500"/>
                             <select value={inviteUserData.role} onChange={(e) => setInviteUserData({...inviteUserData, role: e.target.value as RoleType})} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500">
                                <option value="crm_collaborator">Colaborador de CRM</option>
                                <option value="crm_admin">Admin de CRM</option>
                             </select>
                             {modalError && <p className="text-sm text-red-600">{modalError}</p>}
                            <div className="flex justify-end gap-3 pt-4">
                                <button type="button" onClick={() => { setIsInviteModalOpen(false); setModalError(''); }} className="px-4 py-2 rounded-lg border">Cancelar</button>
                                <button type="submit" className="px-4 py-2 rounded-lg bg-teal-600 text-white">Enviar Invitación</button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
            
            <ConfirmationModal 
                isOpen={deleteModalState.isOpen} 
                onClose={() => setDeleteModalState({ isOpen: false, user: null })} 
                onConfirm={handleDeleteUser} 
                title={`Confirmar Eliminación de Usuario`} 
                message={<>¿Estás seguro de que quieres eliminar a <strong>"{deleteModalState.user?.full_name}"</strong>? Esta acción eliminará su acceso al CRM, pero no su cuenta de la plataforma.</>} 
                confirmColor="red"
            />
            <InfoModal isOpen={infoModal.isOpen} onClose={() => setInfoModal(prev => ({...prev, isOpen: false}))} title={infoModal.title} message={infoModal.message} type={infoModal.type}/>
             <style>{`.animate-scale-in { animation: scale-in 0.2s ease-out forwards; } @keyframes scale-in { from { transform: scale(0.95); opacity: 0; } to { transform: scale(1); opacity: 1; } }`}</style>
        </div>
    );
};

export default Roles;
