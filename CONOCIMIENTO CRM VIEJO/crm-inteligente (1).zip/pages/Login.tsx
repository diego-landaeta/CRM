
import React, { useState } from 'react';
import Icon from '../components/ui/Icon.tsx';
import { authService } from '../services/authService.ts';
import { User } from '../types.ts';

interface LoginProps {
  onLoginSuccess: (user: User) => void;
  onSwitchToSignUp: () => void;
}

const Login: React.FC<LoginProps> = ({ onLoginSuccess, onSwitchToSignUp }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [view, setView] = useState<'login' | 'reset'>('login');
  const [resetMessage, setResetMessage] = useState('');

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isLoading) return;
    setError('');
    setIsLoading(true);

    try {
      const user = await authService.login(email, password);
      if(user) {
        onLoginSuccess(user);
      }
    } catch (err: any) {
      setError(err.message || 'Ocurrió un error inesperado.');
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleResetSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isLoading) return;
    setError('');
    setResetMessage('');
    setIsLoading(true);
    
    try {
        await authService.resetPasswordForEmail(email);
        setResetMessage('Si existe una cuenta con ese correo, se ha enviado un enlace para restablecer la contraseña.');
    } catch (err: any) {
        setError(err.message || 'Ocurrió un error al enviar el correo.');
    } finally {
        setIsLoading(false);
    }
  };
  
  const renderLoginForm = () => (
     <form className="mt-6 space-y-6" onSubmit={handleLoginSubmit}>
        <div className="space-y-4 rounded-md">
            <div>
              <label htmlFor="email-address" className="sr-only">Correo electrónico</label>
              <input
                id="email-address" name="email" type="email" autoComplete="email" required value={email} onChange={(e) => setEmail(e.target.value)}
                className="relative block w-full px-4 py-3 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-lg focus:outline-none focus:ring-[var(--input-focus-ring)] focus:border-[var(--input-focus-ring)] focus:z-10 sm:text-sm transition"
                placeholder="Correo electrónico"
              />
            </div>
            <div>
              <label htmlFor="password" className="sr-only">Contraseña</label>
              <input
                id="password" name="password" type="password" autoComplete="current-password" required value={password} onChange={(e) => setPassword(e.target.value)}
                className="relative block w-full px-4 py-3 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-lg focus:outline-none focus:ring-[var(--input-focus-ring)] focus:border-[var(--input-focus-ring)] focus:z-10 sm:text-sm transition"
                placeholder="Contraseña"
              />
            </div>
        </div>

        <div className="text-right text-sm">
            <a href="#" onClick={(e) => { e.preventDefault(); setView('reset'); setError(''); }} className="font-medium text-[var(--text-accent)] hover:text-teal-700">
                ¿Olvidaste tu contraseña?
            </a>
        </div>
        
        {error && <div className="p-3 text-sm text-center text-red-800 bg-red-100 rounded-lg">{error}</div>}

        <div>
            <button
              type="submit"
              disabled={isLoading}
              className="group relative w-full flex justify-center py-3 px-4 border border-transparent text-sm font-medium rounded-lg text-white bg-[var(--button-primary-bg)] hover:bg-[var(--button-primary-hover-bg)] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[var(--button-primary-hover-bg)] disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors"
            >
                {isLoading ? <Icon name="hourglass_top" className="h-5 w-5 text-white animate-spin" /> : 'Iniciar Sesión'}
            </button>
        </div>

        <div className="text-sm text-center">
            <p className="text-gray-600">
                ¿No tienes una cuenta?{' '}
                <a href="#" onClick={(e) => { e.preventDefault(); onSwitchToSignUp(); }} className="font-medium text-[var(--text-accent)] hover:text-teal-700">
                    Regístrate
                </a>
            </p>
        </div>
    </form>
  );
  
   const renderResetForm = () => (
     <form className="mt-6 space-y-6" onSubmit={handleResetSubmit}>
        <p className="text-center text-[var(--text-secondary)]">Introduce tu correo electrónico para recibir instrucciones y restablecer tu contraseña.</p>
        <div>
            <label htmlFor="email-address" className="sr-only">Correo electrónico</label>
            <input
                id="email-address" name="email" type="email" autoComplete="email" required value={email} onChange={(e) => setEmail(e.target.value)}
                className="relative block w-full px-4 py-3 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-lg focus:outline-none focus:ring-[var(--input-focus-ring)] focus:border-[var(--input-focus-ring)] focus:z-10 sm:text-sm transition"
                placeholder="Correo electrónico"
            />
        </div>
        
        {error && <div className="p-3 text-sm text-center text-red-800 bg-red-100 rounded-lg">{error}</div>}
        {resetMessage && <div className="p-3 text-sm text-center text-green-800 bg-green-100 rounded-lg">{resetMessage}</div>}

        <div>
            <button
                type="submit"
                disabled={isLoading}
                className="group relative w-full flex justify-center py-3 px-4 border border-transparent text-sm font-medium rounded-lg text-white bg-[var(--button-primary-bg)] hover:bg-[var(--button-primary-hover-bg)] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[var(--button-primary-hover-bg)] disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors"
            >
                {isLoading ? <Icon name="hourglass_top" className="h-5 w-5 text-white animate-spin" /> : 'Enviar Instrucciones'}
            </button>
        </div>

        <div className="text-sm text-center">
            <a href="#" onClick={(e) => { e.preventDefault(); setView('login'); setError(''); }} className="font-medium text-[var(--text-accent)] hover:text-teal-700">
                Volver a Iniciar Sesión
            </a>
        </div>
    </form>
  );

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100 p-4">
      <div className="w-full max-w-sm p-8 space-y-6 bg-white rounded-2xl shadow-lg">
        <div className="text-center">
            <div className="flex justify-center items-center mb-4">
                 <span className="p-3 bg-[var(--sidebar-bg)] rounded-full shadow-md">
                    <Icon name="insights" className="text-3xl text-white" />
                 </span>
            </div>
          <h1 className="text-3xl font-bold text-[var(--text-primary)]">{view === 'login' ? 'CRM Inteligente' : 'Recuperar Contraseña'}</h1>
          <p className="mt-2 text-[var(--text-secondary)]">
              {view === 'login' ? 'Inicia sesión para acceder a tu panel.' : ''}
          </p>
        </div>

        {view === 'login' ? renderLoginForm() : renderResetForm()}

      </div>
    </div>
  );
};

export default Login;