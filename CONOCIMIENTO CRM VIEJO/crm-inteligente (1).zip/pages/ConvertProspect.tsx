import React, { useState, useEffect } from 'react';
import Icon from '../components/ui/Icon.tsx';
import { dataService } from '../services/dataService.ts';
import { configService } from '../services/configService.ts';
import { Prospect, Client, ClientDataForCreate, Json, ClientUpdate } from '../types.ts';
import DuplicateContactModal from '../components/ui/DuplicateContactModal.tsx';
import FormInput from '../components/ui/FormInput.tsx';
import FormSelect from '../components/ui/FormSelect.tsx';

interface ConvertProspectProps {
    id: string;
    onCancel: () => void;
    onConvert: () => void;
}

const ConvertProspect: React.FC<ConvertProspectProps> = ({ id, onCancel, onConvert }) => {
    const [prospectData, setProspectData] = useState<Prospect | null>(null);
    const [clientStage, setClientStage] = useState('');
    const [clientValue, setClientValue] = useState<number>(0);
    const [clientStatuses, setClientStatuses] = useState<string[]>([]);
    const [programLabel, setProgramLabel] = useState('Oferta Académica');
    const [error, setError] = useState('');
    const [duplicateClient, setDuplicateClient] = useState<Client | null>(null);


    useEffect(() => {
        const fetchData = async () => {
            const data = await dataService.getProspectById(id);
            const statuses = await configService.getClientStatuses();
            const label = await configService.getLabel('prospect', 'program');

            setProspectData(data);
            if (data) {
                setClientValue(data.estimated_value);
            }
            setClientStatuses(statuses);
            setProgramLabel(label);

            if (statuses.length > 0) {
                setClientStage(statuses[0]);
            }
        };
        fetchData();
    }, [id]);

    const handleConvert = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        if (prospectData) {
            try {
                await dataService.convertProspectToClient(prospectData.id, clientStage, clientValue);
                onConvert();
            } catch (err: any) {
                 if (err.message.includes('ya existe un cliente con el mismo correo')) {
                    const existingContact = await dataService.findContactByEmail(prospectData.email);
                    if (existingContact && existingContact.type === 'client') {
                        setDuplicateClient(existingContact.contact as Client);
                    }
                } else {
                    setError(err.message);
                }
            }
        }
    };

    const handleOverwrite = async () => {
        if (!prospectData || !duplicateClient) return;
        try {
            const clientPayload: ClientDataForCreate = {
                name: prospectData.name, email: prospectData.email, phone: prospectData.phone,
                program: prospectData.program, stage: clientStage, estimated_value: clientValue,
                next_contact: prospectData.next_contact || null, owner: prospectData.owner, notes: prospectData.notes,
                country: prospectData.country, origin: prospectData.origin, coordinator: prospectData.coordinator,
                payment_type: 'Pago Único', installments_total: null, installments_paid: null, installment_details: null,
                single_payment_method: null,
            };
            await dataService.updateClient({ id: duplicateClient.id, ...clientPayload } as ClientUpdate);
            await dataService.deleteProspect(prospectData.id);
            setDuplicateClient(null);
            onConvert();
        } catch (err: any) {
            setError(err.message);
            setDuplicateClient(null);
        }
    }

    if (!prospectData) {
        return <div className="p-8">Cargando prospecto...</div>;
    }

    return (
        <div className="flex-1 bg-[#F7FAFC] p-8 overflow-y-auto">
            <header className="mb-8">
                <h2 className="text-3xl font-semibold text-gray-800">Convertir Prospecto a Cliente</h2>
                <p className="text-gray-600">Confirma los datos de <span className="font-bold">{prospectData.name}</span> para convertirlo en cliente.</p>
            </header>
            <div className="bg-white p-8 rounded-lg shadow-md">
                <form onSubmit={handleConvert}>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                        <FormInput label="Nombre" id="name" name="name" value={prospectData.name} readOnly onChange={() => {}}/>
                        <FormInput label="Email" id="email" name="email" type="email" value={prospectData.email} readOnly onChange={() => {}}/>
                        <FormInput label={programLabel} id="program" name="program" value={prospectData.program} readOnly onChange={() => {}}/>
                        <FormInput label="País" id="pais" name="country" value={prospectData.country} readOnly onChange={() => {}}/>
                        <FormInput label="Origen" id="origen" name="origin" value={prospectData.origin} readOnly onChange={() => {}}/>
                        <FormInput 
                            label="Valor de Venta" 
                            id="valor" 
                            name="valor"
                            type="number" 
                            value={clientValue}
                            onChange={(e) => setClientValue(Number(e.target.value))}
                        />
                    </div>
                    <div className="mb-6">
                        <label className="block text-sm font-medium text-gray-700 mb-1" htmlFor="intereses">Intereses</label>
                        <textarea className="w-full border-gray-300 rounded-md p-3 border focus:ring-2 focus:ring-blue-500 transition bg-gray-100" id="intereses" name="intereses" rows={4} defaultValue={prospectData.notes} readOnly></textarea>
                    </div>
                    <div className="mb-8">
                        <FormSelect label="Asignar Etapa de Cliente" id="stage" name="stage" options={clientStatuses} value={clientStage} onChange={(e) => setClientStage(e.target.value)} />
                    </div>

                    {error && (
                        <div className="my-4 p-3 bg-red-100 text-red-700 text-sm rounded-lg text-center">
                            {error}
                        </div>
                    )}
                    
                    <div className="flex justify-end space-x-4">
                        <button type="button" onClick={onCancel} className="px-6 py-3 rounded-md font-medium bg-white text-gray-700 border border-gray-300 hover:bg-gray-50 transition">Cancelar</button>
                        <button type="submit" className="px-6 py-3 rounded-md font-medium text-white bg-[#0D7852] hover:bg-[#0A5D40] transition flex items-center">
                            <Icon name="sync_alt" className="mr-2"/>
                            Convertir a Cliente
                        </button>
                    </div>
                </form>
            </div>
             <DuplicateContactModal
                isOpen={!!duplicateClient}
                onClose={() => setDuplicateClient(null)}
                onOverwrite={handleOverwrite}
                existingContact={duplicateClient}
                newContactData={{...prospectData, stage: clientStage, estimated_value: clientValue}}
                entityType={'client'}
                allowOverwrite={true}
                actionType={'overwrite'}
            />
        </div>
    );
};

export default ConvertProspect;