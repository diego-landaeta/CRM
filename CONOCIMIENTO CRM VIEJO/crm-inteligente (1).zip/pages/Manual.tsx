import React, { useState } from 'react';
import Icon from '../components/ui/Icon.tsx';

const sqlScript = `-- ### PASO 1: Crear las tablas necesarias ###

-- Tabla para almacenar los roles
CREATE TABLE public.roles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL UNIQUE,
    description TEXT,
    created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL
);
COMMENT ON TABLE public.roles IS 'Almacena los roles de usuario (ej. Administrador, Colaborador).';

-- Tabla para almacenar todos los permisos disponibles en la aplicación
CREATE TABLE public.permissions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL UNIQUE,
    description TEXT,
    created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL
);
COMMENT ON TABLE public.permissions IS 'Catálogo de acciones granulares permitidas en el sistema.';

-- Tabla pivote para asociar roles con permisos
CREATE TABLE public.role_permissions (
    role_id UUID NOT NULL REFERENCES public.roles(id) ON DELETE CASCADE,
    permission_id UUID NOT NULL REFERENCES public.permissions(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL,
    PRIMARY KEY (role_id, permission_id)
);
COMMENT ON TABLE public.role_permissions IS 'Asocia roles con sus respectivos permisos.';

-- Tabla de perfiles públicos de usuario, extendiendo auth.users
CREATE TABLE public.profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    full_name TEXT,
    role_id UUID NOT NULL REFERENCES public.roles(id),
    updated_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now())
);
COMMENT ON TABLE public.profiles IS 'Almacena datos públicos y el rol de cada usuario.';

-- Tabla para gestionar invitaciones de nuevos usuarios
CREATE TABLE public.invitations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email TEXT NOT NULL UNIQUE,
    role_id UUID NOT NULL REFERENCES public.roles(id),
    invited_by UUID NOT NULL REFERENCES auth.users(id),
    created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL
);
COMMENT ON TABLE public.invitations IS 'Almacena las invitaciones pendientes para nuevos usuarios.';


-- ### PASO 2: Habilitar Row Level Security (RLS) ###
ALTER TABLE public.roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.permissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.role_permissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.invitations ENABLE ROW LEVEL SECURITY;


-- ### PASO 3: Crear función de ayuda para verificar si un usuario es Administrador ###
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  is_admin_user boolean;
BEGIN
  SELECT EXISTS (
    SELECT 1
    FROM public.profiles p
    JOIN public.roles r ON p.role_id = r.id
    WHERE p.id = auth.uid() AND r.name = 'Administrador'
  ) INTO is_admin_user;
  
  RETURN is_admin_user;
END;
$$;


-- ### PASO 4: Crear políticas de acceso RLS ###
CREATE POLICY "Allow authenticated users to view all data" ON public.profiles FOR SELECT USING (auth.role() = 'authenticated');
CREATE POLICY "Allow users to update their own name" ON public.profiles FOR UPDATE USING (auth.uid() = id) WITH CHECK (auth.uid() = id);
CREATE POLICY "Allow admins to manage all profiles" ON public.profiles FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin());

CREATE POLICY "Allow authenticated read access on roles" ON public.roles FOR SELECT USING (auth.role() = 'authenticated');
CREATE POLICY "Allow role management for admins" ON public.roles FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin());

CREATE POLICY "Allow authenticated read access on permissions" ON public.permissions FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "Allow authenticated read access on role_permissions" ON public.role_permissions FOR SELECT USING (auth.role() = 'authenticated');
CREATE POLICY "Allow role management for admins" ON public.role_permissions FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin());

CREATE POLICY "Allow admin to manage invitations" ON public.invitations FOR ALL USING (public.is_admin()) WITH CHECK (public.is_admin());


-- ### PASO 5: Crear la función y el trigger para manejar nuevos usuarios ###

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  role_id_to_assign UUID;
  profile_count INT;
  invitation_role_id UUID;
  admin_role_name TEXT := 'Administrador';
  default_role_name TEXT := 'Colaborador';
BEGIN
  -- 1. Buscar una invitación para el email del nuevo usuario
  SELECT role_id INTO invitation_role_id FROM public.invitations WHERE email = new.email;

  IF invitation_role_id IS NOT NULL THEN
    -- Si fue invitado, se le asigna el rol de la invitación
    role_id_to_assign := invitation_role_id;
    -- Se elimina la invitación para que no se pueda volver a usar
    DELETE FROM public.invitations WHERE email = new.email;
  ELSE
    -- Si no fue invitado, se revisa si es el primer usuario
    SELECT count(*) INTO profile_count FROM public.profiles;
    IF profile_count = 0 THEN
      -- El primer usuario se convierte en Administrador
      SELECT id INTO role_id_to_assign FROM public.roles WHERE name = admin_role_name;
      IF role_id_to_assign IS NULL THEN
        RAISE EXCEPTION 'ERROR CRÍTICO DE CONFIGURACIÓN: El rol por defecto "%" no existe. Por favor, créalo antes de registrar al primer usuario.', admin_role_name;
      END IF;
    ELSE
      -- Los usuarios siguientes no invitados obtienen el rol por defecto
      SELECT id INTO role_id_to_assign FROM public.roles WHERE name = default_role_name;
      IF role_id_to_assign IS NULL THEN
        RAISE EXCEPTION 'ERROR CRÍTICO DE CONFIGURACIÓN: El rol por defecto "%" no existe. Por favor, créalo para permitir el registro de nuevos usuarios.', default_role_name;
      END IF;
    END IF;
  END IF;
  
  -- Insertar el nuevo perfil
  INSERT INTO public.profiles (id, full_name, role_id)
  VALUES (
    new.id,
    coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name'),
    role_id_to_assign
  );
  
  RETURN new;
END;
$$;

-- Este trigger llama a la función 'handle_new_user' después de que se cree un nuevo usuario.
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();


-- ### PASO 6: Insertar los datos iniciales (Roles y Permisos) ###

-- Insertar Roles
INSERT INTO public.roles (name, description) VALUES
('Administrador', 'Acceso total al sistema. Puede gestionar usuarios, roles y configuraciones.'),
('Colaborador', 'Rol estándar con acceso a la gestión de clientes y prospectos, pero no puede editar la configuración.');

-- Insertar Permisos
INSERT INTO public.permissions (name, description) VALUES
  ('clients:read', 'Ver clientes'),
  ('clients:write', 'Crear y editar clientes'),
  ('clients:delete', 'Eliminar clientes'),
  ('prospects:read', 'Ver prospectos'),
  ('prospects:write', 'Crear y editar prospectos'),
  ('prospects:delete', 'Eliminar prospectos'),
  ('prospects:convert', 'Convertir prospectos a clientes'),
  ('billing:read', 'Ver facturación'),
  ('email:send', 'Enviar emails'),
  ('statistics:read', 'Ver estadísticas'),
  ('config:read', 'Ver configuración'),
  ('config:write', 'Modificar configuración'),
  ('users:manage', 'Invitar, eliminar y gestionar roles de usuarios'),
  ('roles:manage', 'Crear, editar y eliminar roles y permisos');


-- ### PASO 7: Asignar Permisos a los Roles ###

-- Asignar TODOS los permisos al rol de Administrador
INSERT INTO public.role_permissions (role_id, permission_id)
SELECT
  (SELECT id FROM public.roles WHERE name = 'Administrador'),
  p.id
FROM public.permissions p;

-- Asignar permisos específicos al rol de Colaborador
INSERT INTO public.role_permissions (role_id, permission_id)
SELECT
  (SELECT id FROM public.roles WHERE name = 'Colaborador'),
  p.id
FROM public.permissions p
WHERE p.name IN (
  'clients:read',
  'clients:write',
  'clients:delete',
  'prospects:read',
  'prospects:write',
  'prospects:delete',
  'prospects:convert',
  'billing:read',
  'email:send',
  'statistics:read',
  'config:read'
);`;

const Manual: React.FC = () => {
    const [activeTab, setActiveTab] = useState('setup');

    const sections = [
        { id: 'setup', label: 'Setup Inicial', icon: 'dns' },
        { id: 'dashboard', label: 'Dashboard', icon: 'dashboard' },
        { id: 'contacts', label: 'Clientes y Prospectos', icon: 'people' },
        { id: 'config', label: 'Configuración', icon: 'settings' },
        { id: 'billing', label: 'Facturación y Email', icon: 'receipt_long' },
        { id: 'cermi', label: 'Asistente IA Cermi', icon: 'auto_awesome' },
    ];

    const TabButton: React.FC<{ section: typeof sections[0] }> = ({ section }) => {
        const isActive = activeTab === section.id;
        return (
            <button
                onClick={() => setActiveTab(section.id)}
                className={`flex items-center justify-center sm:justify-start text-center sm:text-left w-full gap-3 px-4 py-3 rounded-lg transition-colors duration-200 focus:outline-none ${
                    isActive
                        ? 'bg-teal-600 text-white shadow-md'
                        : 'text-gray-600 hover:bg-teal-50 hover:text-teal-700'
                }`}
            >
                <Icon name={section.icon} className={isActive ? 'text-white' : 'text-teal-600'} />
                <span className="font-medium">{section.label}</span>
            </button>
        );
    };
    
    const ContentWrapper: React.FC<{ id: string, children: React.ReactNode }> = ({ id, children }) => (
        <div className={`${activeTab === id ? 'block' : 'hidden'} prose max-w-none prose-p:text-gray-700 prose-ul:list-disc prose-headings:text-gray-800 prose-ul:ml-6 prose-li:mb-2 prose-strong:font-semibold prose-a:text-teal-600`}>
            {children}
        </div>
    );
    
    const SubSection: React.FC<{title: string, icon: string, children: React.ReactNode}> = ({ title, icon, children }) => (
        <section className="mb-8 mt-6">
            <header className="flex items-center mb-3 border-b pb-2">
                <Icon name={icon} className="text-2xl text-teal-600 mr-3" />
                <h3 className="text-xl font-bold">{title}</h3>
            </header>
            <div>{children}</div>
        </section>
    );

    const CopyButton: React.FC<{ textToCopy: string }> = ({ textToCopy }) => {
        const [copied, setCopied] = useState(false);
    
        const handleCopy = () => {
            navigator.clipboard.writeText(textToCopy).then(() => {
                setCopied(true);
                setTimeout(() => setCopied(false), 2000);
            });
        };
    
        return (
            <button 
                onClick={handleCopy} 
                className="absolute top-3 right-3 bg-gray-700 text-white px-3 py-1.5 rounded-md text-xs hover:bg-gray-600 transition-colors flex items-center gap-1.5"
                aria-label="Copiar script SQL"
            >
                <Icon name={copied ? 'check' : 'content_copy'} className="text-sm" />
                {copied ? '¡Copiado!' : 'Copiar'}
            </button>
        );
    };

    return (
        <div className="p-4 sm:p-8 overflow-y-auto bg-gray-50 min-h-full">
            <div className="max-w-7xl mx-auto">
                <header className="mb-8 text-center sm:text-left">
                    <h1 className="text-4xl font-extrabold text-gray-900">Manual de Usuario</h1>
                    <p className="text-lg text-gray-500 mt-2">Tu guía completa para dominar CRM Inteligente.</p>
                </header>

                <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
                    <aside className="lg:col-span-1">
                        <nav className="space-y-2 sticky top-24">
                           {sections.map(section => <TabButton key={section.id} section={section} />)}
                           <div className="pt-4">
                               <a 
                                href="https://gestion360pro.com/wp-content/uploads/2025/07/Manual-de-Usuario1.pdf"
                                target="_blank"
                                rel="noopener noreferrer"
                                className="flex items-center justify-center w-full gap-3 px-4 py-3 rounded-lg transition-colors duration-200 bg-gray-700 text-white hover:bg-gray-800 shadow-md">
                                <Icon name="picture_as_pdf" />
                                <span className="font-medium">Descargar PDF</span>
                            </a>
                           </div>
                        </nav>
                    </aside>

                    <main className="lg:col-span-3 bg-white p-6 sm:p-10 rounded-xl shadow-lg">
                        <ContentWrapper id="setup">
                            <h2><Icon name="dns" className="mr-2" />Configuración Inicial de la Base de Datos</h2>
                            <p>Para que el sistema de <strong>roles y permisos</strong> funcione, necesitas ejecutar el siguiente script SQL en el <strong>SQL Editor</strong> de tu proyecto en Supabase. Esto configurará todas las tablas, funciones y permisos necesarios.</p>
                            <p><strong>Importante:</strong> Este script ahora asignará automáticamente el rol de <strong>Administrador</strong> al primer usuario que se registre. Todos los demás usuarios sin invitación recibirán el rol de <strong>Colaborador</strong> por defecto.</p>
                            <p>Simplemente haz clic en el botón "Copiar" y pega el contenido completo en el editor de Supabase.</p>
                            <div className="relative bg-gray-800 text-white p-4 rounded-lg my-4">
                                <CopyButton textToCopy={sqlScript} />
                                <pre className="overflow-x-auto text-sm">
                                    <code className="language-sql font-mono">
                                        {sqlScript}
                                    </code>
                                </pre>
                            </div>
                        </ContentWrapper>
                        <ContentWrapper id="dashboard">
                            <h2><Icon name="dashboard" className="mr-2" />Dashboard: Tu Centro de Mando</h2>
                            <p>El Dashboard te ofrece una vista panorámica y personalizable del rendimiento de tu negocio. Te permite analizar métricas clave y entender la salud de tus ventas de un solo vistazo.</p>
                            
                            <SubSection title="Filtros Globales" icon="filter_alt">
                                <p>En la parte superior del Dashboard, encontrarás los controles para filtrar toda la información de la página:</p>
                                <ul>
                                    <li><strong>Filtro de Fechas:</strong> Selecciona un rango de fechas (inicio y fin) para acotar las estadísticas a un período específico. Por defecto, no se aplica ningún filtro de fecha.</li>
                                    <li><strong>Filtro de Oferta Académica:</strong> Si está activado, puedes seleccionar un programa específico para ver las estadísticas relacionadas únicamente con esa oferta.</li>
                                </ul>
                                <p>Todos los gráficos y tarjetas de estadísticas se actualizarán automáticamente al cambiar estos filtros.</p>
                            </SubSection>

                             <SubSection title="Resumen Diario y Estadísticas Clave" icon="today">
                                <p>Justo debajo de los filtros, encontrarás el resumen diario y las tarjetas principales:</p>
                                <ul>
                                    <li><strong>Resumen Diario:</strong> Muestra los nuevos prospectos y clientes registrados en una fecha específica. Usa el selector de fecha para consultar el rendimiento de cualquier día.</li>
                                    <li><strong>Tarjetas de Estadísticas Principales:</strong> Presentan 4 KPIs (Indicadores Clave de Rendimiento) que reflejan los datos filtrados:
                                        <ul>
                                            <li><strong>Total de Clientes:</strong> Número total de clientes activos.</li>
                                            <li><strong>Prospectos Nuevos:</strong> Cantidad de prospectos en la etapa "Nuevo".</li>
                                            <li><strong>Tasa de Conversión:</strong> Porcentaje de prospectos que se convierten en clientes.</li>
                                            <li><strong>Valor Total Estimado:</strong> Suma del valor de todos tus clientes y prospectos activos.</li>
                                        </ul>
                                    </li>
                                </ul>
                            </SubSection>

                            <SubSection title="Gráficos Interactivos y Reportes" icon="bar_chart">
                                <p>Visualiza tus datos de forma más clara con los gráficos y tablas:</p>
                                <ul>
                                    <li><strong>Distribución por Oferta Académica:</strong> Un gráfico de barras que compara la cantidad de clientes y prospectos interesados en cada programa.</li>
                                    <li><strong>Etapas de Prospectos:</strong> Un gráfico circular que muestra en qué etapa del embudo de ventas se encuentra cada prospecto.</li>
                                    <li><strong>Estadísticas por País:</strong> Una tabla detallada que desglosa el número de clientes, prospectos y el valor total por cada país.</li>
                                    <li><strong>Descargar Reporte:</strong> Al hacer clic en <Icon name="download" className="text-sm" /> <strong>Descargar Reporte</strong>, se abrirá una ventana para que personalices tu exportación. Selecciona los campos que necesitas y obtén un archivo Excel con los datos de todos tus clientes y prospectos.</li>
                                </ul>
                            </SubSection>
                        </ContentWrapper>
                        
                        <ContentWrapper id="contacts">
                             <h2><Icon name="people" className="mr-2" />Gestión de Clientes y Prospectos</h2>
                             <p>Las secciones de Clientes y Prospectos son casi idénticas en su funcionamiento y te permiten gestionar toda la información de tus contactos. Ahora incluyen pestañas para separar contactos <strong>Activos</strong> de <strong>Archivados</strong>. Aquí te explicamos todas las funciones disponibles.</p>
                             
                            <SubSection title="Añadir, Editar y Eliminar Contactos" icon="person_add">
                                <ul>
                                    <li><strong>Nuevo Contacto:</strong> Haz clic en <Icon name="add" className="text-sm" /> <strong>Nuevo Cliente</strong> o <strong>Nuevo Prospecto</strong> para abrir un formulario completo y detallado.</li>
                                    <li><strong>Formulario Detallado:</strong> Rellena todos los campos. Si una coordinadora, etapa o programa no existe, puedes escribir el nuevo nombre en el campo correspondiente y se creará automáticamente al guardar.</li>
                                    <li><strong>Creación Rápida:</strong> Usa el botón <Icon name="bolt" className="text-sm" /> <strong>Creación Rápida</strong> para añadir un contacto con solo los campos esenciales (configurables en el menú de Configuración).</li>
                                    <li><strong>Editar:</strong> En la tabla de contactos, haz clic en el icono <Icon name="edit" className="text-sm" /> para modificar la información de un cliente o prospecto.</li>
                                    <li><strong>Eliminar:</strong> Usa el icono <Icon name="delete" className="text-sm" /> para borrar un contacto. Una ventana de confirmación te pedirá verificar la acción para evitar borrados accidentales.</li>
                                    <li><strong>Convertir Prospecto a Cliente:</strong> En la lista de Prospectos, el icono <Icon name="sync_alt" className="text-sm" /> te permite convertir un prospecto en cliente, transfiriendo sus datos y asignándole una etapa de cliente.</li>
                                </ul>
                            </SubSection>
                            
                            <SubSection title="Búsqueda y Filtrado Avanzado" icon="filter_list">
                                <p>Localiza contactos específicos de forma rápida y eficiente.</p>
                                <ul>
                                    <li><strong>Ordenar Tabla:</strong> Haz clic en el encabezado de cualquier columna (ej. "Nombre", "Etapa") para ordenar la lista alfabéticamente o numéricamente en orden ascendente o descendente.</li>
                                    <li><strong>Filtros Avanzados:</strong> Haz clic en el botón <Icon name="filter_list" className="text-sm" /> <strong>Filtros Avanzados</strong> para abrir un panel lateral. Desde allí podrás filtrar tu lista por:
                                        <ul>
                                            <li>Término de búsqueda (nombre o email).</li>
                                            <li>Etapa, coordinadora, país y origen.</li>
                                            <li>Tipo de Pago (solo para clientes).</li>
                                            <li>Oferta académica (Facultad, Tipo de programa y Programa específico).</li>
                                        </ul>
                                    </li>
                                    <li><strong>Indicador de Filtros Activos:</strong> El botón de filtros mostrará un número que indica cuántos filtros estás aplicando actualmente.</li>
                                </ul>
                            </SubSection>
                            
                            <SubSection title="Importación Masiva desde Excel" icon="upload_file">
                                 <p>Añade cientos de contactos a la vez con la potente herramienta de importación.</p>
                                 <ol className="list-decimal ml-6 space-y-2">
                                     <li><strong>Paso 1: Descargar Plantilla.</strong> En la ventana de importación, primero selecciona los campos que deseas incluir. Después, haz clic en <Icon name="download" className="text-sm" /> <strong>Descargar Plantilla</strong>. Se generará un archivo Excel con las columnas correspondientes y una fila de ejemplo.</li>
                                     <li><strong>Paso 2: Rellenar Datos.</strong> Abre el archivo Excel y llena las filas con la información de tus contactos. Si dejas un campo como "Coordinadora" vacío, el sistema intentará asignarla automáticamente según el país (si tienes esa configuración).</li>
                                     <li><strong>Paso 3: Subir Archivo.</strong> Arrastra tu archivo Excel completado o selecciónalo desde tu computadora. Haz clic en <Icon name="upload" className="text-sm" /> <strong>Importar</strong>. El sistema procesará los datos, creará automáticamente las nuevas etapas, coordinadoras o programas que no existan, y añadirá los contactos, evitando duplicados por email.</li>
                                 </ol>
                            </SubSection>

                             <SubSection title="Archivar y Desarchivar Contactos" icon="archive">
                                <p>Para mantener tus listas principales limpias y enfocadas, puedes archivar clientes o prospectos que no requieran atención inmediata pero que no deseas eliminar permanentemente.</p>
                                <ul>
                                    <li><strong>Archivar:</strong> En la pestaña "Activos", haz clic en el icono <Icon name="archive" className="text-sm" /> en la fila del contacto. Esto lo moverá a la pestaña "Archivados".</li>
                                    <li><strong>Ver Archivados:</strong> Haz clic en la pestaña "Archivados" para ver todos los contactos que has archivado. Los contactos aquí no aparecerán en las búsquedas globales, filtros o reportes del dashboard.</li>
                                    <li><strong>Desarchivar:</strong> En la pestaña "Archivados", haz clic en el icono <Icon name="unarchive" className="text-sm" /> para devolver el contacto a la lista de "Activos". Un cliente volverá a la etapa "Activo" y un prospecto a la etapa "Nuevo".</li>
                                </ul>
                            </SubSection>
                        </ContentWrapper>
                        
                         <ContentWrapper id="config">
                             <h2><Icon name="settings" className="mr-2" />Configuración y Personalización</h2>
                             <p>Adapta cada aspecto del CRM a las necesidades específicas de tu negocio. La página de Configuración está organizada en pestañas para facilitar el acceso.</p>
                             
                            <SubSection title="Mi Cuenta" icon="person">
                                 <p>Gestiona tu información personal y seguridad. Aquí puedes actualizar tu contraseña de acceso al CRM.</p>
                             </SubSection>

                            <SubSection title="Equipo y Territorios" icon="group">
                                <ul>
                                    <li><strong>Gestión de Coordinadoras:</strong> Añade o elimina coordinadoras de la lista que aparecerá en los formularios de Clientes y Prospectos.</li>
                                    <li><strong>Gestión de Países:</strong> Administra la lista de países disponibles en los formularios.</li>
                                    <li><strong>Asignación por País:</strong> Asigna una coordinadora por defecto a cada país. Cuando crees un nuevo contacto y selecciones un país, el campo de coordinadora se rellenará automáticamente, ahorrándote tiempo.</li>
                                </ul>
                            </SubSection>
                            
                            <SubSection title="Personalización de la Plataforma" icon="tune">
                                 <ul>
                                     <li><strong>Campos de Formularios:</strong> Aquí puedes cambiar las etiquetas de los campos (ej. renombrar "Programa de Estudio" a "Producto Adquirido") y decidir qué columnas son visibles por defecto en las tablas de Clientes y Prospectos.</li>
                                     <li><strong>Listas y Categorías:</strong>
                                        <ul>
                                            <li><strong>Oferta Académica:</strong> Activa o desactiva este módulo. Gestiona tus facultades, y dentro de cada una, añade o elimina Cursos, Diplomados, Masters y Especializaciones. Esta estructura jerárquica aparecerá en los formularios de contacto.</li>
                                            <li><strong>Etapas de Clientes/Prospectos:</strong> Personaliza completamente tu embudo de ventas. Añade, elimina o renombra las etapas por las que pasan tus contactos.</li>
                                        </ul>
                                     </li>
                                 </ul>
                            </SubSection>

                            <SubSection title="Funciones Rápidas" icon="bolt">
                                <p>Activa la opción de <strong>Creación Rápida</strong> para las vistas de Clientes y/o Prospectos.
                                </p>
                            </SubSection>
                             
                             <SubSection title="Roles y Permisos" icon="admin_panel_settings">
                                 <p>Define qué puede hacer cada tipo de usuario en el sistema. Puedes crear nuevos roles (ej. "Ventas Junior") y asignarles permisos granulares, como ver clientes pero no eliminarlos.</p>
                                 <p><strong>Importante:</strong> El rol "Administrador" tiene acceso a todo y no puede ser modificado para garantizar la seguridad del sistema.</p>
                             </SubSection>
                        </ContentWrapper>

                        <ContentWrapper id="billing">
                            <h2><Icon name="receipt_long" className="mr-2" />Facturación y Email</h2>

                            <SubSection title="Módulo de Facturación" icon="payments">
                                <p>Lleva un control detallado de los pagos de tus clientes:</p>
                                <ul>
                                    <li><strong>Vista General:</strong> Accede a una tabla con todos tus clientes que tienen un valor de venta asignado. Podrás ver el valor total, el monto abonado y el saldo pendiente.</li>
                                    <li><strong>Gestión de Cuotas:</strong> Para clientes con pago a plazos, haz clic en el icono <Icon name="payments" className="text-sm" /> para abrir una ventana y gestionar sus cuotas. Marca cada cuota como "Pagada" a medida que se completen los pagos. El sistema recalculará los totales automáticamente.</li>
                                    <li><strong>Estados de Pago:</strong> Los pagos se marcan como "Pagado", "Pendiente" o "Atrasado" para que puedas identificar rápidamente quién necesita un seguimiento.</li>
                                </ul>
                            </SubSection>

                            <SubSection title="Envío de Correos con n8n" icon="email">
                                <p>Integra tus cuentas de correo electrónico a través de la plataforma de automatización n8n para enviar emails directamente desde el CRM.</p>
                                 <ol className="list-decimal ml-6 space-y-2">
                                     <li><strong>Descarga la Plantilla:</strong> En la sección de Email, descarga la plantilla de flujo de trabajo para n8n.</li>
                                     <li><strong>Configura en n8n:</strong> Importa la plantilla en tu instancia de n8n, configura el nodo de email con tus credenciales (ej. Gmail, Outlook) y activa el flujo.</li>
                                     <li><strong>Copia la Webhook URL:</strong> Una vez activado, copia la "Production URL" del webhook de n8n.</li>
                                     <li><strong>Añade el Flujo al CRM:</strong> Vuelve al CRM, ve a la sección de Email, haz clic en "+ Añadir", dale un nombre a tu flujo (ej. "Cuenta de Ventas") y pega la URL.</li>
                                     <li><strong>Envía Correos:</strong> ¡Listo! Ahora puedes seleccionar el flujo que acabas de crear, elegir un destinatario de tu lista de contactos y enviar correos. Puedes añadir múltiples flujos para gestionar diferentes cuentas de correo.</li>
                                 </ol>
                            </SubSection>
                        </ContentWrapper>
                        
                        <ContentWrapper id="cermi">
                             <h2><Icon name="auto_awesome" className="mr-2" />Asistente IA Cermi</h2>
                             <p>Cermi es tu asistente inteligente integrado, diseñado para ayudarte a acceder y analizar tu información de forma conversacional. Hazle preguntas en lenguaje natural sobre tus clientes y prospectos.</p>

                             <SubSection title="Capacidades Principales" icon="psychology">
                                 <ul>
                                     <li><strong>Consulta de Datos:</strong> Pregúntale a Cermi por información específica. Por ejemplo: <em>"¿Quién es el cliente Juan Pérez?"</em> o <em>"¿Cuántos prospectos tengo en Colombia?"</em>.</li>
                                     <li><strong>Análisis y Resúmenes:</strong> Pide resúmenes o análisis. Por ejemplo: <em>"Dame un resumen de los prospectos interesados en el programa de Marketing"</em> o <em>"¿Qué coordinadora tiene más ingresos generados?"</em>.</li>
                                     <li><strong>Conversación Guiada:</strong> Cuando pides información, Cermi no te mostrará una lista larga de inmediato. Primero te preguntará si quieres filtrar por país o fecha. Luego, te dirá cuántos contactos encontró y te preguntará si deseas ver los detalles, haciendo la interacción más manejable.</li>
                                     <li><strong>Asistencia General:</strong> También puedes pedirle ayuda para tareas creativas, como <em>"Redacta un correo de seguimiento para un prospecto en la etapa de negociación"</em> o <em>"Sugiere una estrategia para reactivar clientes inactivos"</em>.</li>
                                 </ul>
                             </SubSection>
                             
                             <SubSection title="¿Cómo Funciona?" icon="memory">
                                 <p>Cuando haces una pregunta relacionada con tus contactos (usando palabras clave como "cliente", "prospecto", "quién es", "dime sobre"), Cermi automáticamente toma un contexto actualizado de tus datos del CRM para darte la respuesta más precisa. No es necesario que le proporciones los datos manualmente; él los obtiene por ti.</p>
                                 <p><strong>Privacidad:</strong> Tu información solo se utiliza para responder a tus preguntas en el momento y no se almacena ni se usa para entrenar el modelo de IA.</p>
                             </SubSection>
                        </ContentWrapper>
                    </main>
                </div>
            </div>
        </div>
    );
};

export default Manual;