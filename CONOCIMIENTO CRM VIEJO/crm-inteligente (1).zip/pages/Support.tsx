
import React from 'react';
import Card from '../components/ui/Card.tsx';
import Icon from '../components/ui/Icon.tsx';

const Support: React.FC = () => {
  return (
    <div className="p-6 max-w-2xl mx-auto">
      <Card>
        <div className="text-center mb-6">
            <Icon name="support_agent" className="text-6xl text-[var(--text-accent)] mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-[var(--text-primary)]">Soporte</h2>
            <p className="text-[var(--text-secondary)] mt-2">
            ¿Necesitas ayuda? Completa el formulario y nos pondremos en contacto contigo.
            </p>
        </div>
        <form className="space-y-4">
            <div>
                <label htmlFor="name" className="block text-sm font-medium text-[var(--text-secondary)]">Nombre</label>
                <input type="text" id="name" className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[var(--input-focus-ring)] focus:ring-[var(--input-focus-ring)] sm:text-sm" placeholder="Tu nombre completo"/>
            </div>
            <div>
                <label htmlFor="email" className="block text-sm font-medium text-[var(--text-secondary)]">Email</label>
                <input type="email" id="email" className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[var(--input-focus-ring)] focus:ring-[var(--input-focus-ring)] sm:text-sm" placeholder="tu@email.com"/>
            </div>
            <div>
                <label htmlFor="message" className="block text-sm font-medium text-[var(--text-secondary)]">Mensaje</label>
                <textarea id="message" rows={4} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[var(--input-focus-ring)] focus:ring-[var(--input-focus-ring)] sm:text-sm" placeholder="Describe tu problema o pregunta..."></textarea>
            </div>
            <div>
                <button type="submit" className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-[var(--button-primary-bg)] hover:bg-[var(--button-primary-hover-bg)] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[var(--button-primary-hover-bg)]">
                    Enviar Mensaje
                </button>
            </div>
        </form>
      </Card>
    </div>
  );
};

export default Support;