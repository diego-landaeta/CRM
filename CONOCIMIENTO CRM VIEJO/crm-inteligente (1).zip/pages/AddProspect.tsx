import React from 'react';
import ContactForm from '../components/forms/ContactForm.tsx';

interface AddProspectProps {
    onCancel: () => void;
    onSave: () => void;
}

const AddProspect: React.FC<AddProspectProps> = ({ onCancel, onSave }) => {
    return <ContactForm entityType="prospect" onCancel={onCancel} onSave={onSave} />;
};

export default AddProspect;
