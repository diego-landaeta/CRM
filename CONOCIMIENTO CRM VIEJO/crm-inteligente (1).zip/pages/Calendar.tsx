
import React from 'react';
import Card from '../components/ui/Card.tsx';
import Icon from '../components/ui/Icon.tsx';

const Calendar: React.FC = () => {
  return (
    <div className="p-6 max-w-2xl mx-auto mt-10">
      <Card>
        <div className="text-center p-8">
            <Icon name="calendar_today" className="text-6xl text-gray-300 mx-auto mb-6" />
            <h2 className="text-3xl font-bold text-gray-800">Calendario</h2>
            <p className="text-lg text-gray-500 mt-2">
                Esta función está en desarrollo.
            </p>
            <p className="text-md text-gray-600 mt-6 bg-blue-50 p-4 rounded-lg border border-blue-200">
                ¡Próximamente! Podrás conectar tu calendario de Google para gestionar tus citas, reuniones y recordatorios de seguimiento directamente desde el CRM.
            </p>
        </div>
      </Card>
    </div>
  );
};

export default Calendar;