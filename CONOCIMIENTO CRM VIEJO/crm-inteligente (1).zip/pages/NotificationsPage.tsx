
import React from 'react';
import { Notification } from '../types.ts';
import Card from '../components/ui/Card.tsx';
import Icon from '../components/ui/Icon.tsx';

interface NotificationsPageProps {
    notifications: Notification[];
    setNotifications: React.Dispatch<React.SetStateAction<Notification[]>>;
}

const NotificationsPage: React.FC<NotificationsPageProps> = ({ notifications, setNotifications }) => {
    const handleClearAll = () => {
        setNotifications([]);
    };

    const handleMarkAllAsRead = () => {
        setNotifications(prev => prev.map(n => ({...n, read: true})));
    };

    const formatDate = (timestamp: string) => {
         const date = new Date(timestamp);
         const now = new Date();
         const diffSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);
         const diffMinutes = Math.floor(diffSeconds / 60);
         const diffHours = Math.floor(diffMinutes / 60);
         const diffDays = Math.floor(diffHours / 24);

         if (diffDays > 1) return `${diffDays} días atrás`;
         if (diffDays === 1) return `hace 1 día`;
         if (diffHours > 1) return `hace ${diffHours} horas`;
         if (diffHours === 1) return `hace 1 hora`;
         if (diffMinutes > 1) return `hace ${diffMinutes} minutos`;
         return `hace un momento`;
    }

    return (
        <div className="p-4 sm:p-6 space-y-6">
            <Card>
                <div className="flex justify-between items-center flex-wrap gap-4 mb-6">
                    <div>
                        <h2 className="text-2xl font-bold text-gray-800">Todas las Notificaciones</h2>
                        <p className="text-sm text-gray-500">Aquí puedes ver todo tu historial de notificaciones.</p>
                    </div>
                    <div className="flex items-center gap-3">
                         <button onClick={handleMarkAllAsRead} className="bg-white hover:bg-gray-100 text-gray-800 font-medium py-2 px-4 rounded-lg flex items-center transition-colors border border-gray-300">
                            <Icon name="drafts" className="mr-2" />
                            Marcar todas como leídas
                        </button>
                        <button onClick={handleClearAll} className="bg-red-50 hover:bg-red-100 text-red-700 font-medium py-2 px-4 rounded-lg flex items-center transition-colors">
                            <Icon name="delete_sweep" className="mr-2" />
                            Borrar Todas
                        </button>
                    </div>
                </div>

                <ul className="space-y-4">
                    {notifications.length > 0 ? (
                        notifications.map(notification => (
                            <li key={notification.id} className={`p-4 rounded-lg border flex items-start gap-4 transition-all ${notification.read ? 'bg-white' : 'bg-teal-50 border-teal-200'}`}>
                                <div className={`mt-1 flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center ${notification.iconColor.replace('text-', 'bg-').replace('500', '100')}`}>
                                    <Icon name={notification.icon} className={`${notification.iconColor} text-xl`} />
                                </div>
                                <div className="flex-grow">
                                    <p className="font-semibold text-gray-800">{notification.title}</p>
                                    <p className="text-sm text-gray-600">{notification.message}</p>
                                    <p className="text-xs text-gray-400 mt-1">{notification.sender} &middot; {formatDate(notification.timestamp)}</p>
                                </div>
                                 {!notification.read && <div className="w-2.5 h-2.5 bg-teal-500 rounded-full mt-2 flex-shrink-0" title="No leído"></div>}
                            </li>
                        ))
                    ) : (
                        <div className="text-center py-12 text-gray-500">
                            <Icon name="notifications_off" className="text-5xl mb-4 mx-auto" />
                            <h3 className="text-lg font-semibold">No tienes notificaciones</h3>
                            <p>Tu centro de notificaciones está vacío.</p>
                        </div>
                    )}
                </ul>
            </Card>
        </div>
    );
};

export default NotificationsPage;
