
import React, { useState, useEffect, useMemo } from 'react';
import { Bar, Line, Pie, Doughnut } from 'react-chartjs-2';
import * as ChartJS from 'chart.js';
import { dataService } from '../services/dataService.ts';
import { Client, Prospect } from '../types.ts';
import Icon from '../components/ui/Icon.tsx';
import Card from '../components/ui/Card.tsx';
import GraphSelectionModal from '../components/statistics/GraphSelectionModal.tsx';
import { exportToExcel } from '../utils/csv.ts';
import { configService } from '../services/configService.ts';
import { useCurrency } from '../contexts/CurrencyContext.tsx';


// Register Chart.js components
ChartJS.Chart.register(
  ChartJS.CategoryScale,
  ChartJS.LinearScale,
  ChartJS.BarElement,
  ChartJS.LineElement,
  ChartJS.PointElement,
  ChartJS.ArcElement,
  ChartJS.Title,
  ChartJS.Tooltip,
  ChartJS.Legend
);

const StatCard: React.FC<{ title: string; value: string; icon: string; className?: string }> = ({ title, value, icon, className }) => (
  <Card className={`transition-transform transform hover:scale-105 ${className}`}>
    <div className="flex items-center justify-between">
      <div>
        <h3 className="text-sm font-medium text-gray-500">{title}</h3>
        <p className="text-3xl font-bold text-gray-800 mt-1">{value}</p>
      </div>
      <div className="bg-teal-100 p-3 rounded-full">
        <Icon name={icon} className="text-teal-600 text-3xl" />
      </div>
    </div>
  </Card>
);

const ChartCard: React.FC<{ title: string; onExport: () => void; isVisible: boolean; children: React.ReactNode; className?: string; }> = ({ title, onExport, isVisible, children, className = '' }) => (
    <div className={`${!isVisible ? 'hidden' : ''} ${className}`}>
        <Card className="flex flex-col animate-fade-in-down h-full">
            <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold text-gray-700">{title}</h3>
                <button 
                    onClick={onExport}
                    className="p-1 text-gray-400 hover:text-gray-700"
                    title="Exportar datos a Excel"
                >
                    <Icon name="download" />
                </button>
            </div>
            <div className="flex-grow h-80">
                {children}
            </div>
        </Card>
    </div>
);


const Statistics: React.FC = () => {
    const [clients, setClients] = useState<Client[]>([]);
    const [prospects, setProspects] = useState<Prospect[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [teamMemberRole, setTeamMemberRole] = useState('Coordinadoras');
    const [dateRange, setDateRange] = useState({ start: '', end: '' });
    const { formatCurrency } = useCurrency();

    const [isModalOpen, setIsModalOpen] = useState(false);
    const [visibleGraphs, setVisibleGraphs] = useState<Record<string, boolean>>({
        ingresosPorMes: true,
        nuevosContactosPorMes: true,
        distribucionOrigen: true,
        rendimientoCoordinadoras: true,
        embudoDeVentas: true,
        ventasPorPais: true,
        programasPopulares: true,
    });
    
    useEffect(() => {
        const fetchData = async () => {
            setIsLoading(true);
            try {
                const [clientsData, prospectsData, role] = await Promise.all([
                    dataService.getClients(),
                    dataService.getProspects(),
                    configService.getTeamMemberRolePlural()
                ]);
                setClients(clientsData);
                setProspects(prospectsData);
                setTeamMemberRole(role);
            } catch (error) {
                console.error("Error fetching statistics data:", error);
            } finally {
                setIsLoading(false);
            }
        };
        fetchData();
    }, []);

    const filteredData = useMemo(() => {
        const startDate = dateRange.start ? new Date(dateRange.start) : null;
        const endDate = dateRange.end ? new Date(dateRange.end) : null;
        if (endDate) endDate.setHours(23, 59, 59, 999); // Include the whole day

        const filteredClients = clients.filter(c => {
            const creationDate = new Date(c.creation_date);
            if (startDate && creationDate < startDate) return false;
            if (endDate && creationDate > endDate) return false;
            return true;
        });
        const filteredProspects = prospects.filter(p => {
             const creationDate = new Date(p.creation_date);
            if (startDate && creationDate < startDate) return false;
            if (endDate && creationDate > endDate) return false;
            return true;
        });

        return { clients: filteredClients, prospects: filteredProspects };
    }, [clients, prospects, dateRange]);


    const generalStats = useMemo(() => {
        const { clients: fClients, prospects: fProspects } = filteredData;
        const totalRevenue = fClients.reduce((sum, client) => sum + (client.estimated_value || 0), 0);
        const avgClientValue = fClients.length > 0 ? totalRevenue / fClients.length : 0;
        
        const convertedCount = fProspects.filter(p => p.stage === 'Cerrado Ganado').length;
        const totalProspects = fProspects.length;
        const conversionRate = totalProspects > 0 ? (convertedCount / totalProspects) * 100 : 0;

        const convertedProspects = fProspects.filter(p => p.stage === 'Cerrado Ganado');
        const conversionTimes = convertedProspects.map(p => {
             const creation = new Date(p.creation_date).getTime();
             const lastContact = new Date(p.last_contact).getTime();
             return (lastContact - creation) / (1000 * 60 * 60 * 24); // in days
        });
        const avgConversionTime = conversionTimes.length > 0 ? conversionTimes.reduce((a, b) => a + b, 0) / conversionTimes.length : 0;

        return {
            totalRevenue,
            avgClientValue,
            conversionRate,
            avgConversionTime,
        };
    }, [filteredData]);

    const chartData = useMemo(() => {
        if (isLoading) return {};
        const { clients: fClients, prospects: fProspects } = filteredData;

        // 1. Ingresos por Mes
        const monthlyRevenue: { [key: string]: number } = {};
        fClients.forEach(client => {
            const month = new Date(client.creation_date).toISOString().slice(0, 7); // YYYY-MM
            monthlyRevenue[month] = (monthlyRevenue[month] || 0) + client.estimated_value;
        });
        const sortedMonths = Object.keys(monthlyRevenue).sort();
        const ingresosPorMes = {
            labels: sortedMonths,
            datasets: [{
                label: 'Ingresos',
                data: sortedMonths.map(m => monthlyRevenue[m]),
                borderColor: 'rgb(16, 185, 129)',
                backgroundColor: 'rgba(16, 185, 129, 0.2)',
                fill: true,
                tension: 0.3
            }]
        };

        // 2. Nuevos Clientes vs Prospectos
        const monthlyNewClients: { [key: string]: number } = {};
        const monthlyNewProspects: { [key: string]: number } = {};
        fClients.forEach(c => {
             const month = new Date(c.creation_date).toISOString().slice(0, 7);
             monthlyNewClients[month] = (monthlyNewClients[month] || 0) + 1;
        });
        fProspects.forEach(p => {
            const month = new Date(p.creation_date).toISOString().slice(0, 7);
            monthlyNewProspects[month] = (monthlyNewProspects[month] || 0) + 1;
        });
        const allMonths = [...new Set([...Object.keys(monthlyNewClients), ...Object.keys(monthlyNewProspects)])].sort();
        const nuevosContactosPorMes = {
            labels: allMonths,
            datasets: [
                { label: 'Nuevos Clientes', data: allMonths.map(m => monthlyNewClients[m] || 0), backgroundColor: '#10B981' },
                { label: 'Nuevos Prospectos', data: allMonths.map(m => monthlyNewProspects[m] || 0), backgroundColor: '#065F46' }
            ]
        }

        // 3. Distribución de Origen
        const originCounts: { [key: string]: number } = {};
        [...fClients, ...fProspects].forEach(c => {
            const origin = c.origin || 'Desconocido';
            originCounts[origin] = (originCounts[origin] || 0) + 1;
        });
        const distribucionOrigen = {
            labels: Object.keys(originCounts),
            datasets: [{
                data: Object.values(originCounts),
                backgroundColor: ['#10B981', '#F59E0B', '#3B82F6', '#8B5CF6', '#EC4899', '#6B7280'],
            }]
        };

        // 4. Rendimiento Coordinadoras
        const coordinatorPerformance: { [key: string]: { clients: number, revenue: number } } = {};
        fClients.forEach(client => {
            const coord = client.coordinator || 'Sin Asignar';
            if (!coordinatorPerformance[coord]) coordinatorPerformance[coord] = { clients: 0, revenue: 0 };
            coordinatorPerformance[coord].clients++;
            coordinatorPerformance[coord].revenue += client.estimated_value;
        });
        const rendimientoCoordinadoras = {
             labels: Object.keys(coordinatorPerformance),
             datasets: [{
                 label: 'Ingresos Generados',
                 data: Object.values(coordinatorPerformance).map(c => c.revenue),
                 backgroundColor: '#3B82F6',
             }]
        }
        
        // 5. Embudo de Ventas
        const prospectStages = ['Nuevo', 'Calificado', 'Propuesta', 'Negociación', 'Cerrado Ganado'];
        const stageCounts = prospectStages.map(stage => fProspects.filter(p => p.stage === stage).length);
        const embudoDeVentas = {
            labels: prospectStages,
            datasets: [{
                label: 'Prospectos en Etapa',
                data: stageCounts,
                backgroundColor: ['#6366F1', '#A78BFA', '#FBBF24', '#60A5FA', '#34D399'],
            }]
        };
        
        // 6. Ventas por País
        const countrySales: { [key: string]: number } = {};
        fClients.forEach(client => {
            const country = client.country || 'Desconocido';
            countrySales[country] = (countrySales[country] || 0) + client.estimated_value;
        });
        const ventasPorPais = {
            labels: Object.keys(countrySales),
            datasets: [{
                label: 'Ventas Totales',
                data: Object.values(countrySales),
                backgroundColor: Object.keys(countrySales).map((_, i) => `hsl(${i * 40}, 70%, 60%)`),
            }]
        };
        
        // 7. Programas más populares
        const programCounts: { [key: string]: number } = {};
        [...fClients, ...fProspects].forEach(c => {
            if (c.program) {
                programCounts[c.program] = (programCounts[c.program] || 0) + 1;
            }
        });
        const topPrograms = Object.entries(programCounts).sort(([,a],[,b]) => b - a).slice(0, 10);
        const programasPopulares = {
            labels: topPrograms.map(p => p[0]),
            datasets: [{
                label: 'Número de Contactos',
                data: topPrograms.map(p => p[1]),
                backgroundColor: '#8B5CF6',
            }]
        };


        return { ingresosPorMes, nuevosContactosPorMes, distribucionOrigen, rendimientoCoordinadoras, embudoDeVentas, ventasPorPais, programasPopulares };
    }, [filteredData, isLoading, formatCurrency]);
    
    const handleSaveGraphSelection = (selection: Record<string, boolean>) => {
        setVisibleGraphs(selection);
        setIsModalOpen(false);
    };

    const handleExport = (chartKey: string, chartName: string) => {
        const chart = (chartData as any)[chartKey];
        if (!chart) return;

        const dataToExport = chart.labels.map((label: string, index: number) => {
            const row: {[key: string]: any} = { Categoria: label };
            chart.datasets.forEach((dataset: any) => {
                row[dataset.label] = dataset.data[index];
            });
            return row;
        });
        exportToExcel(`${chartName}.xlsx`, dataToExport);
    }
    
    const chartOptions = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: { position: 'top' as const },
        },
    };
    
    const currencyTooltip = {
        callbacks: {
            label: (context: any) => {
                let label = context.dataset.label || context.label || '';
                let value = context.parsed.y ?? context.parsed;
                if (label) {
                    label += ': ';
                }
                if (value !== null) {
                    label += formatCurrency(value);
                }
                return label;
            }
        }
    };
    
    const currencyYAxis = {
        ticks: {
            callback: (value: string | number) => formatCurrency(Number(value))
        }
    };
    
    return (
        <div className="p-4 sm:p-6 bg-gray-50/50">
            {isLoading && (
                 <div className="fixed inset-0 bg-white/70 flex items-center justify-center z-50">
                    <div className="text-center">
                        <Icon name="hourglass_top" className="text-4xl text-gray-500 animate-spin mb-4" />
                        <p className="text-lg font-medium text-gray-600">Calculando estadísticas...</p>
                    </div>
                </div>
            )}
            <header className="mb-6 bg-white p-4 rounded-lg shadow-sm border">
                <div className="flex justify-between items-center flex-wrap gap-4">
                    <div>
                         <h1 className="text-3xl font-bold text-gray-800">Panel de Estadísticas</h1>
                         <p className="text-sm text-gray-500">Analiza a fondo el rendimiento de tu negocio.</p>
                    </div>
                    <button onClick={() => setIsModalOpen(true)} className="bg-white hover:bg-gray-100 text-gray-800 font-medium py-2 px-4 rounded-lg flex items-center transition-colors shadow-sm border border-gray-300">
                        <Icon name="grid_view" className="mr-2" />
                        Gestionar Gráficos
                    </button>
                </div>
                 <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4 pt-4 border-t">
                    <div>
                        <label htmlFor="startDate" className="text-sm font-medium text-gray-700">Fecha de Inicio</label>
                        <input type="date" name="start" id="startDate" value={dateRange.start} onChange={(e) => setDateRange(prev => ({...prev, start: e.target.value}))} className="w-full mt-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-teal-500 focus:border-teal-500"/>
                    </div>
                    <div>
                        <label htmlFor="endDate" className="text-sm font-medium text-gray-700">Fecha de Fin</label>
                        <input type="date" name="end" id="endDate" value={dateRange.end} onChange={(e) => setDateRange(prev => ({...prev, end: e.target.value}))} className="w-full mt-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-teal-500 focus:border-teal-500"/>
                    </div>
                    <div className="self-end">
                         <button onClick={() => setDateRange({start: '', end: ''})} className="w-full bg-white hover:bg-gray-100 text-gray-800 font-medium py-2 px-4 rounded-lg flex items-center justify-center transition-colors shadow-sm border border-gray-300">
                            <Icon name="refresh" className="mr-2" />
                            Limpiar Fechas
                        </button>
                    </div>
                </div>
            </header>
            
            <main className={`space-y-6 ${isLoading ? 'opacity-20 blur-sm' : ''}`}>
                 <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    <StatCard title="Ingresos Totales" value={formatCurrency(generalStats.totalRevenue)} icon="payments" />
                    <StatCard title="Valor Prom. Cliente" value={formatCurrency(generalStats.avgClientValue)} icon="trending_up" />
                    <StatCard title="Tasa de Conversión" value={`${generalStats.conversionRate.toFixed(1)}%`} icon="percent" />
                    <StatCard title="Tiempo Prom. Conversión" value={`${generalStats.avgConversionTime.toFixed(1)} días`} icon="speed" />
                </div>
                
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <ChartCard title="Ingresos por Mes" isVisible={visibleGraphs.ingresosPorMes} onExport={() => handleExport('ingresosPorMes', 'Ingresos por Mes')}>
                        <Line options={{...chartOptions, plugins: { ...chartOptions.plugins, tooltip: currencyTooltip }, scales: { y: currencyYAxis }}} data={(chartData as any).ingresosPorMes || {labels:[], datasets:[]}} />
                    </ChartCard>
                    <ChartCard title="Nuevos Clientes vs. Prospectos" isVisible={visibleGraphs.nuevosContactosPorMes} onExport={() => handleExport('nuevosContactosPorMes', 'Nuevos Contactos por Mes')}>
                        <Bar options={chartOptions} data={(chartData as any).nuevosContactosPorMes || {labels:[], datasets:[]}} />
                    </ChartCard>
                    <ChartCard title="Distribución de Origen" isVisible={visibleGraphs.distribucionOrigen} onExport={() => handleExport('distribucionOrigen', 'Distribucion de Origen')}>
                        <Doughnut options={{...chartOptions, plugins: {legend: {position: 'right'}}}} data={(chartData as any).distribucionOrigen || {labels:[], datasets:[]}} />
                    </ChartCard>
                     <ChartCard title={`Rendimiento de ${teamMemberRole} (por Ingresos)`} isVisible={visibleGraphs.rendimientoCoordinadoras} onExport={() => handleExport('rendimientoCoordinadoras', `Rendimiento de ${teamMemberRole}`)}>
                        <Bar options={{...chartOptions, plugins: { ...chartOptions.plugins, tooltip: currencyTooltip }, scales: { y: currencyYAxis }}} data={(chartData as any).rendimientoCoordinadoras || {labels:[], datasets:[]}} />
                    </ChartCard>
                    <ChartCard title="Embudo de Ventas de Prospectos" isVisible={visibleGraphs.embudoDeVentas} onExport={() => handleExport('embudoDeVentas', 'Embudo de Ventas')}>
                        <Bar options={{...chartOptions, indexAxis: 'y', plugins: { legend: { display: false }}}} data={(chartData as any).embudoDeVentas || {labels:[], datasets:[]}} />
                    </ChartCard>
                     <ChartCard title="Ventas por País" isVisible={visibleGraphs.ventasPorPais} onExport={() => handleExport('ventasPorPais', 'Ventas por Pais')}>
                        <Pie options={{...chartOptions, plugins: { ...chartOptions.plugins, tooltip: currencyTooltip }}} data={(chartData as any).ventasPorPais || {labels:[], datasets:[]}} />
                    </ChartCard>
                    <ChartCard title="Programas Más Populares" isVisible={visibleGraphs.programasPopulares} onExport={() => handleExport('programasPopulares', 'Programas Populares')} className="lg:col-span-2">
                        <Bar options={{...chartOptions, indexAxis: 'y', plugins: { legend: { display: false }}}} data={(chartData as any).programasPopulares || {labels:[], datasets:[]}} />
                    </ChartCard>
                </div>
            </main>
            
            <GraphSelectionModal
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                onSave={handleSaveGraphSelection}
                currentSelection={visibleGraphs}
                teamMemberRole={teamMemberRole}
            />
        </div>
    );
}

export default Statistics;
