
import React, { useState, useEffect, useCallback } from 'react';
import Card from '../components/ui/Card.tsx';
import Icon from '../components/ui/Icon.tsx';
import { dataService } from '../services/dataService.ts';
import { authService } from '../services/authService.ts';
import { Client, Prospect, User, Profile } from '../types.ts';
import { supabase } from '../services/supabaseClient.ts';

const Email: React.FC = () => {
    const [allRecipients, setAllRecipients] = useState<(Client | Prospect | Profile)[]>([]);
    const [currentUser, setCurrentUser] = useState<User | null>(null);
    const [selectedRecipient, setSelectedRecipient] = useState('');
    const [subject, setSubject] = useState('');
    const [body, setBody] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [statusMessage, setStatusMessage] = useState({ type: '', text: '' });

    const fetchInitialData = useCallback(async () => {
        const user = await authService.getUser();
        setCurrentUser(user);

        if (user?.profile) {
            const userRole = user.profile.role;
            const [clients, prospects, users] = await Promise.all([
                dataService.getClients(),
                dataService.getProspects(),
                dataService.getUsers(),
            ]);

            let combinedRecipients: (Client | Prospect | Profile)[] = [];

            if (userRole === 'platform_admin') {
                // Platform admin can see everyone
                combinedRecipients = [...clients, ...prospects, ...users.filter(u => u.id !== user.id)];
            } else if (userRole === 'crm_admin') {
                // CRM admin can see their contacts and collaborators
                const teamMembers = users.filter(u => u.id !== user.id);
                combinedRecipients = [...clients, ...prospects, ...teamMembers];
            } else if (userRole === 'crm_collaborator') {
                // Collaborator can only see contacts
                combinedRecipients = [...clients, ...prospects];
            }
            
            setAllRecipients(combinedRecipients.sort((a, b) => (('name' in a ? a.name : a.full_name) || '').localeCompare(('name' in b ? b.name : b.full_name) || '')));
        }
    }, []);

    useEffect(() => {
        fetchInitialData();
    }, [fetchInitialData]);

    const handleSend = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        setStatusMessage({ type: '', text: '' });

        if (!selectedRecipient || !subject || !body) {
            setStatusMessage({ type: 'error', text: 'Error: Debes completar todos los campos.' });
            setIsLoading(false);
            return;
        }

        const { data, error } = await supabase.functions.invoke('send-email', {
            body: {
                to: selectedRecipient,
                subject,
                body,
            },
        });

        if (error) {
            setStatusMessage({ type: 'error', text: error.message || 'Ocurrió un error al enviar el correo.' });
        } else {
            setStatusMessage({ type: 'success', text: data.message || '¡Correo enviado exitosamente!' });
            setSelectedRecipient('');
            setSubject('');
            setBody('');
        }

        setIsLoading(false);
    };

    return (
        <div className="p-4 sm:p-6">
            <header className="mb-6">
                 <h2 className="text-2xl font-bold text-gray-800">Envío de Correos</h2>
                 <p className="text-gray-600 mt-1">
                    Envía correos a tus contactos y colaboradores directamente desde el CRM.
                </p>
            </header>

            <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
                <div className="lg:col-span-3">
                    <Card>
                        <form onSubmit={handleSend} className="space-y-4">
                            <div>
                                <label htmlFor="from" className="block text-sm font-medium text-gray-700">De</label>
                                <input 
                                    type="text" 
                                    id="from" 
                                    value={`contacto@gestion360pro.com (Responder a: ${currentUser?.email || ''})`} 
                                    readOnly 
                                    className="mt-1 block w-full bg-gray-100 border border-gray-300 rounded-md shadow-sm py-2 px-3 text-gray-500"
                                />
                            </div>
                            <div>
                                <label htmlFor="recipient" className="block text-sm font-medium text-gray-700">Para (Destinatario)</label>
                                <select
                                    id="recipient"
                                    value={selectedRecipient}
                                    onChange={(e) => setSelectedRecipient(e.target.value)}
                                    required
                                    className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-teal-500 focus:border-teal-500 sm:text-sm rounded-md"
                                >
                                    <option value="">Selecciona un destinatario...</option>
                                    {allRecipients.map(r => {
                                        const email = r.email;
                                        const name = 'name' in r ? r.name : r.full_name;
                                        const type = 'role' in r ? `(Colaborador)` : ('stage' in r ? `(${'payment_type' in r ? 'Cliente' : 'Prospecto'})` : '');

                                        return (
                                            <option key={r.id} value={email || ''}>
                                                {name} {type} {email && `<${email}>`}
                                            </option>
                                        )
                                    })}
                                </select>
                            </div>
                            <div>
                                <label htmlFor="subject" className="block text-sm font-medium text-gray-700">Asunto</label>
                                <input type="text" id="subject" value={subject} onChange={(e) => setSubject(e.target.value)} required className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-teal-500 focus:border-teal-500 sm:text-sm" placeholder="Ej: Propuesta de servicios" />
                            </div>
                            <div>
                                <label htmlFor="body" className="block text-sm font-medium text-gray-700">Mensaje</label>
                                <textarea id="body" rows={8} value={body} onChange={(e) => setBody(e.target.value)} required className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-teal-500 focus:border-teal-500 sm:text-sm" placeholder="Escribe tu mensaje aquí..." />
                            </div>
                            <div>
                                <button type="submit" disabled={isLoading} className="w-full flex justify-center items-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-teal-600 hover:bg-teal-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors">
                                    {isLoading ? <Icon name="hourglass_top" className="animate-spin mr-2"/> : <Icon name="send" className="mr-2"/>}
                                    {isLoading ? 'Enviando...' : 'Enviar Correo'}
                                </button>
                            </div>
                             {statusMessage.text && <div className={`p-3 mt-4 text-sm rounded-lg text-center ${statusMessage.type === 'success' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>{statusMessage.text}</div>}
                        </form>
                    </Card>
                </div>
                <div className="lg:col-span-2 space-y-6">
                     <Card>
                        <div className="flex items-center gap-3 mb-3">
                            <Icon name="info" className="text-2xl text-blue-500" />
                            <h3 className="text-lg font-bold text-gray-800">Información de Envío</h3>
                        </div>
                        <div className="space-y-2 text-sm text-gray-600">
                           <p>
                                <strong>Remitente Fijo:</strong> Todos los correos se envían desde 
                                <code className="bg-gray-100 p-1 rounded text-xs mx-1">contacto@gestion360pro.com</code> para asegurar la entrega.
                           </p>
                           <p>
                                <strong>Responder a:</strong> Las respuestas de los destinatarios se dirigirán a tu correo de usuario: 
                                <code className="bg-gray-100 p-1 rounded text-xs mx-1">{currentUser?.email}</code>.
                           </p>
                           <p>
                                <strong>Límite de Envío:</strong> Para proteger la reputación del servidor, existe un límite de 5 correos por minuto.
                           </p>
                           <p className="font-bold text-teal-700 pt-2 border-t mt-2">
                                ¡Ahora con la potencia de Resend para una mayor fiabilidad!
                           </p>
                        </div>
                    </Card>
                </div>
            </div>
        </div>
    );
};

export default Email;
