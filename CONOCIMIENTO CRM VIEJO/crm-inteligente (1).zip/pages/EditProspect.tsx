import React, { useState, useEffect } from 'react';
import ContactForm from '../components/forms/ContactForm.tsx';
import { dataService } from '../services/dataService.ts';
import { Prospect } from '../types.ts';

interface EditProspectProps {
    id: string;
    onCancel: () => void;
    onSave: () => void;
}

const EditProspect: React.FC<EditProspectProps> = ({ id, onCancel, onSave }) => {
    const [prospect, setProspect] = useState<Prospect | null>(null);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        dataService.getProspectById(id)
            .then(setProspect)
            .finally(() => setIsLoading(false));
    }, [id]);

    if (isLoading) {
        return <div className="p-8 text-center">Cargando prospecto...</div>;
    }
    
    if (!prospect) {
         return <div className="p-8 text-center text-red-500">No se pudo encontrar el prospecto.</div>;
    }

    return <ContactForm entityType="prospect" initialData={prospect} onCancel={onCancel} onSave={onSave} />;
};

export default EditProspect;