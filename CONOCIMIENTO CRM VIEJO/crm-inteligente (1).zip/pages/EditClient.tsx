import React, { useState, useEffect } from 'react';
import ContactForm from '../components/forms/ContactForm.tsx';
import { dataService } from '../services/dataService.ts';
import { Client } from '../types.ts';

interface EditClientProps {
    id: string;
    onCancel: () => void;
    onSave: () => void;
}

const EditClient: React.FC<EditClientProps> = ({ id, onCancel, onSave }) => {
    const [client, setClient] = useState<Client | null>(null);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        dataService.getClientById(id)
            .then(setClient)
            .finally(() => setIsLoading(false));
    }, [id]);

    if (isLoading) {
        return <div className="p-8 text-center">Cargando cliente...</div>;
    }
    
    if (!client) {
         return <div className="p-8 text-center text-red-500">No se pudo encontrar el cliente.</div>;
    }

    return <ContactForm entityType="client" initialData={client} onCancel={onCancel} onSave={onSave} />;
};

export default EditClient;