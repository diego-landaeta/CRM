import React, { useState, useEffect, useMemo } from 'react';
import Icon from '../components/ui/Icon.tsx';
import { configService } from '../services/configService.ts';
import { FieldConfig, EntityType, CoordinatorMap, User, Json, Page } from '../types.ts';
import { authService } from '../services/authService.ts';
import QuickCreateManager from '../components/config/QuickCreateManager.tsx';
import AcademicOfferManager from '../components/config/AcademicOfferManager.tsx';
import InfoModal from '../components/ui/InfoModal.tsx';
import ConfirmationModal from '../components/ui/ConfirmationModal.tsx';
import { useCurrency } from '../contexts/CurrencyContext.tsx';

const SettingsToggle: React.FC<{ label: string; enabled: boolean; onChange: () => void }> = ({ label, enabled, onChange }) => (
     <div className="flex items-center justify-between p-2 rounded-md hover:bg-gray-50">
        <span className="text-sm font-medium text-gray-700">{label}</span>
        <button
            type="button"
            onClick={onChange}
            className={`${enabled ? 'bg-teal-600' : 'bg-gray-200'} relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500`}
        >
            <span className={`${enabled ? 'translate-x-6' : 'translate-x-1'} inline-block w-4 h-4 transform bg-white rounded-full transition-transform`} />
        </button>
    </div>
);

const AccountManager: React.FC<{ onSaveSuccess: (message: string) => void, showSaveConfirmation: (onConfirm: () => Promise<void>) => void }> = ({ onSaveSuccess, showSaveConfirmation }) => {
    const [user, setUser] = useState<User | null>(null);
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [error, setError] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    useEffect(() => {
        const fetchUser = async () => {
            const currentUser = await authService.getUser();
            setUser(currentUser);
        }
        fetchUser();
    }, []);

    const handleSave = async () => {
        setError('');
        if (!password || password.length < 6) {
            setError("La contraseña debe tener al menos 6 caracteres.");
            return;
        }
        if (password !== confirmPassword) {
            setError("Las contraseñas no coinciden.");
            return;
        }
        
        const performSave = async () => {
            setIsLoading(true);
            try {
                await authService.updatePassword(password);
                onSaveSuccess("Contraseña actualizada exitosamente. Se ha enviado una notificación a tu correo electrónico.");
                setPassword('');
                setConfirmPassword('');
            } catch (err: any) {
                setError(err.message || 'Ocurrió un error al actualizar la contraseña.');
            } finally {
                setIsLoading(false);
            }
        };
        
        showSaveConfirmation(performSave);
    };

    if (!user) return <div className="bg-white rounded-lg shadow p-6">Cargando datos de usuario...</div>;

    return (
        <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-xl font-semibold mb-4 border-b pb-3">Mi Cuenta y Seguridad</h2>
            <div className="space-y-4">
                <div>
                    <label className="block text-sm font-medium text-gray-700">Nombre de Usuario</label>
                    <input type="text" value={user.profile?.full_name || ''} readOnly className="mt-1 block w-full bg-gray-100 border-gray-300 rounded-md shadow-sm p-2"/>
                </div>
                 <div>
                    <label className="block text-sm font-medium text-gray-700">Email</label>
                    <input type="email" value={user.email} readOnly className="mt-1 block w-full bg-gray-100 border-gray-300 rounded-md shadow-sm p-2"/>
                </div>
                 <div>
                    <label className="block text-sm font-medium text-gray-700">Nueva Contraseña</label>
                    <input type="password" value={password} onChange={e => setPassword(e.target.value)} className="mt-1 block w-full border-gray-300 rounded-md shadow-sm p-2 focus:ring-teal-500 focus:border-teal-500"/>
                </div>
                 <div>
                    <label className="block text-sm font-medium text-gray-700">Confirmar Nueva Contraseña</label>
                    <input type="password" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} className="mt-1 block w-full border-gray-300 rounded-md shadow-sm p-2 focus:ring-teal-500 focus:border-teal-500"/>
                </div>
                {error && <p className="text-sm text-red-600">{error}</p>}
            </div>
            <div className="flex justify-end mt-6">
                <button onClick={handleSave} disabled={isLoading} className="bg-teal-600 text-white font-medium py-2 px-4 rounded-lg hover:bg-teal-700 transition-colors disabled:bg-gray-400">
                    {isLoading ? 'Guardando...' : 'Guardar Cambios'}
                </button>
            </div>
        </div>
    );
};


const FieldCustomizer: React.FC<{ entity: EntityType; onSaveSuccess: (message: string) => void, showSaveConfirmation: (onConfirm: () => Promise<void>) => void }> = ({ entity, onSaveSuccess, showSaveConfirmation }) => {
    const [config, setConfig] = useState<FieldConfig[]>([]);

    useEffect(() => {
        const fetchConfig = async () => {
            setConfig(await configService.getFieldConfig(entity));
        };
        fetchConfig();
    }, [entity]);


    const handleLabelChange = (key: string, newLabel: string) => {
        setConfig(prev => prev.map(f => f.key === key ? { ...f, label: newLabel } : f));
    };

    const handleVisibilityChange = (key: string) => {
        setConfig(prev => prev.map(f => f.key === key ? { ...f, isVisible: !f.isVisible } : f));
    };
    
    const handleSave = async () => {
        showSaveConfirmation(async () => {
            await configService.updateFieldConfig(entity, config);
            onSaveSuccess(`Configuración de campos para ${entity === 'client' ? 'Cliente' : 'Prospecto'} guardada.`);
        });
    };

    return (
        <div>
            <div className="space-y-4">
                {config.filter(f => f.key !== 'creation_date').map(field => (
                    <div key={field.key} className="grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
                       <div className="md:col-span-1">
                           <input 
                             type="text" 
                             value={field.label}
                             onChange={(e) => handleLabelChange(field.key, e.target.value)}
                             className="w-full text-sm font-medium px-3 py-2 border border-gray-300 rounded-md focus:ring-teal-500 focus:border-teal-500"
                           />
                       </div>
                       <div className="md:col-span-2">
                           <SettingsToggle label="Visible en tablas" enabled={field.isVisible} onChange={() => handleVisibilityChange(field.key)} />
                       </div>
                    </div>
                ))}
            </div>
             <div className="flex justify-end mt-6">
                <button onClick={handleSave} className="bg-teal-600 text-white font-medium py-2 px-4 rounded-lg hover:bg-teal-700 transition-colors">
                    Guardar Cambios de {entity === 'client' ? 'Cliente' : 'Prospecto'}
                </button>
            </div>
        </div>
    );
};

const TeamManager: React.FC<{ onSaveSuccess: (message: string) => void, showSaveConfirmation: (onConfirm: () => Promise<void>) => void, showConfirmation: (title: string, message: string, onConfirm: () => Promise<void>) => void }> = ({ onSaveSuccess, showSaveConfirmation, showConfirmation }) => {
    const [members, setMembers] = useState<string[]>([]);
    const [roleLabel, setRoleLabel] = useState('Coordinadoras');
    const [singularRole, setSingularRole] = useState('Coordinadora');
    const [newMember, setNewMember] = useState('');
    const [isEditingLabel, setIsEditingLabel] = useState(false);
    const [tempRoleLabel, setTempRoleLabel] = useState('');
    const [error, setError] = useState('');
    const [isSaving, setIsSaving] = useState(false);
    const [initialMembers, setInitialMembers] = useState<string[]>([]);
    const [initialRoleLabel, setInitialRoleLabel] = useState('Coordinadoras');

    const fetchTeamData = async () => {
        const [memberList, plural, single] = await Promise.all([
            configService.getCoordinators(),
            configService.getTeamMemberRolePlural(),
            configService.getTeamMemberRoleSingular()
        ]);
        setMembers(memberList);
        setInitialMembers(memberList);
        setRoleLabel(plural);
        setInitialRoleLabel(plural);
        setSingularRole(single);
        setTempRoleLabel(plural);
    };

    useEffect(() => {
        fetchTeamData();
        window.addEventListener('config_updated', fetchTeamData);
        return () => window.removeEventListener('config_updated', fetchTeamData);
    }, []);

    const isDirty = useMemo(() => {
        const membersChanged = JSON.stringify(members.sort()) !== JSON.stringify(initialMembers.sort());
        const labelChanged = roleLabel !== initialRoleLabel;
        return membersChanged || labelChanged;
    }, [members, initialMembers, roleLabel, initialRoleLabel]);

    const handleAdd = (e: React.FormEvent) => {
        e.preventDefault();
        if (newMember.trim() && !members.includes(newMember.trim())) {
            setMembers(prev => [...prev, newMember.trim()]);
            setNewMember('');
        }
    };

    const handleDelete = (name: string) => {
        showConfirmation(
            `Eliminar ${singularRole}`,
            `¿Estás seguro de que quieres eliminar a "${name}" de la lista? Los cambios se guardarán al hacer clic en "Guardar Cambios".`,
            async () => {
                setMembers(prev => prev.filter(m => m !== name));
            }
        );
    };

    const handleLabelEdit = () => {
        setTempRoleLabel(roleLabel);
        setIsEditingLabel(true);
    };

    const handleTempLabelChange = () => {
        if (tempRoleLabel.trim()) {
            setRoleLabel(tempRoleLabel.trim());
        }
        setIsEditingLabel(false);
    };

    const handleLabelKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
        if (e.key === 'Enter') {
            handleTempLabelChange();
        } else if (e.key === 'Escape') {
            setIsEditingLabel(false);
        }
    };

    const handleSave = () => {
        setError('');
        showSaveConfirmation(async () => {
            setIsSaving(true);
            try {
                const [clientFields, prospectFields] = await Promise.all([
                    configService.getFieldConfig('client'),
                    configService.getFieldConfig('prospect')
                ]);

                const plural = roleLabel.trim();
                let singular = plural;
                if (plural.toLowerCase().endsWith('es')) {
                    singular = plural.slice(0, -2);
                } else if (plural.toLowerCase().endsWith('s')) {
                    singular = plural.slice(0, -1);
                }
                
                const newClientFields = clientFields.map(f => f.key === 'coordinator' ? { ...f, label: singular } : f);
                const newProspectFields = prospectFields.map(f => f.key === 'coordinator' ? { ...f, label: singular } : f);

                const newFieldConfig = {
                    client: newClientFields,
                    prospect: newProspectFields,
                };

                await configService.updateConfig({
                    coordinators: members,
                    team_member_role_plural: roleLabel,
                    field_config: newFieldConfig as unknown as Json,
                });
                onSaveSuccess('Los cambios en el equipo han sido guardados.');
            } catch (err: any) {
                console.error("Failed to save team changes:", err);
                const errorMessage = err.message || 'No se pudieron guardar los cambios. Inténtalo de nuevo.';
                setError(errorMessage);
            } finally {
                setIsSaving(false);
            }
        });
    };
    
    return (
        <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between border-b pb-3 mb-4">
                {isEditingLabel ? (
                    <input
                        type="text"
                        value={tempRoleLabel}
                        onChange={(e) => setTempRoleLabel(e.target.value)}
                        onBlur={handleTempLabelChange}
                        onKeyDown={handleLabelKeyDown}
                        className="text-lg font-semibold bg-transparent border-b-2 border-teal-500 focus:outline-none"
                        autoFocus
                    />
                ) : (
                    <h3 className="text-lg font-semibold">Gestión de {roleLabel}</h3>
                )}
                <button onClick={handleLabelEdit} className="text-gray-500 hover:text-teal-600 p-1" aria-label="Editar nombre del rol">
                    <Icon name="edit" className="text-base" />
                </button>
            </div>
            <div className="space-y-3 mb-4 max-h-48 overflow-y-auto pr-2">
                {members.map(c => (
                    <div key={c} className="flex items-center justify-between bg-gray-50 p-2 rounded-md">
                        <span className="text-gray-700">{c}</span>
                        <button onClick={() => handleDelete(c)} className="text-gray-500 hover:text-red-600 p-1"><Icon name="delete" className="text-base" /></button>
                    </div>
                ))}
                 {members.length === 0 && <p className="text-center text-sm text-gray-500 py-4">No hay miembros del equipo.</p>}
            </div>
            <form onSubmit={handleAdd} className="flex gap-4 mt-6">
                <input
                    type="text"
                    value={newMember}
                    onChange={e => setNewMember(e.target.value)}
                    placeholder={`Añadir ${singularRole.toLowerCase()}`}
                    className="flex-grow w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-teal-500 focus:border-teal-500"
                />
                <button type="submit" className="bg-teal-600 text-white font-medium py-2 px-4 rounded-lg hover:bg-teal-700">Añadir</button>
            </form>
             <div className="flex justify-end items-center gap-4 mt-6 pt-4 border-t">
                {error && <p className="text-sm text-red-600 text-right">{error}</p>}
                <button 
                    onClick={handleSave} 
                    disabled={!isDirty || isSaving}
                    className="bg-green-600 text-white font-medium py-2 px-4 rounded-lg hover:bg-green-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center justify-center min-w-[150px]"
                >
                    {isSaving ? <Icon name="hourglass_top" className="animate-spin" /> : 'Guardar Cambios'}
                </button>
            </div>
        </div>
    );
};

const CountryManager: React.FC<{ onActionSuccess: (message: string) => void, showConfirmation: (title: string, message: string, onConfirm: () => Promise<void>) => void, teamMemberRolePlural: string }> = ({ onActionSuccess, showConfirmation, teamMemberRolePlural }) => {
    const [countries, setCountries] = useState<string[]>([]);
    const [newCountry, setNewCountry] = useState('');

    const fetchCountries = async () => {
        setCountries(await configService.getCountries());
    };

    useEffect(() => {
        fetchCountries();
        window.addEventListener('config_updated', fetchCountries);
        return () => window.removeEventListener('config_updated', fetchCountries);
    }, []);

    const handleAdd = async (e: React.FormEvent) => {
        e.preventDefault();
        if (newCountry.trim()) {
            await configService.addCountry(newCountry.trim());
            onActionSuccess(`País "${newCountry.trim()}" añadido correctamente.`);
            setNewCountry('');
        }
    };

    const handleDelete = (name: string) => {
        showConfirmation(
            'Confirmar Eliminación',
            `¿Seguro que quieres eliminar el país "${name}"? Esta acción no se puede deshacer.`,
            async () => {
                await configService.deleteCountry(name);
                onActionSuccess(`País "${name}" eliminado.`);
            }
        );
    };

    return (
        <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-semibold border-b pb-3 mb-4">Gestión de Países</h3>
             <p className="text-sm text-gray-600 mb-4">
                Administra la lista de países para tus contactos.
            </p>
            <div className="space-y-3 mb-4 max-h-48 overflow-y-auto pr-2">
                {countries.map(country => (
                    <div key={country} className="flex items-center justify-between bg-gray-50 p-2 rounded-md">
                        <span className="text-gray-700 font-medium">{country}</span>
                        <button onClick={() => handleDelete(country)} className="text-gray-500 hover:text-red-600 p-1"><Icon name="delete" className="text-base" /></button>
                    </div>
                ))}
            </div>
            <form onSubmit={handleAdd} className="flex gap-4 mt-6">
                <input type="text" value={newCountry} onChange={e => setNewCountry(e.target.value)} placeholder="Nuevo país" className="flex-grow w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-teal-500 focus:border-teal-500"/>
                <button type="submit" className="bg-teal-600 text-white font-medium py-2 px-4 rounded-lg hover:bg-teal-700">Añadir</button>
            </form>
        </div>
    );
};

const CoordinatorAssignmentManager: React.FC<{ onSaveSuccess: (message: string) => void, showSaveConfirmation: (onConfirm: () => Promise<void>) => void, teamMemberRolePlural: string }> = ({ onSaveSuccess, showSaveConfirmation, teamMemberRolePlural }) => {
    const [map, setMap] = useState<CoordinatorMap>({});
    const [coordinators, setCoordinators] = useState<string[]>([]);
    const [countries, setCountries] = useState<string[]>([]);
    
    useEffect(() => {
        const handleConfigUpdate = async () => {
            setMap(await configService.getCoordinatorMap());
            setCoordinators(await configService.getCoordinators());
            setCountries(await configService.getCountries());
        };
        handleConfigUpdate();
        window.addEventListener('config_updated', handleConfigUpdate);
        return () => window.removeEventListener('config_updated', handleConfigUpdate);
    }, []);

    const handleCoordinatorChange = (country: string, coordinator: string) => {
        setMap(prev => ({...prev, [country]: coordinator}));
    };
    
    const handleSave = async () => {
        showSaveConfirmation(async () => {
            await configService.updateCoordinatorMap(map);
            onSaveSuccess(`Asignaciones de ${teamMemberRolePlural.toLowerCase()} guardadas exitosamente.`);
        });
    };

    return (
         <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-semibold border-b pb-3 mb-4">Asignación Automática de {teamMemberRolePlural}</h3>
            <p className="text-sm text-gray-600 mb-4">
                Asigna un miembro del equipo a un país para que sea seleccionado automáticamente al crear un nuevo contacto de ese país.
            </p>
            <div className="space-y-4">
                {countries.map(country => (
                    <div key={country} className="grid grid-cols-2 gap-4 items-center">
                        <label className="font-medium text-gray-700">{country}</label>
                        <select 
                            value={map[country] || ''} 
                            onChange={(e) => handleCoordinatorChange(country, e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-teal-500 focus:border-teal-500"
                        >
                            <option value="">Sin Asignar</option>
                            {coordinators.map(c => <option key={c} value={c}>{c}</option>)}
                        </select>
                    </div>
                ))}
            </div>
             <div className="flex justify-end mt-6">
                <button onClick={handleSave} className="bg-teal-600 text-white font-medium py-2 px-4 rounded-lg hover:bg-teal-700 transition-colors">
                    Guardar Asignaciones
                </button>
            </div>
        </div>
    );
};

const StatusManager: React.FC<{
    title: string;
    getStatuses: () => Promise<string[]>;
    addStatus: (name: string) => Promise<void>;
    deleteStatus: (name: string) => Promise<void>;
    onActionSuccess: (message: string) => void;
    showConfirmation: (title: string, message: string, onConfirm: () => Promise<void>) => void;
}> = ({ title, getStatuses, addStatus, deleteStatus, onActionSuccess, showConfirmation }) => {
    const [statuses, setStatuses] = useState<string[]>([]);
    const [newStatus, setNewStatus] = useState('');

    useEffect(() => {
        const updateStatuses = async () => setStatuses(await getStatuses());
        updateStatuses();
        window.addEventListener('config_updated', updateStatuses);
        return () => window.removeEventListener('config_updated', updateStatuses);
    }, [getStatuses]);

    const handleAdd = async (e: React.FormEvent) => {
        e.preventDefault();
        if(newStatus.trim()){
            await addStatus(newStatus.trim());
            onActionSuccess(`Etapa "${newStatus.trim()}" añadida.`);
            setNewStatus('');
        }
    };

    const handleDelete = (status: string) => {
        showConfirmation(
            'Confirmar Eliminación',
            `¿Seguro que quieres eliminar la etapa "${status}"?`,
            async () => {
                await deleteStatus(status);
                onActionSuccess(`Etapa "${status}" eliminada.`);
            }
        );
    };

    return (
         <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-semibold border-b pb-3 mb-4">{title}</h3>
            <div className="space-y-3 mb-4 max-h-48 overflow-y-auto pr-2">
                {statuses.map(status => (
                    <div key={status} className="flex items-center justify-between bg-gray-50 p-2 rounded-md">
                        <span className="text-gray-700">{status}</span>
                        <button onClick={() => handleDelete(status)} className="text-gray-500 hover:text-red-600 p-1">
                            <Icon name="delete" className="text-base" />
                        </button>
                    </div>
                ))}
            </div>
            <form onSubmit={handleAdd} className="flex gap-4 mt-6">
                <input 
                    type="text" 
                    value={newStatus} 
                    onChange={e => setNewStatus(e.target.value)}
                    placeholder="Nueva etapa"
                    className="flex-grow w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-teal-500 focus:border-teal-500"
                />
                 <button type="submit" className="bg-teal-600 text-white font-medium py-2 px-4 rounded-lg hover:bg-teal-700 transition-colors">
                    Añadir
                </button>
            </form>
        </div>
    );
};

const CurrencyManager: React.FC<{ onSaveSuccess: (message: string) => void, showSaveConfirmation: (onConfirm: () => Promise<void>) => void }> = ({ onSaveSuccess, showSaveConfirmation }) => {
    const { currency, setCurrency } = useCurrency();
    const [selectedCurrency, setSelectedCurrency] = useState<'USD' | 'EUR'>(currency);
    const [isSaving, setIsSaving] = useState(false);

    useEffect(() => {
        setSelectedCurrency(currency);
    }, [currency]);

    const handleSave = async () => {
        showSaveConfirmation(async () => {
            setIsSaving(true);
            try {
                await setCurrency(selectedCurrency);
                onSaveSuccess('Divisa actualizada correctamente.');
            } catch (error) {
                console.error("Error saving currency:", error);
            } finally {
                setIsSaving(false);
            }
        });
    };
    
    const hasChanged = selectedCurrency !== currency;

    return (
        <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-semibold border-b pb-3 mb-4">Gestión de Divisa</h3>
            <p className="text-sm text-gray-600 mb-4">
                Selecciona la divisa principal para mostrar los valores monetarios en la aplicación.
            </p>
            <div className="space-y-3">
                <label className="flex items-center p-3 rounded-lg border has-[:checked]:bg-teal-50 has-[:checked]:border-teal-400 transition-colors cursor-pointer">
                    <input type="radio" name="currency" value="USD" checked={selectedCurrency === 'USD'} onChange={() => setSelectedCurrency('USD')} className="h-4 w-4 text-teal-600 border-gray-300 focus:ring-teal-500" />
                    <span className="ml-3 font-medium text-gray-700">Dólar Estadounidense (USD - $)</span>
                </label>
                <label className="flex items-center p-3 rounded-lg border has-[:checked]:bg-teal-50 has-[:checked]:border-teal-400 transition-colors cursor-pointer">
                    <input type="radio" name="currency" value="EUR" checked={selectedCurrency === 'EUR'} onChange={() => setSelectedCurrency('EUR')} className="h-4 w-4 text-teal-600 border-gray-300 focus:ring-teal-500" />
                    <span className="ml-3 font-medium text-gray-700">Euro (EUR - €)</span>
                </label>
            </div>
            <div className="flex justify-end mt-6">
                <button 
                    onClick={handleSave} 
                    disabled={isSaving || !hasChanged} 
                    className="bg-teal-600 text-white font-medium py-2 px-4 rounded-lg hover:bg-teal-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
                >
                    {isSaving ? 'Guardando...' : 'Guardar Divisa'}
                </button>
            </div>
        </div>
    );
};

interface ConfigurationProps {
    onNavigate: (page: Page) => void;
    currentUser: User;
}

const Configuration: React.FC<ConfigurationProps> = ({ onNavigate, currentUser }) => {
    const [activeSection, setActiveSection] = useState('account');
    const [activePlatformSection, setActivePlatformSection] = useState('fields');
    const [openFieldCustomizer, setOpenFieldCustomizer] = useState<EntityType | null>(null);
    const [infoModalState, setInfoModalState] = useState({ isOpen: false, title: '', message: '' });
    const [teamMemberRolePlural, setTeamMemberRolePlural] = useState('Coordinadoras');
    
    const [deleteConfirmationState, setDeleteConfirmationState] = useState({ isOpen: false, title: '', message: '', onConfirm: async () => {} });
    const [saveConfirmationState, setSaveConfirmationState] = useState({ isOpen: false, title: 'Confirmar Cambios', message: '¿Estás seguro de que deseas guardar los cambios realizados?', onConfirm: async () => {} });

    useEffect(() => {
        const getRole = async () => setTeamMemberRolePlural(await configService.getTeamMemberRolePlural());
        getRole();
        window.addEventListener('config_updated', getRole);
        return () => window.removeEventListener('config_updated', getRole);
    }, []);

    const showInfoModal = (title: string, message: string) => {
        setInfoModalState({ isOpen: true, title, message });
    };

    const showDeleteConfirmation = (title: string, message: string, onConfirm: () => Promise<void>) => {
        setDeleteConfirmationState({ isOpen: true, title, message, onConfirm: async () => {
            await onConfirm();
            setDeleteConfirmationState({ isOpen: false, title: '', message: '', onConfirm: async () => {} });
        }});
    };

    const showSaveConfirmation = (onConfirm: () => Promise<void>) => {
        setSaveConfirmationState(prev => ({ ...prev, isOpen: true, onConfirm: async () => {
             await onConfirm();
             setSaveConfirmationState({ isOpen: false, title: 'Confirmar Cambios', message: '¿Estás seguro de que deseas guardar los cambios realizados?', onConfirm: async () => {} });
        }}));
    };

    const isAdmin = useMemo(() => currentUser?.profile?.role === 'crm_admin' || currentUser?.profile?.role === 'platform_admin', [currentUser]);
    const isPlatformAdmin = useMemo(() => currentUser?.profile?.role === 'platform_admin', [currentUser]);

    const sections = [
        { id: 'account', label: 'Mi Cuenta', icon: 'person', component: <AccountManager onSaveSuccess={(message) => showInfoModal("Cuenta Actualizada", message)} showSaveConfirmation={showSaveConfirmation} /> },
        { id: 'team', label: `Equipo y Territorios`, icon: 'group', component: (
            <div className="space-y-6">
                <TeamManager onSaveSuccess={(message) => showInfoModal("Equipo Actualizado", message)} showConfirmation={showDeleteConfirmation} showSaveConfirmation={showSaveConfirmation} />
                <CountryManager onActionSuccess={(message) => showInfoModal("Países Actualizados", message)} showConfirmation={showDeleteConfirmation} teamMemberRolePlural={teamMemberRolePlural}/>
                <CoordinatorAssignmentManager onSaveSuccess={(message) => showInfoModal("Asignaciones Guardadas", message)} showSaveConfirmation={showSaveConfirmation} teamMemberRolePlural={teamMemberRolePlural} />
            </div>
        )},
        { id: 'platform', label: 'Personalización', icon: 'tune', component: (
            <div className="space-y-6">
                <div className="bg-white rounded-lg shadow p-6">
                     <h3 className="text-lg font-semibold border-b pb-3 mb-4">Personalización de Campos</h3>
                     <div className="flex gap-4">
                        <button onClick={() => setOpenFieldCustomizer('client')} className="w-full bg-gray-100 hover:bg-gray-200 text-gray-800 font-medium py-3 px-4 rounded-lg">Campos de Clientes</button>
                        <button onClick={() => setOpenFieldCustomizer('prospect')} className="w-full bg-gray-100 hover:bg-gray-200 text-gray-800 font-medium py-3 px-4 rounded-lg">Campos de Prospectos</button>
                     </div>
                </div>
                <AcademicOfferManager onSaveSuccess={(message) => showInfoModal("Oferta Académica Actualizada", message)} showConfirmation={showDeleteConfirmation} showSaveConfirmation={showSaveConfirmation} />
                <StatusManager title="Etapas de Clientes" getStatuses={configService.getClientStatuses} addStatus={configService.addClientStatus} deleteStatus={configService.deleteClientStatus} onActionSuccess={(message) => showInfoModal("Etapas de Clientes Actualizadas", message)} showConfirmation={showDeleteConfirmation} />
                <StatusManager title="Etapas de Prospectos" getStatuses={configService.getProspectStatuses} addStatus={configService.addProspectStatus} deleteStatus={configService.deleteProspectStatus} onActionSuccess={(message) => showInfoModal("Etapas de Prospectos Actualizadas", message)} showConfirmation={showDeleteConfirmation} />
                <CurrencyManager onSaveSuccess={(message) => showInfoModal("Divisa Actualizada", message)} showSaveConfirmation={showSaveConfirmation} />
            </div>
        )},
        { id: 'quick_create', label: 'Funciones Rápidas', icon: 'bolt', component: <QuickCreateManager onSaveSuccess={(message) => showInfoModal("Creación Rápida Actualizada", message)} showSaveConfirmation={showSaveConfirmation}/> },
    ];
    
    if (openFieldCustomizer) {
        return (
            <div className="p-4 sm:p-6">
                <button onClick={() => setOpenFieldCustomizer(null)} className="mb-4 flex items-center text-teal-600 font-medium hover:text-teal-800">
                    <Icon name="arrow_back" className="mr-2"/> Volver a Configuración
                </button>
                <div className="bg-white rounded-lg shadow p-6">
                    <h2 className="text-xl font-semibold mb-4 border-b pb-3 capitalize">Campos de {openFieldCustomizer === 'client' ? 'Cliente' : 'Prospecto'}</h2>
                    <FieldCustomizer entity={openFieldCustomizer} onSaveSuccess={(message) => showInfoModal("Campos Actualizados", message)} showSaveConfirmation={showSaveConfirmation}/>
                </div>
            </div>
        );
    }

    return (
        <div className="p-4 sm:p-6">
             <header className="mb-6">
                <h1 className="text-3xl font-bold text-gray-800">Configuración</h1>
                <p className="text-gray-500">Ajusta el CRM a las necesidades de tu negocio.</p>
             </header>

            <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
                <aside className="lg:col-span-1">
                    <nav className="space-y-2 sticky top-24">
                        {sections.filter(s => isAdmin || s.id === 'account').map(section => (
                            <button
                                key={section.id}
                                onClick={() => setActiveSection(section.id)}
                                className={`flex items-center w-full gap-3 px-4 py-3 rounded-lg transition-colors duration-200 focus:outline-none ${
                                    activeSection === section.id
                                        ? 'bg-teal-600 text-white shadow-md'
                                        : 'text-gray-600 hover:bg-teal-50 hover:text-teal-700'
                                }`}
                            >
                                <Icon name={section.icon} />
                                <span className="font-medium">{section.label}</span>
                            </button>
                        ))}
                    </nav>
                </aside>
                <main className="lg:col-span-3">
                     {sections.find(s => s.id === activeSection)?.component}
                </main>
            </div>
            
            <InfoModal 
                isOpen={infoModalState.isOpen}
                onClose={() => setInfoModalState({ isOpen: false, title: '', message: '' })}
                title={infoModalState.title}
                message={infoModalState.message}
            />
            <ConfirmationModal
                isOpen={deleteConfirmationState.isOpen}
                onClose={() => setDeleteConfirmationState({ ...deleteConfirmationState, isOpen: false })}
                onConfirm={deleteConfirmationState.onConfirm}
                title={deleteConfirmationState.title}
                message={deleteConfirmationState.message}
                confirmColor="red"
            />
             <ConfirmationModal
                isOpen={saveConfirmationState.isOpen}
                onClose={() => setSaveConfirmationState({ ...saveConfirmationState, isOpen: false })}
                onConfirm={saveConfirmationState.onConfirm}
                title={saveConfirmationState.title}
                message={saveConfirmationState.message}
                confirmColor="teal"
                confirmText="Guardar"
            />
        </div>
    );
};

export default Configuration;
