import React from 'react';
import ContactForm from '../components/forms/ContactForm.tsx';

interface AddClientProps {
    onCancel: () => void;
    onSave: () => void;
}

const AddClient: React.FC<AddClientProps> = ({ onCancel, onSave }) => {
    return <ContactForm entityType="client" onCancel={onCancel} onSave={onSave} />;
};

export default AddClient;
