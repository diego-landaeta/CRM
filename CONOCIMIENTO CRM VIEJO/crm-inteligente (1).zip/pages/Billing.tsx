
import React, { useState, useEffect, useMemo, useCallback } from 'react';
import Card from '../components/ui/Card.tsx';
import Icon from '../components/ui/Icon.tsx';
import { dataService } from '../services/dataService.ts';
import { Client, Page, Installment } from '../types.ts';
import ConfirmationModal from '../components/ui/ConfirmationModal.tsx';
import InstallmentModal from '../components/ui/InstallmentModal.tsx';
import { useCurrency } from '../contexts/CurrencyContext.tsx';

const getStatusClass = (status: string) => {
    const baseClass = 'text-xs font-semibold px-2.5 py-1 rounded-full inline-block';
    switch (status) {
        case 'Pagado': return `${baseClass} bg-green-100 text-green-800`;
        case 'Pendiente': return `${baseClass} bg-yellow-100 text-yellow-800`;
        case 'Atrasado': return `${baseClass} bg-red-100 text-red-800`;
        default: return `${baseClass} bg-gray-100 text-gray-800`;
    }
}

const Billing: React.FC<{ onNavigate: (page: Page, id?: string) => void }> = ({ onNavigate }) => {
    const [clients, setClients] = useState<Client[]>([]);
    const [filter, setFilter] = useState('all');
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [selectedClient, setSelectedClient] = useState<Client | null>(null);
    const { formatCurrency } = useCurrency();

    const fetchClients = useCallback(async () => {
        const allClients = await dataService.getClients();
        setClients(allClients.filter(c => c.estimated_value > 0));
    }, []);

    useEffect(() => {
        fetchClients();
    }, [fetchClients]);

    const handleManageInstallments = (client: Client) => {
        setSelectedClient(client);
        setIsModalOpen(true);
    };

    const handleModalSave = async (updatedClient: Client) => {
        await dataService.updateClient(updatedClient);
        setIsModalOpen(false);
        setSelectedClient(null);
        fetchClients(); // Refresh data
    };

    const filteredClients = useMemo(() => {
        if (filter === 'all') return clients;
        return clients.filter(c => c.payment_type === filter);
    }, [clients, filter]);

    const getPaymentStatus = (client: Client): string => {
        if (client.payment_type === 'Pago Único') {
            return client.total_paid >= client.estimated_value ? 'Pagado' : 'Pendiente';
        }
        if (client.payment_type === 'Cuotas') {
            if (client.total_paid >= client.estimated_value) return 'Pagado';

            const hasOverdue = ((client.installment_details as unknown as Installment[] | null) || []).some(
                inst => inst.status === 'Pendiente' && new Date(inst.dueDate) < new Date()
            );
            return hasOverdue ? 'Atrasado' : 'Pendiente';
        }
        return 'N/A';
    };

    return (
        <div className="p-4 sm:p-6 space-y-6">
            <Card>
                <div className="flex justify-between items-center flex-wrap gap-4 mb-6">
                    <div>
                        <h3 className="text-xl font-semibold text-[var(--text-primary)]">Gestión de Facturación</h3>
                        <p className="text-sm text-[var(--text-secondary)]">Supervisa los pagos y saldos de tus clientes.</p>
                    </div>
                    <div className="flex items-center gap-3">
                        <select onChange={(e) => setFilter(e.target.value)} value={filter} className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-teal-500 focus:border-teal-500">
                            <option value="all">Todos los Pagos</option>
                            <option value="Pago Único">Pago Único</option>
                            <option value="Cuotas">Cuotas</option>
                        </select>
                    </div>
                </div>

                <div className="overflow-x-auto">
                    <table className="w-full text-left">
                        <thead className="text-xs text-gray-500 uppercase border-b border-gray-200 bg-gray-50">
                            <tr>
                                <th className="py-3 px-4">Cliente</th>
                                <th className="py-3 px-4">Valor Total</th>
                                <th className="py-3 px-4">Tipo de Pago</th>
                                <th className="py-3 px-4">Total Abonado</th>
                                <th className="py-3 px-4">Saldo Pendiente</th>
                                <th className="py-3 px-4 text-center">Cuotas</th>
                                <th className="py-3 px-4">Estado</th>
                                <th className="py-3 px-4">Acciones</th>
                            </tr>
                        </thead>
                        <tbody className="text-sm text-gray-700">
                            {filteredClients.map((client) => {
                                const status = getPaymentStatus(client);
                                return (
                                    <tr key={client.id} className="border-b border-gray-200 hover:bg-gray-50">
                                        <td className="py-3 px-4 font-medium">{client.name}</td>
                                        <td className="py-3 px-4 font-semibold">{formatCurrency(client.estimated_value)}</td>
                                        <td className="py-3 px-4">{client.payment_type || 'N/A'}</td>
                                        <td className="py-3 px-4 text-green-600 font-medium">{formatCurrency(client.total_paid)}</td>
                                        <td className="py-3 px-4 text-red-600 font-medium">{formatCurrency(client.estimated_value - client.total_paid)}</td>
                                        <td className="py-3 px-4 text-center">{client.payment_type === 'Cuotas' ? `${client.installments_paid || 0} / ${client.installments_total || 0}` : 'N/A'}</td>
                                        <td className="py-3 px-4"><span className={getStatusClass(status)}>{status}</span></td>
                                        <td className="py-3 px-4">
                                            {client.payment_type === 'Cuotas' && (
                                                <button onClick={() => handleManageInstallments(client)} className="text-gray-500 hover:text-green-600 p-1" title="Gestionar Cuotas">
                                                    <Icon name="payments" className="text-base" />
                                                </button>
                                            )}
                                        </td>
                                    </tr>
                                );
                            })}
                        </tbody>
                    </table>
                     {filteredClients.length === 0 && <p className="text-center text-gray-500 py-8">No hay clientes que coincidan con el filtro seleccionado.</p>}
                </div>
            </Card>

            {selectedClient && isModalOpen && (
                <InstallmentModal
                    isOpen={isModalOpen}
                    onClose={() => setIsModalOpen(false)}
                    onSave={handleModalSave}
                    client={selectedClient}
                />
            )}
        </div>
    );
};

export default Billing;