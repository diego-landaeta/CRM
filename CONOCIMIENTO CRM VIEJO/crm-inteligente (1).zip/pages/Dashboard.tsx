
import React, { useState, useEffect, useMemo } from 'react';
import Icon from '../components/ui/Icon.tsx';
import Card from '../components/ui/Card.tsx';
import { dataService } from '../services/dataService.ts';
import { configService } from '../services/configService.ts';
import { Client, Prospect, Page } from '../types.ts';
import { authService } from '../services/authService.ts';
import { useCurrency } from '../contexts/CurrencyContext.tsx';

const StatCard: React.FC<{ title: string; value: string; icon: string; }> = ({ title, value, icon }) => (
  <Card>
    <div className="flex items-center">
      <div className={`p-3 rounded-full bg-teal-100 mr-4`}>
        <Icon name={icon} className="text-teal-600 text-2xl" />
      </div>
      <div>
        <h3 className="text-sm font-medium text-gray-500">{title}</h3>
        <p className="text-2xl font-bold text-gray-800">{value}</p>
      </div>
    </div>
  </Card>
);

const TopPerformerList: React.FC<{ title: string; items: { name: string; value: string }[] }> = ({ title, items }) => {
    const [isExpanded, setIsExpanded] = useState(false);
    const visibleItems = isExpanded ? items : items.slice(0, 3);
    
    return (
        <div>
            <h4 className="font-semibold text-gray-700 mb-2">{title}</h4>
            {items.length === 0 ? (
                 <p className="text-sm text-gray-500">No hay datos suficientes.</p>
            ) : (
                <ul className="space-y-2">
                    {visibleItems.map((item, index) => (
                        <li key={index} className="flex justify-between items-center text-sm">
                            <span className="text-gray-600">{index + 1}. {item.name}</span>
                            <span className="font-bold text-gray-800">{item.value}</span>
                        </li>
                    ))}
                </ul>
            )}
            {items.length > 3 && (
                <button onClick={() => setIsExpanded(!isExpanded)} className="text-teal-600 hover:text-teal-800 text-sm font-medium mt-2">
                    {isExpanded ? 'Ver menos' : 'Ver todos'}
                </button>
            )}
        </div>
    );
};

const Dashboard: React.FC<{onNavigate: (page: Page, id?: string) => void;}> = ({onNavigate}) => {
    const [clients, setClients] = useState<Client[]>([]);
    const [prospects, setProspects] = useState<Prospect[]>([]);
    const [userName, setUserName] = useState('');
    const [teamMemberRolePlural, setTeamMemberRolePlural] = useState('Coordinadoras');
    const { formatCurrency } = useCurrency();

    useEffect(() => {
        const fetchData = async () => {
            const [clientsData, prospectsData, user, role] = await Promise.all([
                dataService.getClients(),
                dataService.getProspects(),
                authService.getUser(),
                configService.getTeamMemberRolePlural(),
            ]);
            setClients(clientsData);
            setProspects(prospectsData);
            setUserName(user?.profile?.full_name || user?.email || 'Usuario');
            setTeamMemberRolePlural(role);
        };
        fetchData();
    }, []);

    const dashboardStats = useMemo(() => {
        const now = new Date();
        const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

        const clientsThisMonth = clients.filter(c => new Date(c.creation_date) >= startOfMonth);
        const prospectsThisMonth = prospects.filter(p => new Date(p.creation_date) >= startOfMonth);

        const revenueThisMonth = clientsThisMonth.reduce((sum, c) => sum + c.estimated_value, 0);

        // Top countries by revenue
        const countryRevenue: { [key: string]: number } = {};
        clients.forEach(c => {
            countryRevenue[c.country] = (countryRevenue[c.country] || 0) + c.estimated_value;
        });
        const topCountries = Object.entries(countryRevenue)
            .sort(([, a], [, b]) => b - a)
            .map(([name, value]) => ({ name, value: formatCurrency(value) }));

        // Top coordinators by revenue
        const coordinatorRevenue: { [key: string]: number } = {};
        clients.forEach(c => {
            coordinatorRevenue[c.coordinator] = (coordinatorRevenue[c.coordinator] || 0) + c.estimated_value;
        });
        const topCoordinators = Object.entries(coordinatorRevenue)
            .sort(([, a], [, b]) => b - a)
            .map(([name, value]) => ({ name, value: formatCurrency(value) }));
            
        // Upcoming follow-ups
        const upcomingFollowUps = [...clients, ...prospects]
            .filter(c => c.next_contact && new Date(c.next_contact) >= now)
            .sort((a, b) => new Date(a.next_contact!).getTime() - new Date(b.next_contact!).getTime())
            .slice(0, 5);

        // Recent activity
        const recentActivity = [...clients, ...prospects]
            .sort((a,b) => new Date(b.creation_date).getTime() - new Date(a.creation_date).getTime())
            .slice(0, 5);

        return {
            newLeads: prospectsThisMonth.length,
            closedDeals: clientsThisMonth.length,
            revenueThisMonth,
            topCountries,
            topCoordinators,
            upcomingFollowUps,
            recentActivity,
        };
    }, [clients, prospects, formatCurrency]);

  return (
    <div className="p-4 sm:p-6 bg-gray-50/50 space-y-6">
       <header>
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">¡Bienvenido de nuevo, {userName}!</h1>
            <p className="text-gray-500">Aquí tienes un resumen de tu actividad reciente.</p>
       </header>

       <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <StatCard title="Nuevos Prospectos (este mes)" value={dashboardStats.newLeads.toString()} icon="person_add" />
            <StatCard title="Clientes Nuevos (este mes)" value={dashboardStats.closedDeals.toString()} icon="group_add" />
            <StatCard title="Ingresos (este mes)" value={formatCurrency(dashboardStats.revenueThisMonth)} icon="monetization_on" />
       </div>
       
       <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-2">
                <h3 className="text-xl font-semibold text-gray-700 mb-4">Top Rendimiento por Ingresos</h3>
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <TopPerformerList title={`Top Países`} items={dashboardStats.topCountries} />
                    <TopPerformerList title={`Top ${teamMemberRolePlural}`} items={dashboardStats.topCoordinators} />
                </div>
            </Card>

            <Card>
                <h3 className="text-xl font-semibold text-gray-700 mb-4">Próximos Seguimientos</h3>
                <ul className="space-y-3">
                    {dashboardStats.upcomingFollowUps.map(contact => (
                        <li key={contact.id} className="flex items-center justify-between text-sm">
                            <button className="text-left hover:text-teal-600" onClick={() => onNavigate('Clients', contact.id)}>
                                <p className="font-medium">{contact.name}</p>
                                <p className="text-xs text-gray-500">{new Date(contact.next_contact!).toLocaleDateString()}</p>
                            </button>
                             <Icon name="event" className="text-gray-400" />
                        </li>
                    ))}
                    {dashboardStats.upcomingFollowUps.length === 0 && (
                        <p className="text-sm text-center text-gray-500 py-4">No hay seguimientos programados.</p>
                    )}
                </ul>
            </Card>
       </div>

       <div className="grid grid-cols-1">
           <Card>
               <h3 className="text-xl font-semibold text-gray-700 mb-4">Actividad Reciente</h3>
               <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                        <tbody>
                           {dashboardStats.recentActivity.map(contact => (
                               <tr key={contact.id} className="border-b last:border-0">
                                   <td className="py-3 px-2">
                                        <button className="font-medium hover:text-teal-600 text-left" onClick={() => onNavigate('Clients', contact.id)}>
                                            {contact.name}
                                        </button>
                                   </td>
                                   <td className="py-3 px-2 text-gray-500">{contact.email}</td>
                                   <td className="py-3 px-2 text-gray-500">{contact.program}</td>
                                   <td className="py-3 px-2">
                                        <span className={`text-xs font-semibold px-2 py-1 rounded-full ${'estimated_value' in contact ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800'}`}>
                                            {'estimated_value' in contact ? 'Cliente' : 'Prospecto'}
                                        </span>
                                   </td>
                                   <td className="py-3 px-2 text-gray-500 text-right">{new Date(contact.creation_date).toLocaleDateString()}</td>
                               </tr>
                           ))}
                            {dashboardStats.recentActivity.length === 0 && (
                                <tr>
                                    <td colSpan={5} className="text-center py-8 text-gray-500">No hay actividad reciente.</td>
                                </tr>
                            )}
                        </tbody>
                    </table>
               </div>
           </Card>
       </div>
    </div>
  );
};

export default Dashboard;