
import React, { useState, useEffect, useMemo, useCallback } from 'react';
import Card from '../components/ui/Card.tsx';
import Icon from '../components/ui/Icon.tsx';
import { dataService } from '../services/dataService.ts';
import { configService } from '../services/configService.ts';
import { Prospect, Page, FieldConfig, AcademicOffer, ProgramType, ProgramTypeLabels } from '../types.ts';
import { ORIGINS } from '../constants.ts';
import ConfirmationModal from '../components/ui/ConfirmationModal.tsx';
import QuickCreateModal from '../components/forms/QuickCreateModal.tsx';
import ImportCsvModal from '../components/ui/ImportCsvModal.tsx';
import FilterPanel, { Filters as ProspectFilters } from '../components/ui/FilterPanel.tsx';
import ScrollableTableContainer from '../components/ui/ScrollableTableContainer.tsx';
import PaginationControls from '../components/ui/PaginationControls.tsx';
import ContactDetailModal from '../components/ui/ContactDetailModal.tsx';

const getStageClass = (stage: string | null) => {
    const baseClass = 'text-xs font-semibold px-2.5 py-1 rounded-full';
    switch ((stage || '').toLowerCase()) {
        case 'nuevo': return `${baseClass} bg-gray-100 text-gray-800`;
        case 'calificado': return `${baseClass} bg-yellow-100 text-yellow-800`;
        case 'propuesta': return `${baseClass} bg-blue-100 text-blue-800`;
        case 'negociación': return `${baseClass} bg-purple-100 text-purple-800`;
        case 'cerrado ganado': return `${baseClass} bg-green-100 text-green-800`;
        case 'cerrado perdido': return `${baseClass} bg-red-100 text-red-800`;
        case 'archivado': return `${baseClass} bg-gray-400 text-white`;
        default: return `${baseClass} bg-gray-100 text-gray-800`;
    }
}

interface ProspectsProps {
    onNavigate: (page: Page, id?: string) => void;
}

type SortKey = keyof Prospect;

const Prospects: React.FC<ProspectsProps> = ({ onNavigate }) => {
    const [prospects, setProspects] = useState<Prospect[]>([]);
    const [fieldConfig, setFieldConfig] = useState<FieldConfig[]>([]);
    const [coordinators, setCoordinators] = useState<string[]>([]);
    const [prospectStatuses, setProspectStatuses] = useState<string[]>([]);
    const [quickCreateConfig, setQuickCreateConfig] = useState({ is_visible: false, required_fields: [] });
    const [academicOffer, setAcademicOffer] = useState<AcademicOffer>([]);
    const [isAcademicOfferEnabled, setIsAcademicOfferEnabled] = useState(true);
    const [countries, setCountries] = useState<string[]>([]);
    const [allOrigins] = useState<string[]>(ORIGINS);
    const [teamMemberRolePlural, setTeamMemberRolePlural] = useState('Coordinadoras');
    const [teamMemberRoleSingular, setTeamMemberRoleSingular] = useState('Coordinadora');
    
    const [filters, setFilters] = useState<ProspectFilters>({
        searchTerm: '',
        stage: '',
        coordinator: '',
        faculty: '',
        programType: '',
        program: '',
        country: '',
        origin: '',
    });
    const [sort, setSort] = useState<{ key: SortKey; direction: 'asc' | 'desc' }>({ key: 'name', direction: 'asc' });
    const [currentTab, setCurrentTab] = useState<'active' | 'archived'>('active');
    const [currentPage, setCurrentPage] = useState(1);
    const [itemsPerPage, setItemsPerPage] = useState(10);

    const [isConfirmationModalOpen, setIsConfirmationModalOpen] = useState(false);
    const [prospectToAction, setProspectToAction] = useState<{ prospect: Prospect | null; action: 'archive' | 'unarchive' | 'delete' }>({ prospect: null, action: 'delete' });
    const [isQuickCreateModalOpen, setIsQuickCreateModalOpen] = useState(false);
    const [isImportModalOpen, setIsImportModalOpen] = useState(false);
    const [isFilterPanelOpen, setIsFilterPanelOpen] = useState(false);
    const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
    const [selectedContact, setSelectedContact] = useState<Prospect | null>(null);

    const fetchAndSetConfig = useCallback(async () => {
         const [prospectsData, fields, coords, statuses, qcConfig, academicConfig, offer, countryList, pluralRole, singularRole] = await Promise.all([
            dataService.getProspects(),
            configService.getVisibleFields('prospect'),
            configService.getCoordinators(),
            configService.getProspectStatuses(),
            configService.getQuickCreateConfig(),
            configService.getAcademicOfferConfig(),
            configService.getAcademicOffer(),
            configService.getCountries(),
            configService.getTeamMemberRolePlural(),
            configService.getTeamMemberRoleSingular(),
        ]);

        setProspects(prospectsData);
        setFieldConfig(fields);
        setCoordinators(coords);
        setProspectStatuses(statuses);
        setQuickCreateConfig(qcConfig.prospect);
        setIsAcademicOfferEnabled(academicConfig.is_enabled);
        setAcademicOffer(offer);
        setCountries(countryList);
        setTeamMemberRolePlural(pluralRole);
        setTeamMemberRoleSingular(singularRole);
    }, []);

    useEffect(() => {
        fetchAndSetConfig();
        window.addEventListener('config_updated', fetchAndSetConfig);
        return () => window.removeEventListener('config_updated', fetchAndSetConfig);
    }, [fetchAndSetConfig]);

    const programPathMap = useMemo(() => {
        if (!isAcademicOfferEnabled || !academicOffer.length) return {};
        
        const map: Record<string, string> = {};
        for (const faculty of academicOffer) {
            for (const type of Object.keys(ProgramTypeLabels) as ProgramType[]) {
                if (faculty[type]) {
                    for (const program of faculty[type]) {
                        map[program.name] = `${faculty.name} / ${ProgramTypeLabels[type]} / ${program.name}`;
                    }
                }
            }
        }
        return map;
    }, [academicOffer, isAcademicOfferEnabled]);

    const programDetailsMap = useMemo(() => {
        if (!isAcademicOfferEnabled) return new Map();
        const map = new Map<string, { faculty: string, type: ProgramType }>();
        for (const faculty of academicOffer) {
            for (const type of Object.keys(ProgramTypeLabels) as ProgramType[]) {
                if (faculty[type]) {
                    for (const program of faculty[type]) {
                        map.set(program.name, { faculty: faculty.name, type });
                    }
                }
            }
        }
        return map;
    }, [academicOffer, isAcademicOfferEnabled]);


    const handleActionClick = (prospect: Prospect, action: 'delete' | 'archive' | 'unarchive') => {
        setProspectToAction({ prospect, action });
        setIsConfirmationModalOpen(true);
    };

    const confirmAction = async () => {
        if (!prospectToAction.prospect) return;

        const { prospect, action } = prospectToAction;
        try {
            switch(action) {
                case 'delete':
                    await dataService.deleteProspect(prospect.id);
                    break;
                case 'archive':
                    await dataService.updateProspect({ id: prospect.id, stage: 'Archivado' });
                    break;
                case 'unarchive':
                    await dataService.updateProspect({ id: prospect.id, stage: 'Nuevo' });
                    break;
            }
        } catch (error) {
            console.error(`Failed to ${action} prospect:`, error);
        } finally {
            await fetchAndSetConfig();
            setIsConfirmationModalOpen(false);
            setProspectToAction({ prospect: null, action: 'delete' });
        }
    };
    
    const handleSort = (key: SortKey) => {
        setSort(prevSort => ({
            key,
            direction: prevSort.key === key && prevSort.direction === 'asc' ? 'desc' : 'asc',
        }));
    };
    
    const handleApplyFilters = (newFilters: ProspectFilters) => {
        setFilters(newFilters);
    };

    const handleQuickSave = async () => {
        setIsQuickCreateModalOpen(false);
        await fetchAndSetConfig(); // Refresh data
    };

    const handleImportSuccess = () => {
        setIsImportModalOpen(false);
        fetchAndSetConfig();
    }
    
    const handleItemsPerPageChange = (size: number) => {
        setItemsPerPage(size);
        setCurrentPage(1);
    };
    
    const handleViewDetails = (prospect: Prospect) => {
        setSelectedContact(prospect);
        setIsDetailModalOpen(true);
    };

    const activeFilterCount = useMemo(() => {
        return Object.values(filters).filter(value => value && value !== '').length;
    }, [filters]);

    const finalFilteredProspects = useMemo(() => {
        const baseProspects = prospects.filter(prospect => {
            if (currentTab === 'active') {
                return prospect.stage !== 'Archivado';
            }
            return prospect.stage === 'Archivado';
        });

        return baseProspects
            .filter(prospect => {
                const programDetails = programDetailsMap.get(prospect.program);
                const programTypeLabel = programDetails ? ProgramTypeLabels[programDetails.type] : '';

                return (
                    (filters.searchTerm === '' ||
                     (prospect.name || '').toLowerCase().includes(filters.searchTerm.toLowerCase()) ||
                     (prospect.email || '').toLowerCase().includes(filters.searchTerm.toLowerCase())) &&
                    (filters.stage === '' || prospect.stage === filters.stage) &&
                    (filters.coordinator === '' || prospect.coordinator === filters.coordinator) &&
                    (filters.country === '' || prospect.country === filters.country) &&
                    (filters.origin === '' || prospect.origin === filters.origin) &&
                    // Hierarchical Program Filter Logic
                    (filters.faculty === '' || (programDetails && programDetails.faculty === filters.faculty)) &&
                    (filters.programType === '' || (programTypeLabel === filters.programType)) &&
                    (filters.program === '' || prospect.program === filters.program)
                );
            })
            .sort((a, b) => {
                const aValue = a[sort.key] ?? '';
                const bValue = b[sort.key] ?? '';
                if (aValue < bValue) return sort.direction === 'asc' ? -1 : 1;
                if (aValue > bValue) return sort.direction === 'asc' ? 1 : -1;
                return 0;
            });
    }, [prospects, filters, sort, programDetailsMap, currentTab]);
    
    const totalPages = Math.ceil(finalFilteredProspects.length / itemsPerPage);
    
    useEffect(() => {
        if (currentPage > totalPages && totalPages > 0) {
            setCurrentPage(totalPages);
        }
    }, [currentPage, totalPages]);

    const paginatedProspects = useMemo(() => {
        const startIndex = (currentPage - 1) * itemsPerPage;
        return finalFilteredProspects.slice(startIndex, startIndex + itemsPerPage);
    }, [finalFilteredProspects, currentPage, itemsPerPage]);

    const displayStatuses = useMemo(() => prospectStatuses.filter(s => s !== 'Archivado'), [prospectStatuses]);

    const getConfirmationModalProps = () => {
        if (!prospectToAction.prospect) return { title: '', message: '', confirmText: '', confirmColor: 'teal' as 'red' | 'teal' };
        const { prospect, action } = prospectToAction;
        switch (action) {
            case 'archive':
                return {
                    title: 'Confirmar Archivado',
                    message: `¿Estás seguro de que quieres archivar al prospecto "${prospect.name}"?`,
                    confirmText: 'Archivar',
                    confirmColor: 'teal' as const
                };
            case 'unarchive':
                return {
                    title: 'Confirmar Desarchivado',
                    message: `¿Estás seguro de que quieres desarchivar al prospecto "${prospect.name}"?`,
                    confirmText: 'Desarchivar',
                    confirmColor: 'teal' as const
                };
            case 'delete':
            default:
                return {
                    title: 'Confirmar Eliminación',
                    message: <>¿Estás seguro de que quieres eliminar al prospecto <strong>"{prospect.name}"</strong>?<br/>Esta acción no se puede deshacer.</>,
                    confirmText: 'Eliminar',
                    confirmColor: 'red' as const
                };
        }
    };

  return (
    <div className="p-4 sm:p-6 space-y-6">
      <Card>
        <div className="flex justify-between items-center flex-wrap gap-4 mb-4">
          <div>
            <h3 className="text-xl font-semibold text-[var(--text-primary)]">Gestión de Prospectos</h3>
            <p className="text-sm text-[var(--text-secondary)]">Administra y haz seguimiento de tus prospectos ({finalFilteredProspects.length}).</p>
          </div>
           <div className="flex items-center gap-3 flex-wrap">
            <button onClick={() => setIsImportModalOpen(true)} className="bg-white hover:bg-gray-100 text-gray-800 font-medium py-2 px-4 rounded-lg flex items-center transition-colors shadow-md hover:shadow-lg border border-gray-300">
                <Icon name="upload_file" className="mr-2" />
                Importar desde Excel
            </button>
            {quickCreateConfig.is_visible && (
                <button onClick={() => setIsQuickCreateModalOpen(true)} className="bg-teal-500 hover:bg-teal-600 text-white font-medium py-2 px-4 rounded-lg flex items-center transition-colors shadow-md hover:shadow-lg">
                    <Icon name="bolt" className="mr-2" />
                    Creación Rápida
                </button>
            )}
            <button onClick={() => onNavigate('AddProspect')} className="bg-[var(--button-primary-bg)] hover:bg-[var(--button-primary-hover-bg)] text-white font-medium py-2 px-4 rounded-lg flex items-center transition-colors shadow-md hover:shadow-lg">
                <Icon name="add" className="mr-2" />
                Nuevo Prospecto
            </button>
          </div>
        </div>
        
        <div className="border-b border-gray-200 mb-6">
            <nav className="-mb-px flex space-x-6" aria-label="Tabs">
                <button
                    onClick={() => setCurrentTab('active')}
                    className={`${currentTab === 'active' ? 'border-teal-500 text-teal-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'} whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm transition-colors focus:outline-none`}
                >
                    Activos
                </button>
                <button
                    onClick={() => setCurrentTab('archived')}
                    className={`${currentTab === 'archived' ? 'border-teal-500 text-teal-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'} whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm transition-colors focus:outline-none`}
                >
                    Archivados
                </button>
            </nav>
        </div>

        <div className="flex items-center gap-4 mb-4">
            <p className="text-sm text-gray-600 flex-grow hidden sm:block">
                Utiliza los filtros avanzados para acotar tu búsqueda.
            </p>
            <button onClick={() => setIsFilterPanelOpen(true)} className="bg-white hover:bg-gray-100 text-gray-800 font-medium py-2 px-4 rounded-lg flex items-center transition-colors shadow-sm border border-gray-300 w-full sm:w-auto justify-center">
                <Icon name="filter_list" className="mr-2" />
                Filtros Avanzados
                {activeFilterCount > 0 && (
                    <span className="ml-2 bg-teal-600 text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                        {activeFilterCount}
                    </span>
                )}
            </button>
        </div>

        <ScrollableTableContainer>
          <table className="w-full text-left">
            <thead className="text-xs text-gray-500 uppercase border-b border-gray-200 bg-gray-50">
              <tr>
                <th className="py-3 px-4 w-10"><input className="form-checkbox h-4 w-4 text-[var(--text-accent)] rounded border-gray-300 focus:ring-[var(--text-accent)]" type="checkbox" /></th>
                 {fieldConfig.map(field => (
                  <th key={field.key} className="py-3 px-4 cursor-pointer hover:bg-gray-100" onClick={() => handleSort(field.key as SortKey)}>
                     <div className="flex items-center">
                      {field.label}
                      {sort.key === field.key && <Icon name={sort.direction === 'asc' ? 'arrow_upward' : 'arrow_downward'} className="text-xs ml-1" />}
                    </div>
                  </th>
                ))}
                <th className="py-3 px-4">Acciones</th>
              </tr>
            </thead>
            <tbody className="text-sm text-gray-700">
              {paginatedProspects.map((prospect: Prospect) => (
                <tr key={prospect.id} className="border-b border-gray-200 hover:bg-gray-50 transition-colors">
                  <td className="py-3 px-4"><input className="form-checkbox h-4 w-4 text-[var(--text-accent)] rounded border-gray-300 focus:ring-[var(--text-accent)]" type="checkbox" /></td>
                  {fieldConfig.map(field => (
                     <td key={field.key} className="py-3 px-4">
                        {(() => {
                            if (field.key === 'name') {
                                return (
                                     <button onClick={() => handleViewDetails(prospect)} className="text-left hover:text-teal-600 transition-colors w-full focus:outline-none">
                                        <div className="font-medium">{prospect.name}</div>
                                        <div className="text-xs text-gray-500">{prospect.email}</div>
                                    </button>
                                );
                            }
                            if (field.key === 'program' && isAcademicOfferEnabled) {
                                const path = programPathMap[prospect.program];
                                 if (path) {
                                    const parts = path.split(' / ');
                                    return (
                                        <div className="text-xs">
                                            <span className="font-semibold">{parts[0]}</span>
                                            <span className="text-gray-500"> / {parts[1]} / </span>
                                            <span>{parts[2]}</span>
                                        </div>
                                    );
                                }
                                return prospect.program;
                            }
                            if (field.key === 'stage') {
                                return <span className={getStageClass(prospect.stage)}>{prospect.stage}</span>;
                            }
                            if (field.key === 'phone') {
                                return <a href={`tel:${prospect.phone?.replace(/\s/g, '')}`} className="text-teal-600 hover:underline">{prospect.phone}</a>;
                            }
                            return prospect[field.key as keyof Prospect] as React.ReactNode;
                        })()}
                    </td>
                  ))}
                  <td className="py-3 px-4 whitespace-nowrap">
                    {currentTab === 'active' &&
                      <button onClick={() => onNavigate('ConvertProspect', prospect.id)} title="Convertir a Cliente" className="text-gray-500 hover:text-teal-600 p-1"><Icon name="sync_alt" className="text-base" /></button>
                    }
                    {currentTab === 'active' ? (
                        <button onClick={() => handleActionClick(prospect, 'archive')} className="text-gray-500 hover:text-blue-600 p-1" title="Archivar Prospecto"><Icon name="archive" className="text-base" /></button>
                    ) : (
                        <button onClick={() => handleActionClick(prospect, 'unarchive')} className="text-gray-500 hover:text-blue-600 p-1" title="Desarchivar Prospecto"><Icon name="unarchive" className="text-base" /></button>
                    )}
                    <button onClick={() => onNavigate('EditProspect', prospect.id)} className="text-gray-500 hover:text-green-600 p-1" title="Editar Prospecto"><Icon name="edit" className="text-base" /></button>
                    <button onClick={() => handleActionClick(prospect, 'delete')} className="text-gray-500 hover:text-red-600 p-1" title="Eliminar Prospecto"><Icon name="delete" className="text-base" /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </ScrollableTableContainer>
        <PaginationControls
            currentPage={currentPage}
            totalPages={totalPages}
            onPageChange={setCurrentPage}
            itemsPerPage={itemsPerPage}
            onItemsPerPageChange={handleItemsPerPageChange}
            totalItems={finalFilteredProspects.length}
            itemCountOnPage={paginatedProspects.length}
        />
      </Card>
      <ConfirmationModal
        isOpen={isConfirmationModalOpen}
        onClose={() => setIsConfirmationModalOpen(false)}
        onConfirm={confirmAction}
        {...getConfirmationModalProps()}
    />
    <QuickCreateModal
        isOpen={isQuickCreateModalOpen}
        onClose={() => setIsQuickCreateModalOpen(false)}
        onSave={handleQuickSave}
        entityType="prospect"
    />
    <ImportCsvModal 
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
        onSave={handleImportSuccess}
        entityType="prospect"
    />
    <FilterPanel
        isOpen={isFilterPanelOpen}
        onClose={() => setIsFilterPanelOpen(false)}
        onApplyFilters={handleApplyFilters}
        initialFilters={filters}
        entityType="prospect"
        coordinators={coordinators}
        statuses={displayStatuses}
        academicOffer={academicOffer}
        isAcademicOfferEnabled={isAcademicOfferEnabled}
        countries={countries}
        origins={allOrigins}
        teamMemberRolePlural={teamMemberRolePlural}
        teamMemberRoleSingular={teamMemberRoleSingular}
    />
    <ContactDetailModal
        isOpen={isDetailModalOpen}
        onClose={() => setIsDetailModalOpen(false)}
        contact={selectedContact}
        entityType="prospect"
        onNavigate={onNavigate}
    />
    </div>
  );
};

export default Prospects;
