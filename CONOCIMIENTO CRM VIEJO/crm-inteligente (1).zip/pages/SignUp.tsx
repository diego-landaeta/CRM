
import React, { useState } from 'react';
import Icon from '../components/ui/Icon.tsx';
import { authService } from '../services/authService.ts';

interface SignUpProps {
  onSwitchToLogin: () => void;
  onSignUpSuccess: () => void;
}

const SignUp: React.FC<SignUpProps> = ({ onSwitchToLogin, onSignUpSuccess }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isLoading) return;

    if (password !== confirmPassword) {
      setError('Las contraseñas no coinciden.');
      return;
    }
    
    setError('');
    setIsLoading(true);

    try {
      await authService.signup(name, email, password);
      onSignUpSuccess();
    } catch (err: any) {
      setError(err.message || 'Ocurrió un error inesperado durante el registro.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100 p-4">
      <div className="w-full max-w-md p-8 space-y-6 bg-white rounded-2xl shadow-lg">
        <div className="text-center">
            <div className="flex justify-center items-center mb-4">
                 <span className="p-3 bg-[var(--sidebar-bg)] rounded-full shadow-md">
                    <Icon name="insights" className="text-3xl text-white" />
                 </span>
            </div>
          <h1 className="text-3xl font-bold text-[var(--text-primary)]">Crear Cuenta</h1>
          <p className="mt-2 text-[var(--text-secondary)]">Regístrate para empezar a usar CRM Inteligente.</p>
        </div>

        <form className="mt-6 space-y-6" onSubmit={handleSubmit}>
          <div className="space-y-4 rounded-md">
            <div>
              <label htmlFor="name" className="sr-only">Nombre completo</label>
              <input
                id="name" name="name" type="text" autoComplete="name" required value={name} onChange={(e) => setName(e.target.value)}
                className="relative block w-full px-4 py-3 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-lg focus:outline-none focus:ring-[var(--input-focus-ring)] focus:border-[var(--input-focus-ring)] focus:z-10 sm:text-sm transition"
                placeholder="Nombre completo"
              />
            </div>
            <div>
              <label htmlFor="email-address" className="sr-only">Correo electrónico</label>
              <input
                id="email-address" name="email" type="email" autoComplete="email" required value={email} onChange={(e) => setEmail(e.target.value)}
                className="relative block w-full px-4 py-3 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-lg focus:outline-none focus:ring-[var(--input-focus-ring)] focus:border-[var(--input-focus-ring)] focus:z-10 sm:text-sm transition"
                placeholder="Correo electrónico"
              />
            </div>
            <div>
              <label htmlFor="password" className="sr-only">Contraseña</label>
              <input
                id="password" name="password" type="password" autoComplete="new-password" required value={password} onChange={(e) => setPassword(e.target.value)}
                className="relative block w-full px-4 py-3 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-lg focus:outline-none focus:ring-[var(--input-focus-ring)] focus:border-[var(--input-focus-ring)] focus:z-10 sm:text-sm transition"
                placeholder="Contraseña"
              />
            </div>
             <div>
              <label htmlFor="confirm-password" className="sr-only">Confirmar contraseña</label>
              <input
                id="confirm-password" name="confirm-password" type="password" autoComplete="new-password" required value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)}
                className="relative block w-full px-4 py-3 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-lg focus:outline-none focus:ring-[var(--input-focus-ring)] focus:border-[var(--input-focus-ring)] focus:z-10 sm:text-sm transition"
                placeholder="Confirmar contraseña"
              />
            </div>
          </div>
          
          {error && <div className="p-3 text-sm text-center text-red-800 bg-red-100 rounded-lg">{error}</div>}

          <div>
            <button
              type="submit"
              disabled={isLoading}
              className="group relative w-full flex justify-center py-3 px-4 border border-transparent text-sm font-medium rounded-lg text-white bg-[var(--button-primary-bg)] hover:bg-[var(--button-primary-hover-bg)] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[var(--button-primary-hover-bg)] disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors"
            >
                {isLoading ? <Icon name="hourglass_top" className="h-5 w-5 text-white animate-spin" /> : 'Registrarse'}
            </button>
          </div>
        </form>

        <div className="text-sm text-center">
            <p className="text-gray-600">
                ¿Ya tienes una cuenta?{' '}
                <a href="#" onClick={(e) => { e.preventDefault(); onSwitchToLogin(); }} className="font-medium text-[var(--text-accent)] hover:text-teal-700">
                    Inicia sesión
                </a>
            </p>
        </div>
      </div>
    </div>
  );
};

export default SignUp;
