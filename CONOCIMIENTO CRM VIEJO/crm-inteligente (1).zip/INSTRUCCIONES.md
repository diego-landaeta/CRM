# INSTRUCCIONES PARA LA BASE DE DATOS SUPABASE

Para restaurar completamente tu base de datos y asegurar que es compatible con la aplicación, por favor sigue estos pasos en el **SQL Editor** de tu proyecto de Supabase.

---

### PASO ÚNICO: Ejecutar Script de Limpieza y Creación

Copia y pega el siguiente script COMPLETO en una nueva consulta en el SQL Editor de Supabase y haz clic en **"RUN"**.

Este script es **idempotente** y seguro de ejecutar. Primero, **eliminará cualquier estructura anterior** para evitar conflictos y luego creará todo desde cero.

```sql
-- ### PASO 0: SCRIPT DE LIMPIEZA COMPLETA ###
-- Se eliminarán todas las tablas y funciones relacionadas para una instalación limpia.

-- Deshabilitar la seguridad a nivel de fila temporalmente para permitir eliminaciones
DO $$
BEGIN
   IF EXISTS (SELECT 1 FROM pg_tables WHERE schemaname = 'public' AND tablename = 'app_config') THEN
      ALTER TABLE public.app_config DISABLE ROW LEVEL SECURITY;
   END IF;
   IF EXISTS (SELECT 1 FROM pg_tables WHERE schemaname = 'public' AND tablename = 'clients') THEN
      ALTER TABLE public.clients DISABLE ROW LEVEL SECURITY;
   END IF;
   IF EXISTS (SELECT 1 FROM pg_tables WHERE schemaname = 'public' AND tablename = 'prospects') THEN
      ALTER TABLE public.prospects DISABLE ROW LEVEL SECURITY;
   END IF;
   IF EXISTS (SELECT 1 FROM pg_tables WHERE schemaname = 'public' AND tablename = 'invitations') THEN
      ALTER TABLE public.invitations DISABLE ROW LEVEL SECURITY;
   END IF;
   IF EXISTS (SELECT 1 FROM pg_tables WHERE schemaname = 'public' AND tablename = 'profiles') THEN
      ALTER TABLE public.profiles DISABLE ROW LEVEL SECURITY;
   END IF;
END $$;

DROP TABLE IF EXISTS public.role_permissions CASCADE;
DROP TABLE IF EXISTS public.roles CASCADE;
DROP TABLE IF EXISTS public.permissions CASCADE;
DROP TABLE IF EXISTS public.email_logs CASCADE;
DROP TABLE IF EXISTS public.rate_limit_logs CASCADE;


-- Eliminar el trigger de auth.users si existe
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

-- Eliminar funciones si existen
DROP FUNCTION IF EXISTS public.handle_new_user();
DROP FUNCTION IF EXISTS public.get_user_role();
DROP FUNCTION IF EXISTS public.is_admin();


-- Eliminar tablas si existen (CASCADE elimina dependencias como claves foráneas)
DROP TABLE IF EXISTS public.app_config CASCADE;
DROP TABLE IF EXISTS public.clients CASCADE;
DROP TABLE IF EXISTS public.prospects CASCADE;
DROP TABLE IF EXISTS public.invitations CASCADE;
DROP TABLE IF EXISTS public.profiles CASCADE;
DROP TABLE IF EXISTS public.email_logs CASCADE;
DROP TABLE IF EXISTS public.rate_limit_logs CASCADE;


-- ### PASO 1: Crear la estructura de tablas ###

-- Tabla de perfiles públicos de usuario, extendiendo auth.users
CREATE TABLE public.profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    full_name TEXT,
    email TEXT,
    role TEXT NOT NULL CHECK (role IN ('platform_admin', 'crm_admin', 'crm_collaborator')),
    crm_id UUID NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now())
);
COMMENT ON TABLE public.profiles IS 'Almacena datos públicos, el rol y el CRM de cada usuario.';

-- Tabla para gestionar invitaciones de nuevos usuarios
CREATE TABLE public.invitations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email TEXT NOT NULL UNIQUE,
    role TEXT NOT NULL, -- Storing role name directly
    crm_id UUID NOT NULL,
    invited_by UUID NOT NULL REFERENCES auth.users(id),
    created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL
);
COMMENT ON TABLE public.invitations IS 'Almacena las invitaciones pendientes para nuevos usuarios.';

-- Tabla de Clientes
CREATE TABLE public.clients (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    crm_id uuid NOT NULL,
    owner_id uuid NOT NULL REFERENCES auth.users(id),
    assignee_id uuid REFERENCES auth.users(id),
    name text NOT NULL,
    email text,
    phone text,
    program text,
    stage text,
    estimated_value numeric,
    last_contact timestamp with time zone,
    creation_date timestamp with time zone NOT NULL DEFAULT now(),
    next_contact timestamp with time zone,
    owner text,
    coordinator text,
    notes text,
    country text,
    origin text,
    payment_type text,
    installments_total integer,
    installments_paid integer,
    installment_details jsonb,
    total_paid numeric DEFAULT 0,
    single_payment_method text,
    PRIMARY KEY (id)
);
COMMENT ON TABLE public.clients IS 'Almacena la información de los clientes, segregada por crm_id.';

-- Tabla de Prospectos
CREATE TABLE public.prospects (
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    crm_id uuid NOT NULL,
    owner_id uuid NOT NULL REFERENCES auth.users(id),
    name text NOT NULL,
    email text,
    phone text,
    program text,
    stage text,
    estimated_value numeric,
    last_contact timestamp with time zone,
    creation_date timestamp with time zone NOT NULL DEFAULT now(),
    next_contact timestamp with time zone,
    owner text,
    coordinator text,
    notes text,
    country text,
    origin text,
    PRIMARY KEY (id)
);
COMMENT ON TABLE public.prospects IS 'Almacena la información de los prospectos, segregada por crm_id.';

-- Tabla de Configuración de la aplicación por CRM
CREATE TABLE public.app_config (
    id bigint GENERATED ALWAYS AS IDENTITY NOT NULL,
    crm_id uuid NOT NULL UNIQUE,
    owner_id uuid NOT NULL UNIQUE REFERENCES auth.users(id),
    field_config jsonb,
    coordinators text[],
    client_statuses text[],
    prospect_statuses text[],
    coordinator_map jsonb,
    countries text[],
    phone_code_info jsonb,
    quick_create_config jsonb,
    academic_offer jsonb,
    academic_offer_config jsonb,
    team_member_role_plural text DEFAULT 'Coordinadoras'::text,
    currency text DEFAULT 'USD'::text,
    PRIMARY KEY (id)
);
COMMENT ON TABLE public.app_config IS 'Configuraciones personalizadas por cada CRM.';

-- Tabla de registro de envíos de correo
CREATE TABLE public.email_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  crm_id uuid,
  user_id uuid REFERENCES auth.users(id),
  role text,
  recipient_email text,
  status text NOT NULL CHECK (status IN ('success', 'error')),
  error_message TEXT,
  created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL
);
COMMENT ON TABLE public.email_logs IS 'Registra cada intento de envío de correo electrónico.';

-- Tabla para el límite de envíos de correo
CREATE TABLE public.rate_limit_logs (
    id BIGSERIAL PRIMARY KEY,
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT timezone('utc'::text, now()) NOT NULL
);
COMMENT ON TABLE public.rate_limit_logs IS 'Registra los envíos de correo para control de frecuencia.';


-- ### PASO 2: Habilitar Row Level Security (RLS) ###
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.invitations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.clients ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.prospects ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.app_config ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.email_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.rate_limit_logs ENABLE ROW LEVEL SECURITY;

-- ### PASO 3: Crear función de ayuda para obtener el rol del usuario actual ###
CREATE OR REPLACE FUNCTION public.get_user_role()
RETURNS TEXT
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  IF auth.uid() IS NULL THEN
    RETURN NULL;
  END IF;
  RETURN (SELECT role FROM public.profiles WHERE id = auth.uid());
END;
$$;


-- ### PASO 4: Crear políticas de acceso RLS ###

-- Perfiles: Los usuarios pueden ver a otros de su mismo CRM. Admins ven todo.
CREATE POLICY "Allow users to view profiles in their own CRM" ON public.profiles FOR SELECT USING (
  get_user_role() = 'platform_admin' OR
  crm_id = (SELECT crm_id FROM public.profiles WHERE id = auth.uid())
);
CREATE POLICY "Allow users to update their own profile" ON public.profiles FOR UPDATE USING (auth.uid() = id) WITH CHECK (auth.uid() = id);
CREATE POLICY "Allow CRM admins to update profiles in their CRM" ON public.profiles FOR UPDATE USING (
    get_user_role() = 'crm_admin' AND crm_id = (SELECT crm_id FROM public.profiles WHERE id = auth.uid())
);
CREATE POLICY "Allow platform_admin to manage all profiles" ON public.profiles FOR ALL USING (get_user_role() = 'platform_admin');

-- Invitaciones: Admins pueden gestionar invitaciones.
CREATE POLICY "Allow admins to manage invitations" ON public.invitations FOR ALL USING (
    get_user_role() IN ('platform_admin', 'crm_admin') AND
    crm_id = (SELECT crm_id FROM public.profiles WHERE id = auth.uid())
) WITH CHECK (
    crm_id = (SELECT crm_id FROM public.profiles WHERE id = auth.uid())
);
CREATE POLICY "Allow platform_admin full access to invitations" ON public.invitations FOR ALL USING (get_user_role() = 'platform_admin');


-- Datos de negocio: Acceso por crm_id o si es platform_admin
CREATE POLICY "Allow platform_admin full access to clients" ON public.clients FOR ALL USING (get_user_role() = 'platform_admin');
CREATE POLICY "Allow users to access clients in their CRM" ON public.clients FOR ALL USING (crm_id = (SELECT crm_id FROM public.profiles WHERE id = auth.uid()));

CREATE POLICY "Allow platform_admin full access to prospects" ON public.prospects FOR ALL USING (get_user_role() = 'platform_admin');
CREATE POLICY "Allow users to access prospects in their CRM" ON public.prospects FOR ALL USING (crm_id = (SELECT crm_id FROM public.profiles WHERE id = auth.uid()));

CREATE POLICY "Allow platform_admin full access to app_config" ON public.app_config FOR ALL USING (get_user_role() = 'platform_admin');
CREATE POLICY "Allow crm_admin to access their config" ON public.app_config FOR ALL USING (crm_id = (SELECT crm_id FROM public.profiles WHERE id = auth.uid()));

CREATE POLICY "Allow platform_admin full access to email_logs" ON public.email_logs FOR ALL USING (get_user_role() = 'platform_admin');
CREATE POLICY "Allow users to access email_logs in their CRM" ON public.email_logs FOR ALL USING (crm_id = (SELECT crm_id FROM public.profiles WHERE id = auth.uid()));

CREATE POLICY "Users can manage their own rate limit logs" ON public.rate_limit_logs FOR ALL USING (user_id = auth.uid());


-- ### PASO 5: Crear la función y el trigger para manejar nuevos usuarios ###
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  assigned_role TEXT;
  assigned_crm_id UUID;
  profile_count INT;
  invitation RECORD;
BEGIN
  -- 1. Buscar una invitación para el email del nuevo usuario
  SELECT * INTO invitation FROM public.invitations WHERE email = new.email;

  IF invitation IS NOT NULL THEN
    -- Si fue invitado, se le asigna el rol y crm_id de la invitación
    assigned_role := invitation.role;
    assigned_crm_id := invitation.crm_id;
    DELETE FROM public.invitations WHERE email = new.email;
  ELSE
    -- Si no fue invitado, se determina el rol
    SELECT count(*) INTO profile_count FROM public.profiles;
    IF profile_count = 0 THEN
      -- El primer usuario de toda la plataforma se convierte en platform_admin
      assigned_role := 'platform_admin';
      assigned_crm_id := gen_random_uuid(); -- Asigna un nuevo CRM ID para el admin de la plataforma
    ELSE
      -- Los usuarios siguientes no invitados se convierten en crm_admin
      assigned_role := 'crm_admin';
      assigned_crm_id := gen_random_uuid(); -- Cada nuevo admin crea su propio CRM
    END IF;
  END IF;
  
  -- Insertar el nuevo perfil
  INSERT INTO public.profiles (id, full_name, email, role, crm_id)
  VALUES (
    new.id,
    coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name'),
    new.email,
    assigned_role,
    assigned_crm_id
  );
  
  -- Si el usuario es un nuevo admin (platform o crm), crear su configuración
  IF assigned_role IN ('platform_admin', 'crm_admin') THEN
    INSERT INTO public.app_config (crm_id, owner_id)
    VALUES (assigned_crm_id, new.id);
  END IF;
  
  RETURN new;
END;
$$;

-- Este trigger llama a la función `handle_new_user` después de que se cree un nuevo usuario.
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();


-- ### PASO 6: Limpiar registros antiguos en la tabla de rate limiting (Opcional pero recomendado) ###
-- Esta función se puede llamar periódicamente usando Supabase Cron Jobs para mantener la tabla limpia.
CREATE OR REPLACE FUNCTION public.cleanup_rate_limit_logs()
RETURNS void
LANGUAGE sql
AS $$
  DELETE FROM public.rate_limit_logs WHERE created_at < now() - interval '5 minutes';
$$;
```
---

Una vez que hayas ejecutado el script, tu base de datos estará lista. La aplicación ya está configurada para conectarse a ella. Solo necesitas recargar la página.