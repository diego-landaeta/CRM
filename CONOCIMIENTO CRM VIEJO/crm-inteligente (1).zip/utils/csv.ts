
import * as XLSX from 'xlsx';

/**
 * Downloads an Excel template file with specified headers and an optional example row.
 * @param filename The name of the file to download (e.g., "template.xlsx").
 * @param headers An array of strings for the header row.
 * @param exampleRow An optional array of values for the second row.
 */
export function downloadExcelTemplate(filename: string, headers: string[], exampleRow?: (string | number | null)[]) {
    const wsData: any[][] = [headers];
    if (exampleRow) {
        // Ensure the example row has the same number of columns as headers
        const normalizedExampleRow = headers.map((_, i) => exampleRow[i] ?? null);
        wsData.push(normalizedExampleRow);
    }
    const worksheet = XLSX.utils.aoa_to_sheet(wsData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Plantilla");
    XLSX.writeFile(workbook, filename);
}


/**
 * Parses an Excel file and returns its content as an array of objects.
 * @param file The Excel file to parse.
 * @returns A promise that resolves with an array of objects.
 */
export function parseExcel(file: File): Promise<any[]> {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = (event) => {
            try {
                const data = event.target?.result;
                const workbook = XLSX.read(data, { type: 'array', cellDates: true });
                const sheetName = workbook.SheetNames[0];
                if (!sheetName) {
                    throw new Error("El archivo Excel no contiene hojas.");
                }
                const worksheet = workbook.Sheets[sheetName];
                // Using raw: true gets raw numbers, and cellDates: true from read() provides JS Dates.
                // This combination is best for data processing. defval: null handles empty cells cleanly.
                const json = XLSX.utils.sheet_to_json(worksheet, { raw: true, defval: null });
                resolve(json);
            } catch (e) {
                reject(e);
            }
        };
        reader.onerror = (error) => reject(error);
        reader.readAsArrayBuffer(file);
    });
}

/**
 * Exports an array of objects to an Excel file.
 * @param filename The name of the file to download (e.g., "report.xlsx").
 * @param rows An array of objects to export.
 */
export function exportToExcel(filename: string, rows: object[]) {
    if (!rows || !rows.length) {
        alert("No hay datos para exportar.");
        return;
    }
    const worksheet = XLSX.utils.json_to_sheet(rows);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Datos");
    XLSX.writeFile(workbook, filename, { bookType: 'xlsx', type: 'binary' });
}
