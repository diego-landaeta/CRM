import type { User as SupabaseUser } from '@supabase/gotrue-js';

// The 'Json' type from '@supabase/supabase-js' is deprecated.
// We define it locally to represent any valid JSON structure.
export type Json = string | number | boolean | null | { [key: string]: any } | any[];
export type RoleType = 'platform_admin' | 'crm_admin' | 'crm_collaborator';

export interface Database {
  public: {
    Tables: {
      clients: {
        Row: {
          id: string
          crm_id: string
          owner_id: string
          assignee_id: string | null
          estimated_value: number
          last_contact: string
          creation_date: string
          next_contact: string | null
          name: string
          email: string
          phone: string | null
          program: string
          stage: string
          owner: string
          coordinator: string
          notes: string
          country: string
          origin: string
          payment_type: string | null
          installments_total: number | null
          installments_paid: number | null
          installment_details: Json | null
          total_paid: number
          single_payment_method: string | null
        }
        Insert: {
          id?: string
          crm_id: string
          owner_id: string
          assignee_id?: string | null
          estimated_value: number
          last_contact: string
          creation_date: string
          next_contact?: string | null
          name: string
          email: string
          phone?: string | null
          program: string
          stage: string
          owner: string
          coordinator: string
          notes: string
          country: string
          origin: string
          payment_type?: string | null
          installments_total?: number | null
          installments_paid?: number | null
          installment_details?: Json | null
          total_paid?: number
          single_payment_method?: string | null
        }
        Update: {
          id?: string
          crm_id?: string
          owner_id?: string
          assignee_id?: string | null
          estimated_value?: number
          last_contact?: string
          creation_date?: string
          next_contact?: string | null
          name?: string
          email?: string
          phone?: string | null
          program?: string
          stage?: string
          owner?: string
          coordinator?: string
          notes?: string
          country?: string
          origin?: string
          payment_type?: string | null
          installments_total?: number | null
          installments_paid?: number | null
          installment_details?: Json | null
          total_paid?: number
          single_payment_method?: string | null
        }
      }
      prospects: {
        Row: {
          id: string
          crm_id: string
          creation_date: string
          estimated_value: number
          last_contact: string
          next_contact: string | null
          name: string
          email: string
          phone: string | null
          program: string
          stage: string
          owner: string
          coordinator: string
          notes: string
          country: string
          origin: string
          owner_id: string
        }
        Insert: {
          id?: string
          crm_id: string
          creation_date: string
          estimated_value: number
          last_contact: string
          next_contact?: string | null
          name: string
          email: string
          phone?: string | null
          program: string
          stage: string
          owner: string
          coordinator: string
          notes: string
          country: string
          origin: string
          owner_id: string
        }
        Update: {
          id?: string
          crm_id?: string
          creation_date?: string
          estimated_value?: number
          last_contact?: string
          next_contact?: string | null
          name?: string
          email?: string
          phone?: string | null
          program?: string
          stage?: string
          owner?: string
          coordinator?: string
          notes?: string
          country?: string
          origin?: string
          owner_id?: string
        }
      }
      app_config: {
        Row: {
          id: number
          crm_id: string
          owner_id: string
          field_config: Json | null
          coordinators: string[] | null
          client_statuses: string[] | null
          prospect_statuses: string[] | null
          coordinator_map: CoordinatorMap | null
          countries: string[] | null
          phone_code_info: Json | null
          quick_create_config: Json | null
          academic_offer: Json | null
          academic_offer_config: { is_enabled: boolean } | null
          team_member_role_plural: string | null
          currency: string | null
        }
        Insert: {
          id?: number
          crm_id: string
          owner_id: string
          field_config?: Json | null
          coordinators?: string[] | null
          client_statuses?: string[] | null
          prospect_statuses?: string[] | null
          coordinator_map?: CoordinatorMap | null
          countries?: string[] | null
          phone_code_info?: Json | null
          quick_create_config?: Json | null
          academic_offer?: Json | null
          academic_offer_config?: { is_enabled: boolean } | null
          team_member_role_plural?: string | null
          currency?: string | null
        }
        Update: {
          id?: number
          crm_id?: string
          owner_id?: string
          field_config?: Json | null
          coordinators?: string[] | null
          client_statuses?: string[] | null
          prospect_statuses?: string[] | null
          coordinator_map?: CoordinatorMap | null
          countries?: string[] | null
          phone_code_info?: Json | null
          quick_create_config?: Json | null
          academic_offer?: Json | null
          academic_offer_config?: { is_enabled: boolean } | null
          team_member_role_plural?: string | null
          currency?: string | null
        }
      }
      profiles: {
        Row: {
          id: string
          full_name: string | null
          email: string | null
          role: RoleType
          crm_id: string
          updated_at: string | null
        }
        Insert: {
          id: string
          full_name?: string | null
          email?: string | null
          role: RoleType
          crm_id: string
        }
        Update: {
          id?: string
          full_name?: string | null
          email?: string | null
          role?: RoleType
          crm_id?: string
        }
      }
      invitations: {
        Row: {
            id: string
            email: string
            role: string
            crm_id: string
            invited_by: string
            created_at: string
        }
        Insert: {
            id?: string
            email: string
            role: string
            crm_id: string
            invited_by: string
        }
      }
      email_logs: {
        Row: {
            id: string
            crm_id: string
            user_id: string
            role: string
            recipient_email: string
            status: 'success' | 'error'
            error_message: string | null
            created_at: string
        }
        Insert: {
            crm_id: string
            user_id: string
            role: string
            recipient_email: string
            status: 'success' | 'error'
            error_message?: string | null
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
  }
}

export type Profile = Database['public']['Tables']['profiles']['Row'];

export type Page = 'Dashboard' | 'Email' | 'Clients' | 'Prospects' | 'Billing' | 'Configuration' | 'Support' | 'AddClient' | 'AddProspect' | 'ConvertProspect' | 'EditClient' | 'EditProspect' | 'Manual' | 'Notifications' | 'Calendar' | 'Statistics' | 'Roles';

export interface ChatMessage {
    id: string;
    role: 'user' | 'model' | 'system';
    text: string;
    isError?: boolean;
}

export interface NavItem {
    id: Page | string; // Parent items can have a string ID
    label: string;
    icon: string;
    subItems?: NavItem[];
}

export interface Notification {
  id: string;
  title: string;
  message: string;
  sender: string;
  timestamp: string;
  read: boolean;
  icon: string;
  iconColor: string;
}


// Supabase user object now includes the public profile information.
export interface User extends SupabaseUser {
    profile: Profile | null;
}

export interface Installment {
    amount: number;
    dueDate: string;
    status: 'Pendiente' | 'Pagado';
    paymentMethod: string | null;
}

export type Client = Database['public']['Tables']['clients']['Row'];
export type ClientInsert = Database['public']['Tables']['clients']['Insert'];
export type ClientUpdate = Database['public']['Tables']['clients']['Update'];
export interface ClientDataForCreate {
    name: string;
    email: string;
    phone: string | null;
    program: string;
    stage: string;
    estimated_value: number;
    next_contact: string | null;
    owner: string;
    notes: string;
    country: string;
    origin: string;
    coordinator: string;
    payment_type: string | null;
    installments_total: number | null;
    installments_paid: number | null;
    installment_details: Json | null;
    single_payment_method: string | null;
}


export type Prospect = Database['public']['Tables']['prospects']['Row'];
export type ProspectInsert = Database['public']['Tables']['prospects']['Insert'];
export type ProspectUpdate = Database['public']['Tables']['prospects']['Update'];
export interface ProspectDataForCreate {
    name: string;
    email: string;
    phone: string | null;
    program: string;
    stage: string;
    estimated_value: number;
    next_contact: string | null;
    owner: string;
    notes: string;
    country: string;
    origin: string;
    coordinator: string;
}


export interface QuickCreateConfigType {
    client: { is_visible: boolean; required_fields: string[] };
    prospect: { is_visible: boolean; required_fields: string[] };
}

export type AppConfig = Database['public']['Tables']['app_config']['Row'];
export type AppConfigInsert = Database['public']['Tables']['app_config']['Insert'];
export type AppConfigUpdate = Database['public']['Tables']['app_config']['Update'];


// For field customization
export interface FieldConfig {
    key: string;
    label: string;
    isVisible: boolean;
    inputType: 'text' | 'select' | 'date' | 'number' | 'textarea';
}

export type EntityType = 'client' | 'prospect';

export interface CoordinatorMap {
    [country: string]: string;
}

export interface RecentActivity {
  id: string;
  icon: string;
  iconColor: string;
  title: string;
  timestamp: string;
}

export interface PendingTask {
  id:string;
  title: string;
  dueDate: string;
  dueColor: string;
}

// Base interface for contacts, using snake_case to align with database schema.
export type Contact = Client;

// Academic Offer Structure
export interface AcademicProgram {
    id: string; // e.g., using crypto.randomUUID()
    name: string;
}

export type ProgramType = 'courses' | 'diplomas' | 'masters' | 'specializations';

export const ProgramTypeLabels: Record<ProgramType, string> = {
    courses: 'Cursos',
    diplomas: 'Diplomados',
    masters: 'Masters',
    specializations: 'Especializaciones'
};

export interface Faculty {
    id: string; // e.g., using crypto.randomUUID()
    name: string;
    courses: AcademicProgram[];
    diplomas: AcademicProgram[];
    masters: AcademicProgram[];
    specializations: AcademicProgram[];
}

export type AcademicOffer = Faculty[];

export interface FoundContact {
  contact: Client | Prospect;
  type: 'client' | 'prospect';
}
