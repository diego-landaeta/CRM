import { createClient } from '@supabase/supabase-js'
import type { Database } from "../types.ts";

// Se han actualizado las credenciales para apuntar a tu nuevo proyecto de Supabase.
const supabaseUrl = "https://nlombfyhpsexbmwzzhpb.supabase.co";
const supabaseAnonKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im5sb21iZnlocHNleGJtd3p6aHBiIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTQ5NDU4MzQsImV4cCI6MjA3MDUyMTgzNH0.cp2F20ezHT7yiasTTeMNZ37a79z9YnHqirl4C68j7OQ";

// Initialize the Supabase client
export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey);