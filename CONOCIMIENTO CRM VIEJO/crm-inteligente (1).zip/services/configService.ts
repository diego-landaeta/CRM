import { FieldConfig, EntityType, CoordinatorMap, AppConfig, Contact, QuickCreateConfigType, AppConfigUpdate, AppConfigInsert, AcademicOffer, ProgramType, AcademicProgram, ProgramTypeLabels, Json } from '../types.ts';
import { supabase } from './supabaseClient.ts';
import { authService } from './authService.ts';

const DEFAULT_FIELD_CONFIG: Record<EntityType, FieldConfig[]> = {
    client: [
        { key: 'name', label: 'Nombre', isVisible: true, inputType: 'text' },
        { key: 'email', label: 'Email', isVisible: true, inputType: 'text' },
        { key: 'phone', label: 'Teléfono', isVisible: true, inputType: 'text' },
        { key: 'program', label: 'Programa de Estudio', isVisible: true, inputType: 'select' },
        { key: 'stage', label: 'Etapa', isVisible: true, inputType: 'select' },
        { key: 'estimated_value', label: 'Valor Total Venta', isVisible: false, inputType: 'number' },
        { key: 'payment_type', label: 'Tipo de Pago', isVisible: true, inputType: 'select' },
        { key: 'installments_total', label: 'Total Cuotas', isVisible: false, inputType: 'number' },
        { key: 'installments_paid', label: 'Cuotas Pagadas', isVisible: false, inputType: 'number' },
        { key: 'total_paid', label: 'Total Abonado', isVisible: true, inputType: 'number' },
        { key: 'last_contact', label: 'Último Contacto', isVisible: true, inputType: 'date' },
        { key: 'next_contact', label: 'Próximo Contacto', isVisible: true, inputType: 'date' },
        { key: 'owner', label: 'Propietario', isVisible: true, inputType: 'text' },
        { key: 'coordinator', label: 'Coordinadora', isVisible: true, inputType: 'select' },
        { key: 'country', label: 'País', isVisible: false, inputType: 'select' },
        { key: 'origin', label: 'Origen', isVisible: false, inputType: 'select' },
        { key: 'notes', label: 'Notas', isVisible: false, inputType: 'textarea' },
        { key: 'id', label: 'ID', isVisible: false, inputType: 'text' },
        { key: 'creation_date', label: 'Fecha Creación', isVisible: false, inputType: 'date' },
        { key: 'owner_id', label: 'Owner ID', isVisible: false, inputType: 'text' },
    ],
    prospect: [
        { key: 'name', label: 'Nombre', isVisible: true, inputType: 'text' },
        { key: 'email', label: 'Email', isVisible: true, inputType: 'text' },
        { key: 'phone', label: 'Teléfono', isVisible: true, inputType: 'text' },
        { key: 'program', label: 'Programa de Estudio', isVisible: true, inputType: 'select' },
        { key: 'stage', label: 'Etapa', isVisible: true, inputType: 'select' },
        { key: 'estimated_value', label: 'Valor Estimado', isVisible: false, inputType: 'number' },
        { key: 'last_contact', label: 'Último Contacto', isVisible: false, inputType: 'date' },
        { key: 'next_contact', label: 'Próximo Contacto', isVisible: true, inputType: 'date' },
        { key: 'owner', label: 'Propietario', isVisible: true, inputType: 'text' },
        { key: 'coordinator', label: 'Coordinadora', isVisible: true, inputType: 'select' },
        { key: 'country', label: 'País', isVisible: false, inputType: 'select' },
        { key: 'origin', label: 'Origen', isVisible: false, inputType: 'select' },
        { key: 'notes', label: 'Notas', isVisible: false, inputType: 'textarea' },
        { key: 'id', label: 'ID', isVisible: false, inputType: 'text' },
        { key: 'creation_date', label: 'Fecha Creación', isVisible: false, inputType: 'date' },
        { key: 'owner_id', label: 'Owner ID', isVisible: false, inputType: 'text' },
    ]
};

const getDefaultConfig = (): Omit<AppConfig, 'id' | 'owner_id' | 'crm_id'> => ({
    field_config: DEFAULT_FIELD_CONFIG as unknown as Json,
    coordinators: ['Isabel', 'Sofía'],
    client_statuses: ['Activo', 'Soporte', 'Renovación', 'Leal', 'Inactivo'],
    prospect_statuses: ['Nuevo', 'Calificado', 'Propuesta', 'Negociación', 'Cerrado Ganado', 'Cerrado Perdido'],
    coordinator_map: { 'México': 'Isabel', 'Colombia': 'Sofía' },
    countries: ['México', 'Colombia', 'España', 'Argentina'],
    phone_code_info: null, // This field is no longer used
    quick_create_config: {
        client: { is_visible: true, required_fields: ['name', 'email', 'stage'] as Array<keyof Contact> },
        prospect: { is_visible: true, required_fields: ['name', 'email', 'stage'] as Array<keyof Contact> }
    } as Json,
    academic_offer: [] as Json,
    academic_offer_config: { is_enabled: true },
    team_member_role_plural: 'Coordinadoras',
    currency: 'USD',
});


class ConfigService {
    private cachedConfig: AppConfig | null = null;

    private async getConfig(forceRefetch = false): Promise<AppConfig> {
        if (this.cachedConfig && !forceRefetch) {
            return this.cachedConfig;
        }

        const user = await authService.getUser();
        if (!user || !user.profile) {
            console.warn("User not authenticated, returning temporary default config.");
            // Return a default config object that can't be saved because owner_id is missing.
            return {
                id: 0,
                owner_id: '',
                crm_id: '',
                ...getDefaultConfig()
            };
        }

        const { data, error } = await supabase
            .from('app_config')
            .select('*')
            .eq('crm_id', user.profile.crm_id) // Filter by the user's CRM ID
            .single();

        if (error || !data) {
            // Log a real error only if it's not the "no rows found" error.
            if (error && error.code !== 'PGRST116') {
                 console.error("Error fetching user configuration:", error.message);
            }
            console.warn("No existing config found for this user. A new one will be created on the first save.");
            // This is a new user without a config. Return a temporary default config with their ID.
            this.cachedConfig = {
                id: 0, // 0 indicates a non-existent record that needs to be inserted.
                owner_id: user.id,
                crm_id: user.profile.crm_id,
                ...getDefaultConfig()
            };
            return this.cachedConfig;
        }
        
        const configData = data as AppConfig;
        const defaultConfig = getDefaultConfig();
        
        // This is a good practice for backward compatibility: ensure new config fields exist on older records.
        if (!configData.quick_create_config) {
            configData.quick_create_config = defaultConfig.quick_create_config;
        }
        if (!configData.academic_offer) {
            configData.academic_offer = defaultConfig.academic_offer;
        }
        if (!configData.academic_offer_config) {
            configData.academic_offer_config = defaultConfig.academic_offer_config;
        }
        if (!configData.team_member_role_plural) {
            configData.team_member_role_plural = defaultConfig.team_member_role_plural;
        }
        if (!configData.currency) {
            configData.currency = defaultConfig.currency;
        }


        this.cachedConfig = configData;
        return this.cachedConfig;
    }

    public async updateConfig(newConfig: AppConfigUpdate): Promise<void> {
        const currentConfig = await this.getConfig(); 
        const configId = currentConfig.id;

        try {
            if (configId > 0) { // Existing config, so UPDATE
                 const payload: AppConfigUpdate = { ...newConfig };
                 delete payload.id;
                 const { error } = await supabase
                    .from('app_config')
                    .update(payload)
                    .eq('id', configId);
                if (error) throw error;

            } else { // No existing config, so INSERT
                const user = await authService.getUser();
                if (!user || !user.profile) throw new Error("Cannot save configuration: user not authenticated.");
                
                const defaultConfig = getDefaultConfig();
                
                const fullNewConfig: AppConfigInsert = {
                    owner_id: user.id,
                    crm_id: user.profile.crm_id,
                    field_config: newConfig.field_config ?? defaultConfig.field_config,
                    coordinators: newConfig.coordinators ?? defaultConfig.coordinators,
                    client_statuses: newConfig.client_statuses ?? defaultConfig.client_statuses,
                    prospect_statuses: newConfig.prospect_statuses ?? defaultConfig.prospect_statuses,
                    coordinator_map: newConfig.coordinator_map ?? defaultConfig.coordinator_map,
                    countries: newConfig.countries ?? defaultConfig.countries,
                    phone_code_info: newConfig.phone_code_info ?? defaultConfig.phone_code_info,
                    quick_create_config: newConfig.quick_create_config ?? defaultConfig.quick_create_config,
                    academic_offer: newConfig.academic_offer ?? defaultConfig.academic_offer,
                    academic_offer_config: newConfig.academic_offer_config ?? defaultConfig.academic_offer_config,
                    team_member_role_plural: newConfig.team_member_role_plural ?? defaultConfig.team_member_role_plural,
                    currency: newConfig.currency ?? defaultConfig.currency,
                };
    
                const { error: insertError } = await supabase
                    .from('app_config')
                    .insert([fullNewConfig])
                    .select()
                    .single();

                if (insertError) throw insertError;
            }
            
            // Invalidate cache and notify app
            await this.getConfig(true); // Force refetch the new state
            window.dispatchEvent(new Event('config_updated'));

        } catch (error: any) {
            console.error("Error saving config:", error.message || error);
            throw error; // Re-throw to be caught by the UI
        }
    }


    // --- Field Configuration ---

    async getFieldConfig(entity: EntityType): Promise<FieldConfig[]> {
        const config = await this.getConfig();
        const fieldConfig = config.field_config as unknown as Record<EntityType, FieldConfig[]>;
        return fieldConfig?.[entity] || DEFAULT_FIELD_CONFIG[entity];
    }
    
    async getVisibleFields(entity: EntityType): Promise<FieldConfig[]> {
        const fields = await this.getFieldConfig(entity);
        return fields.filter(field => field.isVisible);
    }
    
    async updateFieldConfig(entity: EntityType, updatedEntityConfig: FieldConfig[]) {
        const currentConfig = await this.getConfig();
        const currentFields = currentConfig.field_config ? (currentConfig.field_config as Record<string, unknown>) : {};
        const newFieldConfig = { ...currentFields, [entity]: updatedEntityConfig };
        await this.updateConfig({ field_config: newFieldConfig as unknown as Json });
    }

    async getLabel(entity: EntityType, key: keyof import('../types.ts').Contact): Promise<string> {
        const config = await this.getFieldConfig(entity);
        const field = config.find(f => f.key === key);
        const defaultField = DEFAULT_FIELD_CONFIG[entity].find(f => f.key === key);
        return field?.label || defaultField?.label || key.toString();
    }

    // --- Quick Create Configuration ---

    async getQuickCreateConfig(): Promise<QuickCreateConfigType> {
        const config = await this.getConfig();
        return (config.quick_create_config as unknown as QuickCreateConfigType) || (getDefaultConfig().quick_create_config as unknown as QuickCreateConfigType);
    }

    async updateQuickCreateConfig(newQuickConfig: QuickCreateConfigType) {
        await this.updateConfig({ quick_create_config: newQuickConfig as unknown as Json });
    }

    // --- Coordinator Configuration ---

    async getCoordinatorMap(): Promise<CoordinatorMap> {
        const config = await this.getConfig();
        return (config.coordinator_map as CoordinatorMap) || {};
    }

    async updateCoordinatorMap(newMap: CoordinatorMap) {
        await this.updateConfig({ coordinator_map: newMap });
    }

    async getCoordinatorForCountry(country: string): Promise<string> {
        const map = await this.getCoordinatorMap();
        return map[country] || '';
    }

    // --- Academic Offer ---
    async getAcademicOffer(): Promise<AcademicOffer> {
        const config = await this.getConfig();
        const offer = config.academic_offer;
        // Ensure the returned value is always an array to prevent iterable errors.
        if (Array.isArray(offer)) {
            return offer as unknown as AcademicOffer;
        }
        return [];
    }

    async updateAcademicOffer(newOffer: AcademicOffer) {
        await this.updateConfig({ academic_offer: newOffer as unknown as Json });
    }

    async getAcademicOfferConfig(): Promise<{ is_enabled: boolean }> {
        const config = await this.getConfig();
        return (config.academic_offer_config as { is_enabled: boolean }) || { is_enabled: true };
    }

    async updateAcademicOfferConfig(newOfferConfig: { is_enabled: boolean }) {
        await this.updateConfig({ academic_offer_config: newOfferConfig });
    }

    // --- Team Role Label ---
    async getTeamMemberRolePlural(): Promise<string> {
        const config = await this.getConfig();
        return config.team_member_role_plural || 'Coordinadoras';
    }
    
    async getTeamMemberRoleSingular(): Promise<string> {
        const plural = await this.getTeamMemberRolePlural();
         if (plural.toLowerCase().endsWith('es')) {
            return plural.slice(0, -2);
        }
        if (plural.toLowerCase().endsWith('s')) {
            return plural.slice(0, -1);
        }
        return plural;
    }


    async updateTeamMemberRolePlural(newRole: string) {
        await this.updateConfig({ team_member_role_plural: newRole });
    }

    // --- Currency ---
    async getCurrency(): Promise<'USD' | 'EUR'> {
        const config = await this.getConfig();
        const currency = config.currency;
        if (currency === 'EUR' || currency === 'USD') {
            return currency;
        }
        return 'USD';
    }

    async updateCurrency(newCurrency: 'USD' | 'EUR') {
        await this.updateConfig({ currency: newCurrency });
    }


    async getAllProgramNames(): Promise<string[]> {
        const offer = await this.getAcademicOffer();
        // Add defensive checks for each program type array within a faculty.
        return offer.flatMap(faculty => [
            ...(faculty.courses || []).map(p => p.name),
            ...(faculty.diplomas || []).map(p => p.name),
            ...(faculty.masters || []).map(p => p.name),
            ...(faculty.specializations || []).map(p => p.name),
        ]).sort();
    }
    
    public async ensureAcademicProgramExists(facultyName: string, programTypeLabel: string, programName: string): Promise<void> {
        if (!facultyName?.trim() || !programTypeLabel?.trim() || !programName?.trim()) {
            return; // Don't add if any part is missing
        }

        const offer = await this.getAcademicOffer();
        let offerWasModified = false;

        let faculty = offer.find(f => f.name.toLowerCase() === facultyName.trim().toLowerCase());

        if (!faculty) {
            faculty = {
                id: crypto.randomUUID(),
                name: facultyName.trim(),
                courses: [], diplomas: [], masters: [], specializations: [],
            };
            offer.push(faculty);
            offerWasModified = true;
        }

        const programTypeKey = (Object.entries(ProgramTypeLabels) as [ProgramType, string][]).find(
            ([_key, label]) => label.toLowerCase() === programTypeLabel.toLowerCase()
        )?.[0];

        if (!programTypeKey) {
            console.warn(`Invalid program type label: ${programTypeLabel}`);
            return;
        }
        
        if (!faculty[programTypeKey]) {
          faculty[programTypeKey] = [];
        }

        const programExists = faculty[programTypeKey].some(p => p.name.toLowerCase() === programName.trim().toLowerCase());

        if (!programExists) {
            const newProgram: AcademicProgram = { id: crypto.randomUUID(), name: programName.trim() };
            faculty[programTypeKey].push(newProgram);
            offerWasModified = true;
        }

        if (offerWasModified) {
            await this.updateAcademicOffer(offer);
        }
    }

    // --- List Management ---
    private asStringArray(list: any): string[] {
        if (Array.isArray(list)) {
            return list.filter(item => typeof item === 'string') as string[];
        }
        return [];
    }

    private async getList(key: 'coordinators' | 'client_statuses' | 'prospect_statuses' | 'countries'): Promise<string[]> {
        const config = await this.getConfig();
        return this.asStringArray(config[key]);
    }

    private async addToList(key: 'coordinators' | 'client_statuses' | 'prospect_statuses' | 'countries', name: string) {
        if (!name?.trim()) return;
        const list = await this.getList(key);
        if (!list.some(item => item.toLowerCase() === name.trim().toLowerCase())) {
            await this.updateConfig({ [key]: [...list, name.trim()] });
        }
    }

    private async deleteFromList(key: 'coordinators' | 'client_statuses' | 'prospect_statuses' | 'countries', name: string) {
        const list = await this.getList(key);
        await this.updateConfig({ [key]: list.filter(item => item !== name) });
    }

    getCoordinators = () => this.getList('coordinators');
    addCoordinator = (name: string) => this.addToList('coordinators', name);
    deleteCoordinator = (name: string) => this.deleteFromList('coordinators', name);
    ensureCoordinatorExists = async (name: string) => this.addToList('coordinators', name);

    getClientStatuses = () => this.getList('client_statuses');
    addClientStatus = (name: string) => this.addToList('client_statuses', name);
    deleteClientStatus = (name: string) => this.deleteFromList('client_statuses', name);
    ensureClientStageExists = async (name: string) => this.addToList('client_statuses', name);

    getProspectStatuses = () => this.getList('prospect_statuses');
    addProspectStatus = (name: string) => this.addToList('prospect_statuses', name);
    deleteProspectStatus = (name: string) => this.deleteFromList('prospect_statuses', name);
    ensureProspectStageExists = async (name: string) => this.addToList('prospect_statuses', name);

    getCountries = () => this.getList('countries');
    addCountry = (name: string) => this.addToList('countries', name);

    async deleteCountry(name: string) {
        const countries = await this.getCountries();
        const coordinatorMap = await this.getCoordinatorMap();

        if (countries.includes(name)) {
            delete coordinatorMap[name];
            
            await this.updateConfig({
                countries: countries.filter(c => c !== name),
                coordinator_map: coordinatorMap,
            });
        }
    }
}

export const configService = new ConfigService();