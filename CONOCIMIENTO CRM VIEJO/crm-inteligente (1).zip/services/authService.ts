import { supabase } from './supabaseClient.ts';
import { User, Profile } from '../types.ts';
import type { AuthChangeEvent, Session } from '@supabase/gotrue-js';

// The authentication methods have been updated to work with the modern
// Supabase JS library (v2) to resolve runtime errors.

class AuthService {
  
  async signup(name: string, email: string, password: string): Promise<User | null> {
    const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
            data: {
              full_name: name, // This name will be used by the trigger to create the profile
              email: email, // Make email available to the trigger
            }
        }
    });
    
    if (error) throw error;
    if (!data.user) throw new Error("Signup failed, no user returned.");
    
    // The profile is created by the trigger, so we don't need to return it here.
    // The onAuthStateChange listener will fetch the full user with profile.
    return (data.user as User) || null;
  }
  
  async login(email: string, password: string): Promise<User | null> {
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    
    if (error) throw error;
    if (!data.session || !data.user) throw new Error('Login failed, no session returned.');
    
    // After login, fetch the user with their profile
    return this.getUser();
  }

  async logout(): Promise<void> {
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
    console.log("User logged out.");
  }

  async getUser(): Promise<User | null> {
    const { data: { user }, error } = await supabase.auth.getUser();
     if (error || !user) {
        return null;
    }
    
    const { data: profile } = await supabase
        .from('profiles')
        .select(`*`)
        .eq('id', user.id)
        .single();

    const fullUser: User = { ...user, profile: profile as Profile | null };
    return fullUser;
  }

  async updatePassword(newPassword: string): Promise<void> {
    const { data, error } = await supabase.auth.updateUser({ password: newPassword });
    if (error) {
        console.error("Error updating password:", error.message);
        throw error;
    }
  }

  async resetPasswordForEmail(email: string): Promise<void> {
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: window.location.origin, // Redirect user back to the app
    });
    if (error) {
        console.error("Error sending password reset email:", error.message);
        throw error;
    }
  }

  onAuthStateChange(callback: (event: AuthChangeEvent, session: Session | null) => void) {
    return supabase.auth.onAuthStateChange(callback);
  }
}

export const authService = new AuthService();