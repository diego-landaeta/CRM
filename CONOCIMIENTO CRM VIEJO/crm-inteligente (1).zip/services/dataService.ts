import { Client, Prospect, ClientDataForCreate, ProspectDataForCreate, ClientUpdate, ProspectUpdate, ClientInsert, ProspectInsert, FoundContact, Installment, Json, Profile, RoleType } from '../types.ts';
import { configService } from './configService.ts';
import { supabase } from './supabaseClient.ts';
import { authService } from './authService.ts';

class DataService {

    private async getAuthContext(): Promise<{ userId: string; crmId: string; role: RoleType; userFullName: string; }> {
        const user = await authService.getUser();
        if (!user || !user.profile) {
            throw new Error("User not authenticated or profile not found.");
        }
        return { 
            userId: user.id, 
            crmId: user.profile.crm_id, 
            role: user.profile.role,
            userFullName: user.profile.full_name || user.email || 'Un colega'
        };
    }

    async findContactByEmail(email: string): Promise<FoundContact | null> {
        if (!email || !email.trim()) {
            return null;
        }
        const { crmId } = await this.getAuthContext();
        const trimmedEmail = email.trim();

        const { data: client, error: clientError } = await supabase
            .from('clients')
            .select('*')
            .eq('email', trimmedEmail)
            .eq('crm_id', crmId)
            .maybeSingle();

        if (clientError) console.error("Error checking for duplicate client:", clientError);
        if (client) return { contact: client as Client, type: 'client' };

        const { data: prospect, error: prospectError } = await supabase
            .from('prospects')
            .select('*')
            .eq('email', trimmedEmail)
            .eq('crm_id', crmId)
            .maybeSingle();

        if (prospectError) console.error("Error checking for duplicate prospect:", prospectError);
        if (prospect) return { contact: prospect as Prospect, type: 'prospect' };

        return null;
    }

    async getClients(): Promise<Client[]> {
        const { crmId } = await this.getAuthContext();
        const { data, error } = await supabase.from('clients').select('*').eq('crm_id', crmId);
        if (error) throw error;
        return (data as Client[]) || [];
    }

    async getClientById(id: string): Promise<Client | null> {
        const { data, error } = await supabase.from('clients').select('*').eq('id', id).single();
        if (error) throw error;
        return data as Client | null;
    }

    async addClient(clientData: ClientDataForCreate): Promise<Client> {
        const { userId, crmId } = await this.getAuthContext();
        const existing = await this.findContactByEmail(clientData.email);
        if (existing?.type === 'client') throw new Error("Ya existe un cliente con este correo electrónico.");

        const coordinator = clientData.coordinator || await configService.getCoordinatorForCountry(clientData.country);
        const newClientForDb: ClientInsert = {
            ...clientData, crm_id: crmId, owner_id: userId, last_contact: new Date().toISOString(),
            creation_date: new Date().toISOString(), coordinator, total_paid: 0
        };
        const { data, error } = await supabase.from('clients').insert([newClientForDb]).select().single();
        if (error) throw error;
        return data as Client;
    }

    async updateClient(clientData: ClientUpdate): Promise<Client> {
        const { data, error } = await supabase.from('clients').update(clientData).eq('id', clientData.id!).select().single();
        if (error) throw error;
        return data as Client;
    }

    async deleteClient(id: string): Promise<void> {
        const { error } = await supabase.from('clients').delete().eq('id', id);
        if (error) throw error;
    }
    
    async bulkAddClients(clientsData: Partial<ClientInsert>[]) {
        const { userId, crmId } = await this.getAuthContext();
        const existingEmails = new Set((await this.getClients()).map(c => c.email?.trim()).filter(Boolean));
        
        const clientsToInsert: ClientInsert[] = [];
        const seenEmails = new Set<string>();
        let duplicateCount = 0;

        for (const c of clientsData) {
            const email = c.email?.trim();
            if (!email || existingEmails.has(email) || seenEmails.has(email)) {
                duplicateCount++; continue;
            }
            seenEmails.add(email);
            
            const installments: Installment[] = Array.from({ length: 15 }, (_, i) => i + 1)
                .map(i => ({ amount: c[`installment_${i}_amount`], date: c[`installment_${i}_date`], method: c[`installment_${i}_method`] }))
                .filter(inst => inst.amount && inst.date)
                .map(inst => ({ amount: Number(inst.amount), dueDate: new Date(inst.date).toISOString(), status: 'Pendiente', paymentMethod: inst.method || null }));

            clientsToInsert.push({
                crm_id: crmId, owner_id: userId, name: c.name || 'Sin Nombre', email, phone: c.phone || null,
                program: c.program || 'No especificado', stage: c.stage || (await configService.getClientStatuses())[0] || 'Activo',
                estimated_value: Number(c.estimated_value) || 0, last_contact: new Date().toISOString(),
                creation_date: new Date().toISOString(), next_contact: c.next_contact || null, owner: c.owner || 'Auto Asignado',
                notes: c.notes || '', country: c.country || '', origin: c.origin || 'Importado', coordinator: c.coordinator || '',
                payment_type: c.payment_type || 'Pago Único',
                single_payment_method: c.payment_type === 'Pago Único' ? c.single_payment_method : null,
                installments_total: installments.length || null, installments_paid: 0,
                installment_details: installments.length ? installments as unknown as Json : null, total_paid: 0,
            });
        }
        
        if (clientsToInsert.length > 0) {
            const { error } = await supabase.from('clients').insert(clientsToInsert);
            if (error) throw error;
        }
        
        return { successCount: clientsToInsert.length, duplicateCount };
    }

    async getProspects(): Promise<Prospect[]> {
        const { crmId } = await this.getAuthContext();
        const { data, error } = await supabase.from('prospects').select('*').eq('crm_id', crmId);
        if (error) throw error;
        return (data as Prospect[]) || [];
    }
    
    async getProspectById(id: string): Promise<Prospect | null> {
        const { data, error } = await supabase.from('prospects').select('*').eq('id', id).single();
        if (error) throw error;
        return data as Prospect | null;
    }

    async addProspect(prospectData: ProspectDataForCreate): Promise<Prospect> {
        const { userId, crmId } = await this.getAuthContext();
        const coordinator = prospectData.coordinator || await configService.getCoordinatorForCountry(prospectData.country);
        const newProspectForDb: ProspectInsert = { ...prospectData, owner_id: userId, crm_id: crmId, last_contact: new Date().toISOString(), creation_date: new Date().toISOString(), coordinator };
        const { data, error } = await supabase.from('prospects').insert([newProspectForDb]).select().single();
        if (error) throw error;
        return data as Prospect;
    }

    async updateProspect(prospectData: ProspectUpdate): Promise<Prospect> {
        const { data, error } = await supabase.from('prospects').update(prospectData).eq('id', prospectData.id!).select().single();
        if (error) throw error;
        return data as Prospect;
    }

    async deleteProspect(id: string): Promise<void> {
        const { error } = await supabase.from('prospects').delete().eq('id', id);
        if (error) throw error;
    }

    async bulkAddProspects(prospectsData: Partial<ProspectInsert>[]) {
        const { userId, crmId } = await this.getAuthContext();
        const existingEmails = new Set((await this.getProspects()).map(p => p.email?.trim()).filter(Boolean));
        const defaultStage = (await configService.getProspectStatuses())[0] || 'Nuevo';
    
        const prospectsToInsert: ProspectInsert[] = [];
        const seenEmails = new Set<string>();
        let duplicateCount = 0;
    
        for (const p of prospectsData) {
            const email = p.email?.trim();
            if (!email || existingEmails.has(email) || seenEmails.has(email)) {
                duplicateCount++; continue;
            }
            seenEmails.add(email);
    
            prospectsToInsert.push({
                owner_id: userId, crm_id: crmId, name: p.name || 'Sin Nombre', email, phone: p.phone || null,
                program: p.program || 'No especificado', stage: p.stage || defaultStage, estimated_value: Number(p.estimated_value) || 0,
                last_contact: new Date().toISOString(), creation_date: new Date().toISOString(), next_contact: p.next_contact || null,
                owner: p.owner || 'Auto Asignado', notes: p.notes || '', country: p.country || '',
                origin: p.origin || 'Importado', coordinator: p.coordinator || ''
            });
        }
    
        if (prospectsToInsert.length > 0) {
            const { error } = await supabase.from('prospects').insert(prospectsToInsert);
            if (error) throw error;
        }
        
        return { successCount: prospectsToInsert.length, duplicateCount };
    }

    async convertProspectToClient(prospectId: string, clientStage: string, clientValue: number): Promise<Client> {
        const prospect = await this.getProspectById(prospectId);
        if (!prospect) throw new Error("Prospecto no encontrado.");

        const existingClient = await this.findContactByEmail(prospect.email);
        if (existingClient?.type === 'client') throw new Error("Error: ya existe un cliente con el mismo correo electrónico.");

        const newClientData: ClientDataForCreate = {
            name: prospect.name, email: prospect.email, phone: prospect.phone, program: prospect.program,
            stage: clientStage, estimated_value: clientValue, next_contact: prospect.next_contact,
            owner: prospect.owner, notes: prospect.notes, country: prospect.country, origin: prospect.origin,
            coordinator: prospect.coordinator, payment_type: 'Pago Único', installments_total: null,
            installments_paid: null, installment_details: null, single_payment_method: null,
        };

        const newClient = await this.addClient(newClientData);
        await this.deleteProspect(prospectId);
        return newClient;
    }
    
    // --- USER MANAGEMENT & INVITATIONS ---

    async getUsers(): Promise<Profile[]> {
        const { crmId, role } = await this.getAuthContext();
        
        let query = supabase.from('profiles').select('*');
        if (role !== 'platform_admin') {
            query = query.eq('crm_id', crmId);
        }

        const { data, error } = await query;
        if (error) throw error;
        return (data as Profile[]) || [];
    }

    async updateUserRole(userId: string, role: RoleType): Promise<void> {
        const { error } = await supabase.from('profiles').update({ role }).eq('id', userId);
        if (error) throw error;
    }

    async deleteUser(userId: string): Promise<void> {
        // This only removes the profile. The auth user must be deleted by an admin in the Supabase dashboard.
        const { error } = await supabase.from('profiles').delete().eq('id', userId);
        if (error) throw error;
    }

    async createInvitation(email: string, role: RoleType): Promise<void> {
        const { userId, crmId, userFullName } = await this.getAuthContext();
    
        // Step 1: Insert invitation record into the database
        const { error: dbError } = await supabase.from('invitations').insert({ email, role, crm_id: crmId, invited_by: userId });
        if (dbError) {
            if (dbError.code === '23505') throw new Error('Ya existe una invitación para este correo electrónico.');
            throw dbError;
        }
    
        // Step 2: Invoke the edge function to send the email
        const { error: functionError } = await supabase.functions.invoke('invite-user', {
            body: {
                to: email,
                appUrl: window.location.origin,
                inviterName: userFullName,
            }
        });
    
        if (functionError) {
            // Optional: Rollback the DB insert if email fails? For now, just log and throw.
            console.error("Failed to send invitation email:", functionError);
            throw new Error("La invitación se registró, pero falló el envío del correo. Por favor, contacta al usuario manualmente.");
        }
    }
}

export const dataService = new DataService();