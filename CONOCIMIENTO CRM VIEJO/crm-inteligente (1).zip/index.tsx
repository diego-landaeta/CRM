
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App.tsx';
import { CurrencyProvider } from './contexts/CurrencyContext.tsx';

const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error("Could not find root element to mount to");
}

const root = ReactDOM.createRoot(rootElement);
root.render(
  <React.StrictMode>
    <CurrencyProvider>
      <App />
    </CurrencyProvider>
  </React.StrictMode>
);