
import { NavItem } from './types.ts';

export const NAV_ITEMS: NavItem[] = [
    { id: 'Dashboard', label: 'Dashboard', icon: 'dashboard' },
    { 
        id: 'contactos-parent', 
        label: 'Contactos',
        icon: 'people',
        subItems: [
            { id: 'Clients', label: 'Clientes', icon: 'group' },
            { id: 'Prospects', label: 'Prospectos', icon: 'trending_up' }
        ]
    },
    { 
        id: 'calendario-parent', 
        label: 'Calendario', 
        icon: 'calendar_today',
        subItems: [
            { id: 'Calendar', label: 'Calendario', icon: 'event' },
            { id: 'Email', label: 'Email', icon: 'email' },
        ]
    },
    { id: 'Billing', label: 'Facturación', icon: 'receipt_long' },
    { id: 'Statistics', label: 'Estadísticas', icon: 'query_stats' },
    { 
        id: 'config-parent', 
        label: 'Configuración', 
        icon: 'settings',
        subItems: [
            { id: 'Configuration', label: 'Conf. General', icon: 'tune' },
            { id: 'Roles', label: 'Roles y Permisos', icon: 'admin_panel_settings' },
            { id: 'Support', label: 'Soporte', icon: 'support_agent' },
        ]
    },
    { id: 'Manual', label: 'Manual de Usuario', icon: 'menu_book' },
];

export const ORIGINS = ['Referido', 'Web', 'Campaña Publicitaria', 'Evento', 'Otro'];