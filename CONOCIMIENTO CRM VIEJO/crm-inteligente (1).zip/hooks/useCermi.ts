
import { useState, useCallback, useRef } from 'react';
import { ChatMessage } from '../types.ts';
import { cermiChat } from '../services/geminiService.ts';
import { dataService } from '../services/dataService.ts';

export const useCermi = () => {
    const [messages, setMessages] = useState<ChatMessage[]>([
        { id: 'initial-1', role: 'model', text: '¡Hola! Soy Cermi, tu asistente de CRM. Ahora puedo responder preguntas sobre tus clientes y prospectos. ¿En qué puedo ayudarte hoy?' }
    ]);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const abortControllerRef = useRef<AbortController | null>(null);

    const sendMessage = useCallback(async (text: string) => {
        if (isLoading) return;

        setIsLoading(true);
        setError(null);
        
        const userMessage: ChatMessage = { id: Date.now().toString(), role: 'user', text };
        setMessages(prev => [...prev, userMessage]);

        const modelMessageId = (Date.now() + 1).toString();
        // Add a placeholder for the model's response
        setMessages(prev => [...prev, { id: modelMessageId, role: 'model', text: '' }]);

        try {
            let finalPrompt = text;
            const lowerCaseText = text.toLowerCase();
            const keywords = ['cliente', 'prospecto', 'información', 'datos de', 'quién es', 'dime sobre', 'cuántos'];

            // If the prompt contains keywords related to CRM data, fetch and prepend it.
            if (keywords.some(keyword => lowerCaseText.includes(keyword))) {
                const clients = await dataService.getClients();
                const prospects = await dataService.getProspects();
                
                // Select specific fields to keep the context concise and relevant
                const clientData = clients.map(c => ({ name: c.name, email: c.email, stage: c.stage, program: c.program, notes: c.notes, country: c.country, estimated_value: c.estimated_value, coordinator: c.coordinator }));
                const prospectData = prospects.map(p => ({ name: p.name, email: p.email, stage: p.stage, program: p.program, notes: p.notes, country: p.country, estimated_value: p.estimated_value, coordinator: p.coordinator }));
                
                const context = `Contexto del CRM (en formato JSON):\n- Clientes: ${JSON.stringify(clientData)}\n- Prospectos: ${JSON.stringify(prospectData)}\n\n---\n\n`;
                finalPrompt = `${context}Pregunta del usuario: "${text}"`;
            }

            const stream = await cermiChat.sendMessageStream({ message: finalPrompt });
            
            for await (const chunk of stream) {
                const chunkText = chunk.text;
                setMessages(prev =>
                    prev.map(msg =>
                        msg.id === modelMessageId ? { ...msg, text: msg.text + chunkText } : msg
                    )
                );
            }

        } catch (e: any) {
            console.error("Gemini API Error:", e);
            const errorMessage = "Lo siento, ocurrió un error al procesar tu solicitud. Por favor, intenta de nuevo.";
            setError(errorMessage);
            setMessages(prev =>
                prev.map(msg =>
                    msg.id === modelMessageId ? { ...msg, text: errorMessage, isError: true } : msg
                )
            );
        } finally {
            setIsLoading(false);
        }
    }, [isLoading]);
    
    const cancelStream = useCallback(() => {
        if (abortControllerRef.current) {
            abortControllerRef.current.abort();
            setIsLoading(false);
        }
    }, []);

    return { messages, isLoading, error, sendMessage, cancelStream };
};