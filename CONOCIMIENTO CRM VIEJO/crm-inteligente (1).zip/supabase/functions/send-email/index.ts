
import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import { Resend } from 'npm:resend@3.2.0';
import { corsHeaders } from '../_shared/cors.ts'

declare const Deno: any;

serve(async (req) => {
  // Handle CORS preflight request
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  const supabase = createClient(
    Deno.env.get('SUPABASE_URL')!,
    Deno.env.get('SUPABASE_ANON_KEY')!,
    { global: { headers: { Authorization: req.headers.get('Authorization')! } } }
  )

  let user, profile;
  let requestBody: { to: string; subject: string; body: string; } | null = null;
  
  try {
    const { data: { user: authUser } } = await supabase.auth.getUser()
    user = authUser;
    if (!user) {
      throw new Error('Usuario no autenticado.')
    }

    const { data: userProfile, error: profileError } = await supabase
      .from('profiles')
      .select('role, crm_id')
      .eq('id', user.id)
      .single()
    profile = userProfile
    if (profileError || !profile) {
      throw new Error('Perfil de usuario no encontrado.')
    }
    
    requestBody = await req.json();
    const { to, subject, body } = requestBody;
    if (!to || !subject || !body) {
      throw new Error('Faltan campos obligatorios: para, asunto, cuerpo del mensaje.')
    }

    // Rate Limiting (5 emails per minute)
    await supabase.from('rate_limit_logs').delete().lt('created_at', new Date(Date.now() - 60000).toISOString());

    const { count, error: rateError } = await supabase
        .from('rate_limit_logs')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', user.id);

    if (rateError) throw new Error('No se pudo verificar el límite de envíos.');

    if (count !== null && count >= 5) {
      throw new Error('Límite de envíos excedido. Por favor, espera un minuto.');
    }

    // Send email via Resend SDK
    const resendApiKey = Deno.env.get('RESEND_API_KEY');
    if (!resendApiKey) {
      throw new Error("La RESEND_API_KEY no está configurada en las variables de entorno.");
    }
    
    const resend = new Resend(resendApiKey);

    const { data: resendData, error: resendError } = await resend.emails.send({
      from: 'CRM Inteligente <contacto@gestion360pro.com>',
      to: to,
      subject: subject,
      html: body.replace(/\n/g, '<br>'),
      reply_to: user.email,
    });

    if (resendError) {
      // The Resend SDK provides a detailed error object.
      console.error("Resend API error:", resendError);
      throw new Error(`Error del servidor de correo: ${resendError.message}`);
    }
    
    // Log success
    await supabase.from('email_logs').insert({
      crm_id: profile.crm_id, user_id: user.id, role: profile.role,
      recipient_email: to, status: 'success',
    });
    await supabase.from('rate_limit_logs').insert({ user_id: user.id });

    return new Response(JSON.stringify({ message: '¡Correo enviado exitosamente!' }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 200,
    })
  } catch (error) {
    console.error('Email sending error:', error.message);
    
    const recipientForLog = requestBody?.to || 'No disponible';

    // Log error if user context is available
    if (user && profile) {
      try {
        await supabase.from('email_logs').insert({
            crm_id: profile.crm_id, 
            user_id: user.id, 
            role: profile.role,
            recipient_email: recipientForLog, 
            status: 'error', 
            error_message: error.message,
        });
      } catch (logError) {
         console.error("Fallo al registrar el error en la base de datos:", logError.message);
      }
    }
    
    return new Response(JSON.stringify({ error: error.message }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 500,
    })
  }
})
