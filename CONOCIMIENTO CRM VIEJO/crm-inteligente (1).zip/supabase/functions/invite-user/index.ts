import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import nodemailer from 'npm:nodemailer@6.9.7'
import { corsHeaders } from '../_shared/cors.ts'

declare const Deno: any;

serve(async (req) => {
  // Handle CORS preflight request
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    // Auth check to ensure only authenticated users can send invites
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_ANON_KEY')!,
      { global: { headers: { Authorization: req.headers.get('Authorization')! } } }
    )
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) {
      throw new Error('User not authenticated.')
    }

    const { to, appUrl, inviterName } = await req.json()
    if (!to || !appUrl || !inviterName) {
      throw new Error('Missing required fields: to, appUrl, inviterName.')
    }

    // Configure Nodemailer transporter using environment variables
    const transporter = nodemailer.createTransport({
      host: Deno.env.get('SMTP_HOST'),
      port: parseInt(Deno.env.get('SMTP_PORT')!),
      secure: parseInt(Deno.env.get('SMTP_PORT')!) === 465, // true for 465, false for other ports
      auth: {
        user: Deno.env.get('SMTP_USER'),
        pass: Deno.env.get('SMTP_PASS'),
      },
    });

    const subject = `¡Has sido invitado a unirte a CRM Inteligente!`
    const body = `
      <div style="font-family: 'Inter', sans-serif; max-width: 600px; margin: auto; padding: 20px; border: 1px solid #ddd; border-radius: 10px; background-color: #f9f9f9;">
        <div style="text-align: center; margin-bottom: 20px;">
          <h1 style="color: #0F766E;">CRM Inteligente</h1>
        </div>
        <h2 style="color: #1F2937;">¡Hola!</h2>
        <p style="color: #374151; line-height: 1.6;"><strong>${inviterName}</strong> te ha invitado a unirte a su equipo de trabajo.</p>
        <p style="color: #374151; line-height: 1.6;">Para aceptar la invitación y comenzar a colaborar, por favor regístrate en el siguiente enlace utilizando este mismo correo electrónico (<strong>${to}</strong>).</p>
        <div style="text-align: center; margin: 30px 0;">
          <a href="${appUrl}/" style="background-color: #10B981; color: white; padding: 15px 25px; text-decoration: none; border-radius: 5px; font-weight: bold; font-size: 16px;">Crear Cuenta y Unirme</a>
        </div>
        <p style="color: #374151; line-height: 1.6;">Si tienes alguna pregunta, por favor contacta a ${inviterName}.</p>
        <br>
        <p style="color: #6B7280;">¡Te esperamos!</p>
        <p style="color: #6B7280;"><em>El equipo de CRM Inteligente</em></p>
      </div>
    `

    // Send the email
    await transporter.sendMail({
      from: `"CRM Inteligente" <contacto@gestion360pro.com>`,
      to: to,
      subject: subject,
      html: body,
    });

    return new Response(JSON.stringify({ message: 'Invitation email sent successfully!' }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 200,
    })
  } catch (error) {
    console.error('Invitation sending error:', error.message);
    return new Response(JSON.stringify({ error: `Failed to send invitation: ${error.message}` }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 500,
    })
  }
})