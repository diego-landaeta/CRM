
import React, { createContext, useContext, useState, useEffect, useCallback, ReactNode } from 'react';
import { configService } from '../services/configService.ts';
import { authService } from '../services/authService.ts';

type Currency = 'USD' | 'EUR';

interface CurrencyContextType {
    currency: Currency;
    setCurrency: (currency: Currency) => Promise<void>;
    formatCurrency: (value: number | null | undefined) => string;
}

const CurrencyContext = createContext<CurrencyContextType | undefined>(undefined);

export const CurrencyProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const [currency, setCurrencyState] = useState<Currency>('USD');
    const [isLoading, setIsLoading] = useState(true);

    const fetchCurrency = useCallback(async () => {
        setIsLoading(true);
        try {
            const savedCurrency = await configService.getCurrency();
            setCurrencyState(savedCurrency);
        } catch (error) {
            console.error("Failed to fetch currency, defaulting to USD.", error);
            setCurrencyState('USD');
        } finally {
            setIsLoading(false);
        }
    }, []);

    useEffect(() => {
        const { data: authListener } = authService.onAuthStateChange((_event, session) => {
            if (session) {
                // User is authenticated, fetch their specific currency config.
                fetchCurrency();
            } else {
                // User is not authenticated, use default and stop loading.
                setCurrencyState('USD');
                setIsLoading(false);
            }
        });

        const handleConfigUpdate = () => {
            // This custom event is fired when config is saved.
            // We can assume a session exists if config is being updated.
            fetchCurrency();
        };
        window.addEventListener('config_updated', handleConfigUpdate);

        // Cleanup on unmount
        return () => {
            authListener.subscription.unsubscribe();
            window.removeEventListener('config_updated', handleConfigUpdate);
        };
    }, [fetchCurrency]);

    const setCurrency = async (newCurrency: Currency) => {
        await configService.updateCurrency(newCurrency);
        // The event listener will trigger a state update across the app.
    };

    const formatCurrency = (value: number | null | undefined): string => {
        const locale = currency === 'EUR' ? 'de-DE' : 'en-US'; // Use locales that place symbol correctly
        const val = value ?? 0;
        return new Intl.NumberFormat(locale, {
            style: 'currency',
            currency: currency,
            minimumFractionDigits: 0,
            maximumFractionDigits: 2,
        }).format(val);
    };
    
    const value = { currency, setCurrency, formatCurrency };

    return (
        <CurrencyContext.Provider value={value}>
            {isLoading ? (
                <div className="flex h-screen items-center justify-center bg-gray-100">
                    <div className="text-xl font-medium text-gray-600">Cargando...</div>
                </div>
            ) : (
                children
            )}
        </CurrencyContext.Provider>
    );
};

export const useCurrency = (): CurrencyContextType => {
    const context = useContext(CurrencyContext);
    if (context === undefined) {
        throw new Error('useCurrency must be used within a CurrencyProvider');
    }
    return context;
};